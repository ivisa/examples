package com.cardif.satelite.tesoreria.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.cardif.satelite.tesoreria.model.TramaGenera;

public interface TramaGeneraMapper {
	final String LISTA_TRAMAS ="SELECT * FROM SINI_TRAMA_GENERA"
			+ " WHERE"
			+ " LOTEID = ISNULL(#{nroLote,jdbcType=VARCHAR},LOTEID) AND"
			+ " FECHACREA>=DATEADD(dd, 0, DATEDIFF(dd, 0, ISNULL(#{fec1,jdbcType=DATE},FECHACREA) ))  "
      		+ " AND FECHACREA< DATEADD(dd, 1, DATEDIFF(dd, 0, ISNULL(#{fec2,jdbcType=DATE},FECHACREA) )) "
			+ " AND TIPOPAGOMASIVO =ISNULL(#{tipoPago,jdbcType=VARCHAR},TIPOPAGOMASIVO) "
			+ " AND fecGenTrama IS NULL";
	
	final String LISTA_TRAMAS_ID ="SELECT * FROM SINI_TRAMA_GENERA"
			+ " WHERE"
			+ " LOTEID = ISNULL(#{nroLote,jdbcType=VARCHAR},LOTEID) ";
	
	final String INSERT_TRAMA ="INSERT INTO SINI_TRAMA_GENERA("
			+ "loteId,tipoPagoMasivo,codBanco,moneda,cuentaOrdenante,"
			+ "tramaMonto,usuarioCrea,fechaCrea)"
			+ " VALUES("
			+ "#{loteId,jdbcType=NVARCHAR},"
			+ "#{tipoPagoMasivo,jdbcType=NVARCHAR},"
			+ "#{codBanco,jdbcType=NVARCHAR},"
			+ "#{moneda,jdbcType=VARCHAR},"
			+ "#{cuentaOrdenante,jdbcType=NVARCHAR},"
			+ "#{tramaMonto,javaType=double,jdbcType=NUMERIC},"
			+ "#{usuarioCrea,jdbcType=VARCHAR},"
			+ "GETDATE())"
			+ "";
	final String UPDATE_FECHA_GENERACION ="UPDATE SINI_TRAMA_GENERA"
			+ " SET fecGenTrama = GETDATE()"
			+ " WHERE"
			+ " LOTEID = #{nroLote,jdbcType=VARCHAR} ";
	
	
	@Select(LISTA_TRAMAS)
	public List<TramaGenera> listaTramas(@Param("nroLote") String nroLote, @Param("tipoPago") String tipoPago, @Param("fec1") Date fec1, @Param("fec2") Date fec2);
	
	@Select(LISTA_TRAMAS_ID)
	public TramaGenera listaTramasById(@Param("nroLote") String nroLote);
	
	@Insert(INSERT_TRAMA)
	public void insertTramaGenera(TramaGenera tramaGenera);
	
	@Update(UPDATE_FECHA_GENERACION)
	public void updateTramaGeneraFechaGenera(@Param("nroLote") String nroLote);
	
	
}
