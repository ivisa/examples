package com.cardif.satelite.tesoreria.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.tesoreria.bean.ConsultaPagoResultado;
import com.cardif.satelite.tesoreria.bean.JournalBean;



public interface ConsultaPagoService {
	public ConsultaPagoResultado  obtenerNumeroDeLote(Integer anio , String moneda,String usuario) throws SyncconException;
	public int deleteSiniGeneraLote(String loteId)  throws SyncconException;
	public void actualizarFechaProvisionadoSiniestro(List<JournalBean> listaActualizar,String usuario) throws SyncconException;
	public void actualizarFechaRegistroPagoSiniestro(List<JournalBean> listaActualizar,String usuario) throws SyncconException;
}
