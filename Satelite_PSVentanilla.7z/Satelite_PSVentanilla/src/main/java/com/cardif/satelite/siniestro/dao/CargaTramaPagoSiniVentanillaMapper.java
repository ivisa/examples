package com.cardif.satelite.siniestro.dao;

import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;

public interface CargaTramaPagoSiniVentanillaMapper {
	
	public int insert(TramaConfPagoSiniVentanilla record);
	
	public TramaConfPagoSiniVentanilla selectByPrimaryKey(Long tramaId);
	
	public int deleteByPrimaryKey(Long tramaId);
	
	public int updateByPrimaryKeySelective(TramaConfPagoSiniVentanilla record);
	
	

}
