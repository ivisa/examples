package com.cardif.satelite.siniestro.ventanilla.tramas.bbva;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class LogErroresArchivosBean {

	public String tipoArchivo;
	public String tipoArchivoDesc;
	public int cantCorrectos;
	public int cantIncorrectos;
	public int cantTotal;
	public String linkArchivoTxtErrores;
	
	public static enum NOMBRE_ARCHIVO_LOG_ERRORES_TXT {
		CONFIRMACION("LogErroresArchivosConfirmación_"),
		PAGOS("LogErroresArchivosPagos_");
		
		private String value;
		
		private NOMBRE_ARCHIVO_LOG_ERRORES_TXT(String value) {
			this.value = value;
		}
		
		public String getValue() {
			  SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy-HHmmss");
			  String fmtHora = sdf.format(Calendar.getInstance().getTime());
		      return value+fmtHora+".txt";
		}
	}

	public String getTipoArchivo() {
		return tipoArchivo;
	}
	public void setTipoArchivo(String tipoArchivo) {
		this.tipoArchivo = tipoArchivo;
	}
	public String getTipoArchivoDesc() {
		return tipoArchivoDesc;
	}
	public void setTipoArchivoDesc(String tipoArchivoDesc) {
		this.tipoArchivoDesc = tipoArchivoDesc;
	}
	public int getCantCorrectos() {
		return cantCorrectos;
	}
	public void setCantCorrectos(int cantCorrectos) {
		this.cantCorrectos = cantCorrectos;
	}
	public int getCantIncorrectos() {
		return cantIncorrectos;
	}
	public void setCantIncorrectos(int cantIncorrectos) {
		this.cantIncorrectos = cantIncorrectos;
	}
	public int getCantTotal() {
		return cantTotal;
	}
	public void setCantTotal(int cantTotal) {
		this.cantTotal = cantTotal;
	}
	public String getLinkArchivoTxtErrores() {
		return linkArchivoTxtErrores;
	}
	public void setLinkArchivoTxtErrores(String linkArchivoTxtErrores) {
		this.linkArchivoTxtErrores = linkArchivoTxtErrores;
	}
	
}
