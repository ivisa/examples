package com.cardif.satelite.tesoreria.model;

import java.util.Date;

public class ConsultaPagoBancario {
	private String codigoTrama;
	private int ordenResultado;
	private String tipoTrama;
	private String nombreTipo;
	private String numeroLote;
	private String nombreArchivo;
	private String rutaArchivo;
	private Date fechaCarga;
	public int getOrdenResultado() {
		return ordenResultado;
	}
	public void setOrdenResultado(int ordenResultado) {
		this.ordenResultado = ordenResultado;
	}
	public String getTipoTrama() {
		return tipoTrama;
	}
	public void setTipoTrama(String tipoTrama) {
		this.tipoTrama = tipoTrama;
	}
	public String getNumeroLote() {
		return numeroLote;
	}
	public void setNumeroLote(String numeroLote) {
		this.numeroLote = numeroLote;
	}
	public String getNombreArchivo() {
		return nombreArchivo;
	}
	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}
	public String getRutaArchivo() {
		return rutaArchivo;
	}
	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}
	public Date getFechaCarga() {
		return fechaCarga;
	}
	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}
	public String getNombreTipo() {
		return nombreTipo;
	}
	public void setNombreTipo(String nombreTipo) {
		this.nombreTipo = nombreTipo;
	}
	public String getCodigoTrama() {
		return codigoTrama;
	}
	public void setCodigoTrama(String codigoTrama) {
		this.codigoTrama = codigoTrama;
	}
	
}
