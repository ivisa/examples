package com.cardif.satelite.tesoreria.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class TramaGenera implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String loteId;
	private String tipoPagoMasivo;
	private String codBanco;
	private String moneda;
	private String cuentaOrdenante;
	private double tramaMonto;
	private Date fecGenTrama;
	private String usuarioCrea;
	private Date fechaCrea;
	private String usuarioModifica;
	private Date fechaModifica;
	private List<TramaGeneraDet> detalleTramaGenera;
	public String getLoteId() {
		return loteId;
	}
	public void setLoteId(String loteId) {
		this.loteId = loteId;
	}
	public String getTipoPagoMasivo() {
		return tipoPagoMasivo;
	}
	public void setTipoPagoMasivo(String tipoPagoMasivo) {
		this.tipoPagoMasivo = tipoPagoMasivo;
	}
	public String getCodBanco() {
		return codBanco;
	}
	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public double getTramaMonto() {
		return tramaMonto;
	}
	public void setTramaMonto(double tramaMonto) {
		this.tramaMonto = tramaMonto;
	}
	public Date getFecGenTrama() {
		return fecGenTrama;
	}
	public void setFecGenTrama(Date fecGenTrama) {
		this.fecGenTrama = fecGenTrama;
	}
	public String getUsuarioCrea() {
		return usuarioCrea;
	}
	public void setUsuarioCrea(String usuarioCrea) {
		this.usuarioCrea = usuarioCrea;
	}
	public Date getFechaCrea() {
		return fechaCrea;
	}
	public void setFechaCrea(Date fechaCrea) {
		this.fechaCrea = fechaCrea;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public Date getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
	public List<TramaGeneraDet> getDetalleTramaGenera() {
		return detalleTramaGenera;
	}
	public void setDetalleTramaGenera(List<TramaGeneraDet> detalleTramaGenera) {
		this.detalleTramaGenera = detalleTramaGenera;
	}
	public String getCuentaOrdenante() {
		return cuentaOrdenante;
	}
	public void setCuentaOrdenante(String cuentaOrdenante) {
		this.cuentaOrdenante = cuentaOrdenante;
	}
	
	
}
