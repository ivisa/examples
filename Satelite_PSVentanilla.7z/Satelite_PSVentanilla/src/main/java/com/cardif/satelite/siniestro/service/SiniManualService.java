package com.cardif.satelite.siniestro.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.siniestro.model.SiniManual;

public interface SiniManualService {
	public int createSiniManual(SiniManual siniManual) throws SyncconException;

	public int updateSiniManual(SiniManual siniManual) throws SyncconException;

	public int deleteSiniManual(SiniManual siniManual) throws SyncconException;

	public List<SiniManual> getAllSiniManualByFilter(String ramo, Date fecInicioCarga, Date fecFinCarga, String idSiniestro, String tipoDocumento, String numeroDocumento, String nombre,
			String apellidoPaterno, String apellidoMaterno, String estadoBeneficiario) throws SyncconException;

	public void createAllSiniManual(List<SiniManual> listSiniManual) throws SyncconException;

	public void updateBeneficiarioLoteId(String siniestroId, String nombres, String loteId, String usuario) throws SyncconException;

	public SiniManual getSiniManualBySiniestroNombre(String siniestroId, String nombres) throws SyncconException;

	public void updateBeneficiarioFechaAsigna(String loteId, String usuario)throws SyncconException;
	
	public void updateListaManualBeneficiarioFechaAsigna(List<String> loteId, String usuario)throws SyncconException;
}
