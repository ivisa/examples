package com.cardif.satelite.siniestro.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;







import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.siniestro.model.SiniManual;

public interface SiniManualMapper {
	
	final String CREATE_SINI_MANUAL="INSERT INTO dbo.SINI_MANUAL"
			+ "(siniestro_id"
			+ ",bene_tipo_documento"
			+ ",bene_numero_documento"
			+ ",bene_socio"
			+ ",bene_producto"
			+ ",bene_numero_poliza"
			+ ",bene_fecha_ocurrencia"
			+ ",bene_numero_planilla"
			+ ",bene_monto_pagar"
			+ ",bene_moneda"
			+ ",bene_fecha_apro_rech_carta"
			+ ",bene_mes_apro_rech_carta"
			+ ",bene_apellido_paterno"
			+ ",bene_apellido_materno"
			+ ",bene_nombre"
			+ ",bene_pais"
			+ ",bene_email"
			+ ",bene_numero_cuenta_ban"
			+ ",bene_telefono1"
			+ ",bene_telefono2"
			+ ",bene_direccion"
			+ ",bene_parentesco"
			+ ",bene_porcentaje_participacion"
			+ ",bene_fecha_entrega_op_conta"
			+ ",bene_estado"
			+ ",bene_fecha_pendiente"
			+ ",bene_fecha_envio_op_conta"
			+ ",bene_fecha_provisionado"
			+ ",bene_fecha_registro_pago"
			+ ",bene_fecha_asigna_firmantes"
			+ ",bene_fecha_procesado"
			+ ",bene_fecha_cobro"
			+ ",bene_lote_id"
			+ ",bene_usuario_registra"
			+ ",bene_fecha_registro_archivo"
			+ ")"
			+ " VALUES"
			+ "(#{siniestroId,jdbcType=NVARCHAR}"
			+ ",#{beneTipoDocumento,jdbcType=VARCHAR}"
			+ ",#{beneNumeroDocumento,jdbcType=VARCHAR}"
			+ ",#{beneSocio,jdbcType=VARCHAR}"
			+ ",#{beneProducto,jdbcType=VARCHAR}"
			+ ",#{beneNumeroPoliza,jdbcType=VARCHAR}"
			+ ",#{beneFechaOcurrencia,jdbcType=DATE}"
			+ ",#{beneNumeroPlanilla,jdbcType=NVARCHAR}"
			+ ",#{beneMontoPagar,javaType=double,jdbcType=NUMERIC}"
			+ ",#{beneMoneda,jdbcType=VARCHAR}"
			+ ",#{beneFechaAproRechCarta,jdbcType=DATE}"
			+ ",#{beneMesAproRechCarta,jdbcType=VARCHAR}"
			+ ",#{beneApellidoPaterno,jdbcType=VARCHAR}"
			+ ",#{beneApellidoMaterno,jdbcType=VARCHAR}"
			+ ",#{beneNombre,jdbcType=VARCHAR}"
			+ ",#{benePais,jdbcType=VARCHAR}"
			+ ",#{beneEmail,jdbcType=VARCHAR}"
			+ ",#{beneNumeroCuentaBan,jdbcType=VARCHAR}"
			+ ",#{beneTelefono1,jdbcType=VARCHAR}"
			+ ",#{beneTelefono2,jdbcType=VARCHAR}"
			+ ",#{beneDireccion,jdbcType=VARCHAR}"
			+ ",#{beneParentesco,jdbcType=VARCHAR}"
			+ ",#{benePorcentajeParticipacion,javaType=double,jdbcType=NUMERIC}"
			+ ",#{beneFechaEntregaOpConta,jdbcType=DATE}"
			+ ",#{beneEstado,jdbcType=CHAR}"
			+ ",#{beneFechaPendiente,jdbcType=DATE}"
			+ ",#{beneFechaEnvioOpConta,jdbcType=DATE}"
			+ ",#{beneFechaProvisionado,jdbcType=DATE}"
			+ ",#{beneFechaRegistroPago,jdbcType=DATE}"
			+ ",#{beneFechaAsignaFirmantes,jdbcType=DATE}"
			+ ",#{beneFechaProcesado,jdbcType=DATE}"
			+ ",#{beneFechaCobro,jdbcType=DATE}"
			+ ",#{beneLoteId,jdbcType=VARCHAR}"
			+ ",#{beneUsuarioRegistra,jdbcType=VARCHAR}"
			+ ",GETDATE()"
			+ ")";
	
	final String UPDATE_SINI_MANUAL="UPDATE dbo.SINI_MANUAL SET"
			+ "bene_socio=#{beneSocio,jdbcType=VARCHAR}"
			+ ",bene_producto=#{beneProducto,jdbcType=VARCHAR}"
			+ ",bene_numero_poliza=#{beneNumeroPoliza,jdbcType=VARCHAR}"
			+ ",bene_fecha_ocurrencia=#{beneFechaOcurrencia,jdbcType=DATE}"
			+ ",bene_numero_planilla=#{beneNumeroPlanilla,jdbcType=NVARCHAR}"
			+ ",bene_monto_pagar=#{beneMontoPagar,javaType=double,jdbcType=NUMERIC}"
			+ ",bene_moneda=#{beneMoneda,jdbcType=VARCHAR}"
			+ ",bene_fecha_apro_rech_carta=#{beneFechaAproRechCarta,jdbcType=DATE}"
			+ ",bene_mes_apro_rech_carta=#{beneMesAproRechCarta,jdbcType=VARCHAR}"
			+ ",bene_apellido_paterno=#{beneApellidoPaterno,jdbcType=VARCHAR}"
			+ ",bene_apellido_materno=#{beneApellidoMaterno,jdbcType=VARCHAR}"
			+ ",bene_nombre=#{beneNombre,jdbcType=VARCHAR}"
			+ ",bene_pais = #{benePais,jdbcType=NVARCHAR}"
			+ ",bene_email = #{beneEmail,jdbcType=VARCHAR}"
			+ ",bene_numero_cuenta_ban=#{beneNumeroCuentaBan,jdbcType=VARCHAR}"
			+ ",bene_telefono1=#{beneTelefono1,jdbcType=VARCHAR}"
			+ ",bene_telefono2=#{beneTelefono2,jdbcType=VARCHAR}"
			+ ",bene_direccion=#{beneDireccion,jdbcType=VARCHAR}"
			+ ",bene_parentesco=#{beneParentesco,jdbcType=VARCHAR}"
			+ ",bene_porcentaje_participacion=#{benePorcentajeParticipacion,javaType=double,jdbcType=NUMERIC}"
			+ ",bene_fecha_entrega_op_conta=#{beneFechaEntregaOpConta,jdbcType=DATE}"
			+ ",bene_estado=#{beneEstado,jdbcType=CHAR}"
			+ ",bene_fecha_pendiente=#{beneFechaPendiente,jdbcType=DATE}"
			+ ",bene_fecha_envio_op_conta=#{beneFechaEnvioOpConta,jdbcType=DATE}"
			+ ",bene_fecha_provisionado=#{beneFechaProvisionado,jdbcType=DATE}"
			+ ",bene_fecha_registro_pago=#{beneFechaRegistroPago,jdbcType=DATE}"
			+ ",bene_fecha_asigna_firmantes=#{beneFechaAsignaFirmantes,jdbcType=DATE}"
			+ ",bene_fecha_procesado=#{beneFechaProcesado,jdbcType=DATE}"
			+ ",bene_fecha_cobro=#{beneFechaCobro,jdbcType=DATE}"
			+ ",bene_lote_id=#{beneLoteId,jdbcType=VARCHAR"
			+ ",bene_usuario_modifica=#{beneUsuarioModifica,jdbcType=VARCHAR}"
			+ ",bene_fecha_modificacion= GETDATE()"
			+ " WHERE"
			+ " siniestro_id = #{siniestroId,jdbcType=NVARCHAR} AND"
			+ " bene_tipo_documento=#{beneTipoDocumento,jdbcType=VARCHAR} AND "
			+ " bene_numero_documento=#{beneNumeroDocumento,jdbcType=VARCHAR}"
			+ "";
	
	final String DELETE_SINI_MANUAL="DELETE FROM dbo.SINI_MANUAL WHERE"
			+ " siniestro_id = #{siniestroId,jdbcType=NVARCHAR} AND"
			+ " bene_tipo_documento=#{beneTipoDocumento,jdbcType=VARCHAR} AND "
			+ " bene_numero_documento=#{beneNumeroDocumento,jdbcType=VARCHAR}";
	
	final String SELECT_GET_ALL_FILTER = "SELECT " 
			+ "siniestro_id,"
			+ "("
			+ " SELECT LTRIM(RTRIM(NOM_VALOR))"
			+ " FROM PARAMETRO"
			+ " WHERE LTRIM(RTRIM(COD_PARAM))='"+Constantes.COD_PARAM_SINIESTRO_MANUAL+"'"
			+ " AND LTRIM(RTRIM(COD_VALOR))=SUBSTRING(siniestro_id,1,2) AND TIP_PARAM='"+Constantes.TIP_PARAM_DETALLE+"'"
			+ " ) AS RAMO" 
			+ ",bene_tipo_documento"
			+ ",(SELECT LTRIM(RTRIM(NOM_VALOR)) FROM PARAMETRO WHERE COD_PARAM='027' AND LTRIM(RTRIM(COD_VALOR))=LTRIM(RTRIM(bene_tipo_documento))) AS descripcionTipDoc"   
			+ ",bene_numero_documento" 
			+ ",bene_socio"       
			+ ",bene_producto"       
			+ ",bene_numero_poliza"       
			+ ",bene_fecha_ocurrencia" 
			+ ",bene_numero_planilla"  
			+ ",bene_monto_pagar"       
			+ ",bene_moneda"       
			+ ",bene_fecha_apro_rech_carta" 
			+ ",bene_mes_apro_rech_carta"       
			+ ",bene_apellido_paterno"       
			+ ",bene_apellido_materno"       
			+ ",bene_nombre"       
			+ ",bene_pais"     
			+ ",bene_email"       
			+ ",bene_numero_cuenta_ban"       
			+ ",bene_telefono1"       
			+ ",bene_telefono2"       
			+ ",bene_direccion"       
			+ ",bene_parentesco"       
			+ ",bene_porcentaje_participacion" 
			+ ",bene_fecha_entrega_op_conta" 
			+ ",bene_estado"
			+ ",("
			+ " SELECT LTRIM(RTRIM(NOM_VALOR))"
			+ " FROM PARAMETRO"
			+ " WHERE LTRIM(RTRIM(COD_PARAM))='"+Constantes.COD_PARAM_ESTADO_BENEFICIARIO+"'"
			+ " AND LTRIM(RTRIM(COD_VALOR))=LTRIM(RTRIM(bene_estado)) AND TIP_PARAM='"+Constantes.TIP_PARAM_DETALLE+"'"
			+ " ) AS DESCRI_ESTADO" 
			+ ",bene_fecha_pendiente" 
			+ ",bene_fecha_envio_op_conta" 
			+ ",bene_fecha_provisionado" 
			+ ",bene_fecha_registro_pago" 
			+ ",bene_fecha_asigna_firmantes" 
			+ ",bene_fecha_procesado" 
			+ ",bene_fecha_cobro" 
			+ ",bene_lote_id" 
			+ ",bene_usuario_registra" 
			+ ",bene_fecha_registro_archivo" 
			+ ",bene_usuario_modifica"  
			+ " FROM SINI_MANUAL"
			+ " WHERE"
			+ " SUBSTRING(LTRIM(RTRIM(SINIESTRO_ID)),1,2) = COALESCE(#{tipoRamo,jdbcType=VARCHAR},SUBSTRING(LTRIM(RTRIM(SINIESTRO_ID)),1,2)) AND"
			+ " COALESCE(#{fecInicioCarga,jdbcType=DATE},CONVERT(DATE,bene_fecha_registro_archivo)) <= CONVERT(DATE,bene_fecha_registro_archivo) AND"
			+ " CONVERT(DATE,bene_fecha_registro_archivo) <= COALESCE(#{fecFinCarga,jdbcType=DATE},CONVERT(DATE,bene_fecha_registro_archivo)) AND"
			+ " SINIESTRO_ID = COALESCE(#{numeroSiniestro,jdbcType=VARCHAR},SINIESTRO_ID) AND"
			+ " BENE_TIPO_DOCUMENTO = COALESCE(#{tipoDocumento,jdbcType=VARCHAR},BENE_TIPO_DOCUMENTO) AND"
			+ " BENE_NUMERO_DOCUMENTO = COALESCE(#{numeroDocumento,jdbcType=VARCHAR},BENE_NUMERO_DOCUMENTO) AND"
			+ " BENE_ESTADO = COALESCE(#{estadoBneficiario,jdbcType=VARCHAR},BENE_ESTADO) AND"
			+ " BENE_NOMBRE LIKE '%' + COALESCE(#{nombre,jdbcType=VARCHAR},BENE_NOMBRE) + '%' AND"
			+ " BENE_APELLIDO_PATERNO LIKE '%' + COALESCE(#{apellidoPaterno,jdbcType=VARCHAR},BENE_APELLIDO_PATERNO) + '%' AND"
			+ " BENE_APELLIDO_MATERNO LIKE '%' + COALESCE(#{apellidoMaterno,jdbcType=VARCHAR},BENE_APELLIDO_MATERNO) + '%' ";
	
	final String UPDATE_BENEFICIARIO_LOTE_ID=""
			+ " UPDATE SINI_MANUAL"
			+ " SET bene_lote_id = #{loteId,jdbcType=NVARCHAR}"
			+ " ,bene_usuario_modifica = #{usuario,jdbcType=VARCHAR}"
			+ " ,bene_fecha_modificacion = GETDATE()"
			+ " WHERE"
			+ " LTRIM(RTRIM(siniestro_id))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_PATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_MATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_NOMBRE,' ','')))))=UPPER(#{nombres,jdbcType=VARCHAR})";
	
	final String SELECT_BY_SINIESTRO_NOMBRE="SELECT "
			+ ""
			+ "bene_tipo_documento"
			+ ",bene_numero_documento"
			+ ",bene_direccion"
			+ " FROM SINI_MANUAL"
			+ " WHERE"
			+ " LTRIM(RTRIM(siniestro_id))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_PATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_MATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_NOMBRE,' ','')))))=UPPER(#{nombres,jdbcType=VARCHAR})";
	
	final String UPDATE_SINI_MANUAL_BY_ASIGNA="UPDATE dbo.SINI_MANUAL SET"
			+ " bene_fecha_asigna_firmantes=GETDATE()"
			+ " ,bene_usuario_modifica = #{usuario,jdbcType=VARCHAR}"
			+ " ,bene_fecha_modificacion = GETDATE()"
			+ " WHERE"
			+ " LTRIM(RTRIM(bene_lote_id)) = #{loteId,jdbcType=NVARCHAR}"
			+ "";
	
	final String UPDATE_SINIESTRO_FECHA_PROVISIONADO=""
			+ " UPDATE SINI_MANUAL"
			+ " SET bene_fecha_provisionado = #{beneFechaProvisionado,jdbcType=DATE}"
			+ " ,bene_estado='02'"
			+ " ,bene_usuario_modifica = #{usuario,jdbcType=VARCHAR}"
			+ " ,bene_fecha_modificacion = GETDATE()"
			+ " WHERE"
			+ " LTRIM(RTRIM(siniestro_id))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_PATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_MATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_NOMBRE,' ','')))))=UPPER(#{nombres,jdbcType=VARCHAR})"
			+ " AND bene_monto_pagar=#{beneMontoPagar,javaType=double,jdbcType=NUMERIC}"
			+ " AND bene_fecha_provisionado IS NULL";

	final String UPDATE_SINIESTRO_FECHA_REGISTRO_PAGO=""
			+ " UPDATE SINI_MANUAL"
			+ " SET bene_fecha_registro_pago = GETDATE()"
			+ " ,bene_estado='03'"
			+ " ,bene_usuario_modifica = #{usuario,jdbcType=VARCHAR}"
			+ " ,bene_fecha_modificacion = GETDATE()"
			+ " WHERE"
			+ " LTRIM(RTRIM(siniestro_id))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_PATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_APELLIDO_MATERNO,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BENE_NOMBRE,' ','')))))=UPPER(#{nombres,jdbcType=VARCHAR})"
			+ " AND bene_monto_pagar=#{beneMontoPagar,javaType=double,jdbcType=NUMERIC}"
			+ " AND bene_fecha_registro_pago IS NULL";
	
	
			
	public int createSiniManual(SiniManual siniManual);
	
	@Update(UPDATE_SINI_MANUAL)
	public int updateSiniManual(SiniManual siniManual);
	
	@Delete(DELETE_SINI_MANUAL)
	public int deleteSiniManual(SiniManual siniManual);
	
	@Select(SELECT_GET_ALL_FILTER)
	@ResultMap("BaseResultMap")
	public List<SiniManual> getAllSiniManualByFilter(@Param("tipoRamo") String tipoRamo,@Param("fecInicioCarga") Date fecInicioCarga,
			@Param("fecFinCarga") Date fecFinCarga,
			@Param("numeroSiniestro") String idSiniestro,@Param("tipoDocumento") String tipoDocumento,
			@Param("numeroDocumento") String numeroDocumento,@Param("nombre") String nombre,
			@Param("apellidoPaterno") String apellidoPaterno,@Param("apellidoMaterno") String apellidoMaterno,
			@Param("estadoBneficiario") String estadoBeneficiario);
	
	
	
	@Update(UPDATE_BENEFICIARIO_LOTE_ID)
	 public void updateBeneficiarioLoteId(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres,@Param("loteId") String loteId
			 ,@Param("usuario") String usuario);
	
	@Select(SELECT_BY_SINIESTRO_NOMBRE)
	@ResultMap("BaseResultMap")
	public SiniManual getSiniManualBySiniestroNombre(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres);
	
	@Update(UPDATE_SINI_MANUAL_BY_ASIGNA)
	 public void updateBeneficiarioManualFechaAsigna(@Param("loteId") String loteId
			 ,@Param("usuario") String usuario);
	
	@Select(UPDATE_SINIESTRO_FECHA_PROVISIONADO)
	@ResultMap("BaseResultMap")
	public void updateSiniestroFechaProvisionado(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres,@Param("beneMontoPagar") double beneMontoPagar,@Param("beneFechaProvisionado") Date beneFechaProvisionado,@Param("usuario") String usuario);
	
	@Select(UPDATE_SINIESTRO_FECHA_REGISTRO_PAGO)
	@ResultMap("BaseResultMap")
	public void updateSiniestroFechaRegistroPago(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres,@Param("beneMontoPagar") double beneMontoPagar,@Param("usuario") String usuario);
	
	public int validarExisteLoteIdArchConf_SM(@Param("loteId") String loteId);
	
	final String UPDATE_BENE_TRAMA_CONF = 		
			" UPDATE SINI_MANUAL SET bene_fecha_procesado = GETDATE(), bene_estado = #{beneSiniEstado,jdbcType=NVARCHAR} " +  
			" WHERE bene_numero_documento = #{beneNumDoc,jdbcType=NVARCHAR} AND SUBSTRING(bene_lote_id, 1, 8) = #{numLoteSerie,jdbcType=NVARCHAR} ";
	
	@Select(UPDATE_BENE_TRAMA_CONF)
	public void updateBeneTramaConfirmados(@Param("beneSiniEstado")String beneSiniEstado, @Param("beneNumDoc")String beneNumDoc, @Param("numLoteSerie")String numLoteSerie);
	
	
	final String UPDATE_BENE_TRAMA_COBROS =
			" UPDATE SINI_MANUAL SET bene_fecha_cobro = GETDATE(), bene_estado = #{beneSiniEstado,jdbcType=NVARCHAR} " +  
			" WHERE bene_numero_documento = #{beneNumDoc,jdbcType=NVARCHAR} AND cast(cast(bene_monto_pagar as DECIMAL(14,2)) as varchar(17)) = #{beneMonto,jdbcType=NVARCHAR} ";

	@Select(UPDATE_BENE_TRAMA_COBROS)
	public void updateBeneTramaCobrados(@Param("beneSiniEstado")String beneSiniEstado, @Param("beneNumDoc")String beneNumDoc, @Param("beneMonto")String beneMonto);
	
	
}
