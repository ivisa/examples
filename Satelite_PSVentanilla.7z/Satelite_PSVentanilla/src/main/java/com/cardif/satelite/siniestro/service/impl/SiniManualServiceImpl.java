package com.cardif.satelite.siniestro.service.impl;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;





import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.siniestro.dao.SiniManualMapper;
import com.cardif.satelite.siniestro.model.SiniManual;
import com.cardif.satelite.siniestro.service.SiniManualService;

@Service("siniManualService")
public class SiniManualServiceImpl implements SiniManualService {
	public static final Logger log = Logger
			.getLogger(SiniManualServiceImpl.class);

	@Autowired
	private SiniManualMapper siniManualMapper;
	@Autowired
	private ParametroService parametroService;

	@Override
	public int createSiniManual(SiniManual siniManual) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		try {
			if (siniManual != null) {
				siniManualMapper.createSiniManual(siniManual);
			} else {
				log.error("El objeto siniManual es nulo");
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_INSERTAR);
		}

		log.info("Fin");
		return 0;
	}

	@Override
	public int updateSiniManual(SiniManual siniManual) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		try {
			if (siniManual != null) {
				siniManualMapper.updateSiniManual(siniManual);
			} else {
				log.error("El objeto siniManual es nulo");
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}

		log.info("Fin");
		return 0;
	}

	@Override
	public int deleteSiniManual(SiniManual siniManual) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		try {
			if (siniManual != null) {
				siniManualMapper.deleteSiniManual(siniManual);
			} else {
				log.error("El objeto siniManual es nulo");
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ELIMINAR);
		}

		log.info("Fin");
		return 0;
	}


	@Override
	public void createAllSiniManual(List<SiniManual> listSiniManual)
			throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio createAllSiniManual");
		List<Parametro> listaRamos=new ArrayList<Parametro>();
		try {
			listaRamos.addAll(parametroService.buscar(Constantes.COD_PARAM_SINIESTRO_MANUAL, Constantes.TIP_PARAM_DETALLE));
			for (SiniManual siniManual : listSiniManual) {
				if(siniManual.getSiniestroId().trim().substring(0, 2).compareTo(listaRamos.get(0).getCodValor())==0 ||
						siniManual.getSiniestroId().trim().substring(0, 2).compareTo(listaRamos.get(1).getCodValor())==0){
				createSiniManual(siniManual);
				}
			}
			log.info("Fin createAllSiniManual");
		} catch (SyncconException e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_INSERTAR);
		}
	}

	@Override
	public List<SiniManual> getAllSiniManualByFilter(String ramo,
			Date fecInicioCarga,
			Date fecFinCarga, String idSiniestro, String tipoDocumento,
			String numeroDocumento, String nombre, String apellidoPaterno,
			String apellidoMaterno, String estadoBeneficiario)
			throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio getAllSiniManualByFilter");
		log.info("ramo: "+ ramo);
		log.info("fecInicioCarga: "+ fecInicioCarga);
		log.info("fecFinCarga: "+ fecFinCarga);
		log.info("idSiniestro: "+ idSiniestro);
		log.info("tipoDocumento: "+ tipoDocumento);
		log.info("numeroDocumento: "+ numeroDocumento);
		log.info("estadoBeneficiario: "+ estadoBeneficiario);

	    List<SiniManual> lista = null;
	    try {
	      lista = siniManualMapper.getAllSiniManualByFilter(ramo, fecInicioCarga,fecFinCarga, idSiniestro, tipoDocumento, numeroDocumento, nombre, apellidoPaterno, apellidoMaterno, estadoBeneficiario);
	    } catch (Exception e) {
	      log.error(e.getMessage(), e);
	      throw new SyncconException(ErrorConstants.COD_ERROR_BD_BUSCAR);
	    }
	    log.info("Fin getAllSiniManualByFilter");
	    return lista;
	}

	@Override
	public void updateBeneficiarioLoteId(String siniestroId, String nombres,
			String loteId, String usuario) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		try {
			
			log.debug("siniestroId: "+ siniestroId);
			log.debug("nombres: "+ nombres);
			log.debug("loteId: "+ loteId);
			log.debug("usuario: "+ usuario);
			siniManualMapper.updateBeneficiarioLoteId(siniestroId, nombres, loteId, usuario);		

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}

		log.info("Fin");
	}

	@Override
	public SiniManual getSiniManualBySiniestroNombre(
			String siniestroId, String nombres) throws SyncconException {
		// TODO Auto-generated method stub
		log.debug("Inicio");
		log.debug("siniestroId: "+ siniestroId);
		log.debug("nombres: "+ nombres);

	    SiniManual lista=null;
	    try {
	      lista = siniManualMapper.getSiniManualBySiniestroNombre(siniestroId, nombres);
	    } catch (Exception e) {
	      log.error(e.getMessage(), e);
	      throw new SyncconException(ErrorConstants.COD_ERROR_BD_BUSCAR);
	    }
	    log.info("Fin");
	    return lista;
	}

	@Override
	public void updateBeneficiarioFechaAsigna(String loteId, String usuario) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		try {
			
			log.debug("loteId: "+ loteId);
			log.debug("usuario: "+ usuario);
			siniManualMapper.updateBeneficiarioManualFechaAsigna(loteId, usuario);		

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}

		log.info("Fin");
	}

	@Override
	public void updateListaManualBeneficiarioFechaAsigna(List<String> loteId, String usuario) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		try {
			
			for(String nroLote:loteId){
				updateBeneficiarioFechaAsigna(nroLote, usuario);
			}	

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}

		log.info("Fin");
	}

}
