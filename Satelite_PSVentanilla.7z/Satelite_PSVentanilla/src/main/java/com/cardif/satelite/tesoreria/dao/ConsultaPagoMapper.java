package com.cardif.satelite.tesoreria.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;

import com.cardif.satelite.siniestro.model.SiniManual;
import com.cardif.satelite.tesoreria.bean.ConsultaPagoResultado;

public interface ConsultaPagoMapper {
	final String SP_SINI_GENERA_LOTE ="{ CALL USP_SINI_LOTES_GENERA( #{anio, mode=IN, jdbcType=INTEGER},#{moneda, mode=IN, jdbcType=VARCHAR},#{usuario, mode=IN, jdbcType=VARCHAR},#{resultado, mode=OUT, jdbcType=VARCHAR} ) } ";
	final String DELETE_SINI_GENERA_LOTE="DELETE FROM dbo.SINI_LOTE_GENERA WHERE"
			+ " LTRIM(RTRIM(loteId)) = #{loteId,jdbcType=NVARCHAR} ";
	
	 @Select(value=SP_SINI_GENERA_LOTE)
	 @Options(statementType = StatementType.CALLABLE)
	 public void obtenerNumeroDeLote(ConsultaPagoResultado consultaPagoResultado);
	 
	 @Delete(DELETE_SINI_GENERA_LOTE)
	 public int deleteSiniGeneraLote(@Param("loteId") String loteId);
	  
}
