package com.cardif.satelite.siniestro.controller;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import static com.cardif.satelite.constantes.Constantes.TIP_PARAM_DETALLE;
import static com.cardif.satelite.constantes.ErrorConstants.ERROR_SYNCCON;
import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR;
import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import org.richfaces.model.selection.SimpleSelection;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.ServletContext;

import net.sf.jxls.transformer.XLSTransformer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;

import javax.annotation.PostConstruct;
import javax.faces.model.SelectItem;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.SyncconException;

import org.apache.log4j.Logger;

import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.model.SiniProducto;
import com.cardif.satelite.model.satelite.BeneficiarioSiniestro;
import com.cardif.satelite.siniestro.bean.ConsultaSiniestro;
import com.cardif.satelite.siniestro.service.SiniBeneficiariosService;
import com.cardif.satelite.siniestro.service.SiniProductoService;
import com.cardif.satelite.siniestro.service.SiniSiniestroService;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;


@Scope("request")
@Controller("repConsultaSiniBENEFICIARIOController")
public class RepConsultaSiniBENEFICIARIOController extends BaseController
{
	private final Logger logger = Logger.getLogger(RepConsultaSiniBENEFICIARIOController.class);
	
	@Autowired
	private ParametroService parametroService;
	
    @Autowired
    private SiniProductoService siniProductoService;
    
    @Autowired
    private SiniSiniestroService siniSiniestroService;
    
    @Autowired
    private SiniBeneficiariosService siniBeneficiariosService;
    
    
	
	private List<BeneficiarioSiniestro> listaSiniBeneficiario;
	
	private List<BeneficiarioSiniestro> varlista;
	
	private SimpleSelection selection;
	
	private String nroSiniestro;
	private Date fecIniNotific;
	private Date fecFinNotific;
	private Date fecIniUltDoc;
	private Date fecFinUltDoc;
	private Date fecIniAprobRecha;
	private Date fecFinAprobRecha;
	private Date fecIniEntregaOp;
	private Date fecFinEntregaOp;
	private String pagoIni;
	private String pagoFin;
	private String nroPlanilla;
	private String tipoSeguroId;
	private String socioId;
	private String productoId;
	private String nroPoliza;
	private String estadoId;
	private String nroDoc;
	private String coberAfecId;
	private String nombres;
	private String apePaterno;
	private String apeMaterno;
	
	private Boolean checkAll = false;
	
	private List<SelectItem> listaTipoSeguroItem;
	private List<SelectItem> listaSocioItem;
	private List<SelectItem> listaProductoItem;
	private List<SelectItem> listaEstadoItem;
	private List<SelectItem> listaCoberturaAfecItem;
	
	//Filtros beneficiario
	private String tipoDocBeneId;
	private String nroDocBene;
	private Date fecIniEntregaOpBene;
	private Date fecFinEntregaOpBene;
	private String estadoBeneId;
	private String nombresBene;
	private String apePaternoBene;
	private String apeMaternoBene;
	
	private List<SelectItem> listaTipoDocBeneItem;
	private List<SelectItem> listaEstadoBeneItem;
	
	//variables auxiliares
	private String nroRegistros;
	private Boolean disabledBtnExportar;
	
	private Boolean disabledCheckAll = true;
	
	
	@PostConstruct
	@Override
	public String inicio()
	{
		if (logger.isDebugEnabled()) {logger.debug("inicio()");}
		String respuesta = null;
		
		try {
			if (!tieneAcceso())
			{
				if (logger.isDebugEnabled()) {logger.debug("No cuenta con los accesos necesarios.");}
				return "accesoDenegado";
			}
			
			/*** lista de Tipos de Seguros ***************/
			List<Parametro> listaTipoSeguro = parametroService.buscar(Constantes.COD_PARAM_LISTA_SEGUROS, TIP_PARAM_DETALLE);
			listaTipoSeguroItem = new ArrayList<SelectItem>();
			listaTipoSeguroItem.add(new SelectItem("", "- Seleccionar -"));
			for (Parametro p : listaTipoSeguro) {
				listaTipoSeguroItem.add(new SelectItem(p.getCodValor(), p.getNomValor()));
			}
		     
		     
			/*** lista de socios ***************/
			List<Parametro> listaSocio = parametroService.buscar(Constantes.COD_PARAM_SOCIOS_SINI, TIP_PARAM_DETALLE);
			listaSocioItem = new ArrayList<SelectItem>();
			listaSocioItem.add(new SelectItem("", "- Seleccionar -"));
			for (Parametro p : listaSocio) {
				listaSocioItem.add(new SelectItem(p.getCodValor(), p.getNomValor()));
			}
			
			/*** lista de productos ***************/
			List<SiniProducto> listaProducto = siniProductoService.listar();
			listaProductoItem = new ArrayList<SelectItem>();
			listaProductoItem.add(new SelectItem("", "- Seleccionar -"));
			for (SiniProducto p : listaProducto) {
				listaProductoItem.add(new SelectItem(p.getNroProducto(), p.getNomProducto()));
			}
			
			/*** lista de coberturas afectadas ***************/
			List<Parametro> listaCoberturasAfec = parametroService.buscar(Constantes.COD_PARAM_LISTA_COBERTURA, TIP_PARAM_DETALLE);
			listaCoberturaAfecItem = new ArrayList<SelectItem>();
			listaCoberturaAfecItem.add(new SelectItem("", "- Seleccionar -"));
			for (Parametro p : listaCoberturasAfec) {
				listaCoberturaAfecItem.add(new SelectItem(p.getCodValor(), p.getNomValor()));
			}
			
			/*** lista estado Siniestro ***************/
			List<Parametro> listaEstados = parametroService.buscar(Constantes.COD_PARAM_LISTA_ESTADOS, TIP_PARAM_DETALLE);
			listaEstadoItem = new ArrayList<SelectItem>();
			listaEstadoItem.add(new SelectItem("", "- Seleccionar -"));
			for (Parametro p : listaEstados) {
				listaEstadoItem.add(new SelectItem(p.getCodValor(), p.getNomValor()));
			}
			
			/*** lista estado Beneficiario ***************/
			listaEstadoBeneItem = new ArrayList<SelectItem>();
			List<Parametro> listaEstadosBeneficiario = parametroService.buscar(Constantes.COD_PARAM_ESTADO_BENEFICIARIO, TIP_PARAM_DETALLE);
			listaEstadoBeneItem.add(new SelectItem("", "- Seleccionar -"));
			for (Parametro p : listaEstadosBeneficiario) {
				listaEstadoBeneItem.add(new SelectItem(p.getCodValor(), p.getNomValor()));
			}
			
			
			
			/*** lista de tipo de Documento ***************/
			List<Parametro> listaTipoDoc = parametroService.buscar(Constantes.COD_PARAM_TIPOS_DOCUMENTO_SINI, TIP_PARAM_DETALLE);
			listaTipoDocBeneItem = new ArrayList<SelectItem>();
			listaTipoDocBeneItem.add(new SelectItem("", "- Seleccionar -"));
			for (Parametro p : listaTipoDoc) {
				listaTipoDocBeneItem.add(new SelectItem(p.getCodValor(), p.getNomValor()));
			}
			
			disabledBtnExportar = true;
		
		} catch (SyncconException ex) {
		      logger.error(ERROR_SYNCCON + ex.getMessageComplete());
		      FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
		      FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
		      logger.error(e.getMessage(), e);
		      FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
		      FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		      respuesta = MSJ_ERROR;
		}
		
		
		if (logger.isDebugEnabled()) {logger.debug("inicio()");}
		return respuesta;
	}
	
	
	public String procesarConsulta(){
		if (logger.isInfoEnabled()) {logger.info("Inicio");}
		String respuesta = null;
		
		try
		{
			
			//Validacion de filtros Siniestro
			
			//Fecha de notificacion
			if(fecIniNotific != null && fecFinNotific != null){
				if(!Utilitarios.validarFechasInicioFin(fecIniNotific, fecFinNotific)){
					SateliteUtil.mostrarMensaje("La fecha de notificación inicial no puede ser mayor a la final.");
					return respuesta;
				}
			}
			
			//Fecha de Ultimo documento
			if(fecIniUltDoc != null && fecFinUltDoc != null){
				if(!Utilitarios.validarFechasInicioFin(fecIniUltDoc, fecFinUltDoc)){
					SateliteUtil.mostrarMensaje("La fecha de Último Documento inicial no puede ser mayor a la final.");
					return respuesta;
				}
			}
			
			//Fecha Aprob/Rechazo
			if(fecIniAprobRecha != null && fecFinAprobRecha != null){
				if(!Utilitarios.validarFechasInicioFin(fecIniAprobRecha, fecFinAprobRecha)){
					SateliteUtil.mostrarMensaje("La fecha de Aprob/Rechazo inicial no puede ser mayor a la final.");
					return respuesta;
				}
			}

			//Fecha Entrega Opc
			if(fecIniEntregaOp != null && fecFinEntregaOp != null){
				if(!Utilitarios.validarFechasInicioFin(fecIniEntregaOp, fecFinEntregaOp)){
					SateliteUtil.mostrarMensaje("La fecha de Entrega Op. inicial no puede ser mayor a la final.");
					return respuesta;
				}
			}
			
			//Pago
			if(StringUtils.isNotBlank(pagoIni) || StringUtils.isNotBlank(pagoFin)){
				
				BigDecimal valor1 = new BigDecimal("0");
				BigDecimal valor2 = new BigDecimal("0");
				
				try{
					
					if(StringUtils.isNotBlank(pagoIni)){
						valor1 = new BigDecimal(pagoIni);
					}
					
					if(StringUtils.isNotBlank(pagoFin)){
						valor2 = new BigDecimal(pagoFin);
					}
					
				}catch(Exception e){
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Montos no múmericos en el campo Pago.");
					return respuesta;
				}
				
				if(valor1.compareTo(BigDecimal.ZERO) == 0){
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Rango de Pago Inicial tiene que se mayor a cero.");
					return respuesta;
				}
				
				if(StringUtils.isNotBlank(pagoIni) && StringUtils.isNotBlank(pagoFin)){
					if(valor1.compareTo(valor2) > 0){
						SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Rango de Pago Inicial no puede ser mayor al rango de Pago final.");
						return respuesta;
					}
				} 
				
			}
			
			//Validacion de filtros Beneficiario
			
			//Fecha Entrega Opc
			if(fecIniEntregaOpBene != null && fecFinEntregaOpBene != null){
				if(!Utilitarios.validarFechasInicioFin(fecIniEntregaOpBene, fecFinEntregaOpBene)){
					SateliteUtil.mostrarMensaje("La fecha de Entrega Op. inicial no puede ser mayor a la final.");
					return respuesta;
				}
			}
			
			
			//Invocacion al query
			this.listaSiniBeneficiario = siniSiniestroService.buscarConBeneficiario(nroSiniestro, fecIniNotific, fecFinNotific, fecIniUltDoc, 
					  																fecFinUltDoc, fecIniAprobRecha, fecFinAprobRecha, fecIniEntregaOp,
					  																fecFinEntregaOp, pagoIni, pagoFin, nroPlanilla, tipoSeguroId,
					  																socioId, productoId, nroPoliza, estadoId, nroDoc, coberAfecId,
					  																nombres, apePaterno, apeMaterno, //beneficiario
					  																tipoDocBeneId, validacionEspaciosEnBlanco(nroDocBene), fecIniEntregaOpBene, fecFinEntregaOpBene,
					  																estadoBeneId, validacionEspaciosEnBlanco(nombresBene), validacionEspaciosEnBlanco(apePaternoBene), 
					  																validacionEspaciosEnBlanco(apeMaternoBene));
			
			nroRegistros = String.valueOf(this.listaSiniBeneficiario.size());
			
			disabledBtnExportar = (this.listaSiniBeneficiario.size() > 0) ? false : true;
			
			varlista = new ArrayList<BeneficiarioSiniestro>();
			
			checkAll = false;
			
			this.disabledCheckAll = false;
			
			if(this.listaSiniBeneficiario.size() == 0){
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"No se encontraron datos para la búsqueda.");
			}
			
		}	
		catch (SyncconException e)
		{
			logger.error("SyncconException() - " + ErrorConstants.ERROR_SYNCCON + e.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(e.getSeveridad(), e.getMessage(), null);
	    	FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		catch (Exception e)
		{
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		if (logger.isInfoEnabled()) {logger.info("Fin");}
		return respuesta;
	}
	
	public String validacionEspaciosEnBlanco(String value){
		return (StringUtils.isNotBlank(value) ? value.trim() : value);
	}
	
	public void limpiarDatosInput(){
		
		nroSiniestro = "";
		fecIniNotific = null;
		fecFinNotific = null;
		fecIniUltDoc = null;
		fecFinUltDoc= null;
		fecIniAprobRecha = null;
		fecFinAprobRecha = null;
		fecIniEntregaOp = null;
		fecFinEntregaOp = null;
		pagoIni = "";
		pagoFin = "";
		nroPlanilla = "";
		tipoSeguroId = "";
		socioId = "";
		productoId = "";
		nroPoliza = "";
		estadoId = "";
		nroDoc = "";
		coberAfecId = "";
		nombres = "";
		apePaterno = "";
		apeMaterno = "";
		
		nroRegistros = "0";
		this.listaSiniBeneficiario = new ArrayList<BeneficiarioSiniestro>();
		disabledBtnExportar = true;
		
		this.disabledCheckAll = true;
		
	}

	
	public String exportarBtnOpContables(){

		if (logger.isInfoEnabled()) {logger.info("Inicio");}
		String respuesta = null;
		List<BeneficiarioSiniestro> varListaExportar = new ArrayList<BeneficiarioSiniestro>();
		
		try
		{
			Map<String, Object> beans = new HashMap<String, Object>();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			
			ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();
			String fechaActual = sdf.format(new Date(System.currentTimeMillis()));
			
			int count = 0;
		    for (BeneficiarioSiniestro cheque : listaSiniBeneficiario) {
			      if (cheque.isIdCheck()) {
			        count++;
			      }
			}
		    
		    if(count > 0){
		    	varListaExportar.addAll(varlista);
		    }else{
		    	varListaExportar.addAll(listaSiniBeneficiario);
		    }
			
//			if (null != varlista && 0 < varlista.size())
//			{
				String rutaTemp = System.getProperty("java.io.tmpdir") + "Reporte_Siniestro_Beneficiarios" + fechaActual + ".xls";
		        if (logger.isDebugEnabled()) {logger.debug("Ruta Archivo: " + rutaTemp);}
		        
		        FacesContext facesContext = FacesContext.getCurrentInstance();
		        ServletContext servletContext = (ServletContext) facesContext.getExternalContext().getContext();
		        
		        String rutaTemplate = "";
		        
	        	rutaTemplate = servletContext.getRealPath(File.separator + "excel" + File.separator + "template_exportar_siniestro_beneficiario.xls");
		        
		        
		        if (logger.isDebugEnabled()) {logger.debug("Ruta del Template: " + rutaTemplate);}
		        
		        beans.put("exportar", this.varlista);
		        
		        XLSTransformer transformer = new XLSTransformer();
		        transformer.transformXLS(rutaTemplate, beans, rutaTemp);
				
		        File archivoResp = new File(rutaTemp);
		        FileInputStream fis = new FileInputStream(archivoResp);
		        
		        HttpServletResponse response = (HttpServletResponse) contexto.getResponse();
		        byte[] loader = new byte[(int) archivoResp.length()];
		        response.addHeader("Content-Disposition", "attachment;filename=" + "Reporte_Siniestro_Beneficiarios" + fechaActual + ".xls");
		        response.setContentType("application/vnd.ms-excel");
				
		        ServletOutputStream sos = response.getOutputStream();
		        
		        while ((fis.read(loader)) > 0)
		        {
		        	sos.write(loader, 0, loader.length);
		        }
		        
		        fis.close();
		        sos.close();
		        
		        FacesContext.getCurrentInstance().responseComplete();
		        if (logger.isDebugEnabled()) {logger.debug("Exportacion culminada.");}
		        
		        //Actualizar la fecha de env. op. contable
		        siniBeneficiariosService.updateBeneficiarioFecOpContable(varlista);
		        
//		        varlista = null;
		        
		        varListaExportar = null;
		        
		        disabledBtnExportar = false;
//			}
//			else
//			{
//				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Seleccionar registros de la grilla.");
//			}
		}
		catch (SyncconException e)
		{
			logger.error("SyncconException() - " + ErrorConstants.ERROR_SYNCCON + e.getMessageComplete());
			logger.error("SyncconException() -->" + ExceptionUtils.getStackTrace(e));
			FacesMessage facesMsg = new FacesMessage(e.getSeveridad(), e.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		catch (Exception e)
		{
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		if (logger.isInfoEnabled()) {logger.info("Fin");}
		return respuesta;
	
	}
	
	public String exportarBtnGenerarReporte(){

		if (logger.isInfoEnabled()) {logger.info("Inicio");}
		String respuesta = null;
		List<BeneficiarioSiniestro> varListaExportar = new ArrayList<BeneficiarioSiniestro>();
		
		try
		{
			Map<String, Object> beans = new HashMap<String, Object>();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			
			ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();
			String fechaActual = sdf.format(new Date(System.currentTimeMillis()));
			
			int count = 0;
		    for (BeneficiarioSiniestro cheque : listaSiniBeneficiario) {
			      if (cheque.isIdCheck()) {
			        count++;
			      }
			}
		    
		    if(count > 0){
		    	varListaExportar.addAll(varlista);
		    }else{
		    	varListaExportar.addAll(listaSiniBeneficiario);
		    }
			
//			if (null != varlista && 0 < varlista.size())
//			{
				String rutaTemp = System.getProperty("java.io.tmpdir") + "Reporte_Siniestro_Beneficiarios" + fechaActual + ".xls";
		        if (logger.isDebugEnabled()) {logger.debug("Ruta Archivo: " + rutaTemp);}
		        
		        FacesContext facesContext = FacesContext.getCurrentInstance();
		        ServletContext servletContext = (ServletContext) facesContext.getExternalContext().getContext();
		        
		        String rutaTemplate = "";
		        
	        	rutaTemplate = servletContext.getRealPath(File.separator + "excel" + File.separator + "template_exportar_siniestro_beneficiario.xls");
		        
		        
		        if (logger.isDebugEnabled()) {logger.debug("Ruta del Template: " + rutaTemplate);}
		        
		        beans.put("exportar", varListaExportar);
		        
		        XLSTransformer transformer = new XLSTransformer();
		        transformer.transformXLS(rutaTemplate, beans, rutaTemp);
				
		        File archivoResp = new File(rutaTemp);
		        FileInputStream fis = new FileInputStream(archivoResp);
		        
		        HttpServletResponse response = (HttpServletResponse) contexto.getResponse();
		        byte[] loader = new byte[(int) archivoResp.length()];
		        response.addHeader("Content-Disposition", "attachment;filename=" + "Reporte_Siniestro_Beneficiarios" + fechaActual + ".xls");
		        response.setContentType("application/vnd.ms-excel");
				
		        ServletOutputStream sos = response.getOutputStream();
		        
		        while ((fis.read(loader)) > 0)
		        {
		        	sos.write(loader, 0, loader.length);
		        }
		        
		        fis.close();
		        sos.close();
		        
		        FacesContext.getCurrentInstance().responseComplete();
		        if (logger.isDebugEnabled()) {logger.debug("Exportacion culminada.");}
		        
//		        varlista = null;
		        
		        varListaExportar = null;
		        
		        disabledBtnExportar = false;
//			}
//			else
//			{
//				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Seleccionar registros de la grilla.");
//			}
		}
//		catch (SyncconException e)
//		{
//			logger.error("SyncconException() - " + ErrorConstants.ERROR_SYNCCON + e.getMessageComplete());
//			logger.error("SyncconException() -->" + ExceptionUtils.getStackTrace(e));
//			FacesMessage facesMsg = new FacesMessage(e.getSeveridad(), e.getMessage(), null);
//			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
//		}
		catch (Exception e)
		{
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		if (logger.isInfoEnabled()) {logger.info("Fin");}
		return respuesta;
	
	}	

	 public void selectionListener() {
		 if (logger.isInfoEnabled()) {logger.info("Inicio");}
//		    Iterator<Object> iterator = null;
//		    String pk = null;
//		    iterator = getSelection().getKeys(); // getSiniestroSelection().getKeys();//
//		    String valorCheck = (String) event.getComponent().getAttributes().get("selectedSiniestro");

		    List<BeneficiarioSiniestro> siniestroSeleccionados = new ArrayList<BeneficiarioSiniestro>();
		    for (BeneficiarioSiniestro cheque : listaSiniBeneficiario) {
		      if (cheque.isIdCheck()) {
		        siniestroSeleccionados.add(cheque);
		      }
		    }
		    varlista = siniestroSeleccionados;
		    
//		    if(varlista != null && varlista.size() > 0){
//		    	disabledBtnExportar = false;
//		    }else{
//		    	disabledBtnExportar = true;
//		    }
		    
		    this.disabledCheckAll = false;
		    
		    
		 if (logger.isInfoEnabled()) {logger.info("Fin");}
	}
	
	 public void selectionListenerAll() {
		 if (logger.isInfoEnabled()) {logger.info("Inicio");}
		 if(listaSiniBeneficiario != null && listaSiniBeneficiario.size() > 0){
			 List<BeneficiarioSiniestro> siniestroSeleccionados = new ArrayList<BeneficiarioSiniestro>();
			 	if(checkAll){
				    for (BeneficiarioSiniestro cheque : listaSiniBeneficiario) {
				    	cheque.setIdCheck(true);
				        siniestroSeleccionados.add(cheque);
				    }
				    
			 	}else{		 		
				    for (BeneficiarioSiniestro cheque : listaSiniBeneficiario) {
				    	cheque.setIdCheck(false);
				        siniestroSeleccionados.add(cheque);
				    }
			 	}
			    
			    varlista = siniestroSeleccionados;
			    
//			    if(checkAll && (varlista != null && varlista.size() > 0)){
//			    	disabledBtnExportar = false;
//			    }else{
//			    	disabledBtnExportar = true;
//			    }
			    
			    if(varlista != null && varlista.size() > 0){
			    	disabledBtnExportar = false;
			    }else{
			    	disabledBtnExportar = true;
			    }
		 }
		 if (logger.isInfoEnabled()) {logger.info("Fin");}
	}
	

	public List<BeneficiarioSiniestro> getListaSiniBeneficiario() {
		return listaSiniBeneficiario;
	}


	public void setListaSiniBeneficiario(List<BeneficiarioSiniestro> listaSiniBeneficiario) {
		this.listaSiniBeneficiario = listaSiniBeneficiario;
	}


	public String getNroSiniestro() {
		return nroSiniestro;
	}


	public void setNroSiniestro(String nroSiniestro) {
		this.nroSiniestro = nroSiniestro;
	}


	public Date getFecIniNotific() {
		return fecIniNotific;
	}


	public void setFecIniNotific(Date fecIniNotific) {
		this.fecIniNotific = fecIniNotific;
	}


	public Date getFecFinNotific() {
		return fecFinNotific;
	}


	public void setFecFinNotific(Date fecFinNotific) {
		this.fecFinNotific = fecFinNotific;
	}


	public Date getFecIniUltDoc() {
		return fecIniUltDoc;
	}


	public void setFecIniUltDoc(Date fecIniUltDoc) {
		this.fecIniUltDoc = fecIniUltDoc;
	}


	public Date getFecFinUltDoc() {
		return fecFinUltDoc;
	}


	public void setFecFinUltDoc(Date fecFinUltDoc) {
		this.fecFinUltDoc = fecFinUltDoc;
	}


	public Date getFecIniAprobRecha() {
		return fecIniAprobRecha;
	}


	public void setFecIniAprobRecha(Date fecIniAprobRecha) {
		this.fecIniAprobRecha = fecIniAprobRecha;
	}


	public Date getFecFinAprobRecha() {
		return fecFinAprobRecha;
	}


	public void setFecFinAprobRecha(Date fecFinAprobRecha) {
		this.fecFinAprobRecha = fecFinAprobRecha;
	}


	public Date getFecIniEntregaOp() {
		return fecIniEntregaOp;
	}


	public void setFecIniEntregaOp(Date fecIniEntregaOp) {
		this.fecIniEntregaOp = fecIniEntregaOp;
	}


	public Date getFecFinEntregaOp() {
		return fecFinEntregaOp;
	}


	public void setFecFinEntregaOp(Date fecFinEntregaOp) {
		this.fecFinEntregaOp = fecFinEntregaOp;
	}
	

	public String getPagoIni() {
		return pagoIni;
	}


	public void setPagoIni(String pagoIni) {
		this.pagoIni = pagoIni;
	}


	public String getPagoFin() {
		return pagoFin;
	}


	public void setPagoFin(String pagoFin) {
		this.pagoFin = pagoFin;
	}


	public String getNroPlanilla() {
		return nroPlanilla;
	}


	public void setNroPlanilla(String nroPlanilla) {
		this.nroPlanilla = nroPlanilla;
	}


	public String getTipoSeguroId() {
		return tipoSeguroId;
	}


	public void setTipoSeguroId(String tipoSeguroId) {
		this.tipoSeguroId = tipoSeguroId;
	}


	public String getSocioId() {
		return socioId;
	}


	public void setSocioId(String socioId) {
		this.socioId = socioId;
	}


	public String getProductoId() {
		return productoId;
	}


	public void setProductoId(String productoId) {
		this.productoId = productoId;
	}


	public String getNroPoliza() {
		return nroPoliza;
	}


	public void setNroPoliza(String nroPoliza) {
		this.nroPoliza = nroPoliza;
	}


	public String getEstadoId() {
		return estadoId;
	}


	public void setEstadoId(String estadoId) {
		this.estadoId = estadoId;
	}


	public String getNroDoc() {
		return nroDoc;
	}


	public void setNroDoc(String nroDoc) {
		this.nroDoc = nroDoc;
	}


	public String getCoberAfecId() {
		return coberAfecId;
	}


	public void setCoberAfecId(String coberAfecId) {
		this.coberAfecId = coberAfecId;
	}


	public String getNombres() {
		return nombres;
	}


	public void setNombres(String nombres) {
		this.nombres = nombres;
	}


	public String getApePaterno() {
		return apePaterno;
	}


	public void setApePaterno(String apePaterno) {
		this.apePaterno = apePaterno;
	}


	public String getApeMaterno() {
		return apeMaterno;
	}


	public void setApeMaterno(String apeMaterno) {
		this.apeMaterno = apeMaterno;
	}	

	public List<SelectItem> getListaSocioItem() {
		return listaSocioItem;
	}


	public void setListaSocioItem(List<SelectItem> listaSocioItem) {
		this.listaSocioItem = listaSocioItem;
	}

	
	public List<SelectItem> getListaProductoItem() {
		return listaProductoItem;
	}


	public void setListaProductoItem(List<SelectItem> listaProductoItem) {
		this.listaProductoItem = listaProductoItem;
	}

	public List<SelectItem> getListaEstadoItem() {
		return listaEstadoItem;
	}


	public void setListaEstadoItem(List<SelectItem> listaEstadoItem) {
		this.listaEstadoItem = listaEstadoItem;
	}		

	public List<SelectItem> getListaCoberturaAfecItem() {
		return listaCoberturaAfecItem;
	}


	public void setListaCoberturaAfecItem(List<SelectItem> listaCoberturaAfecItem) {
		this.listaCoberturaAfecItem = listaCoberturaAfecItem;
	}


	public String getTipoDocBeneId() {
		return tipoDocBeneId;
	}


	public void setTipoDocBeneId(String tipoDocBeneId) {
		this.tipoDocBeneId = tipoDocBeneId;
	}


	public String getNroDocBene() {
		return nroDocBene;
	}


	public void setNroDocBene(String nroDocBene) {
		this.nroDocBene = nroDocBene;
	}


	public Date getFecIniEntregaOpBene() {
		return fecIniEntregaOpBene;
	}


	public void setFecIniEntregaOpBene(Date fecIniEntregaOpBene) {
		this.fecIniEntregaOpBene = fecIniEntregaOpBene;
	}


	public Date getFecFinEntregaOpBene() {
		return fecFinEntregaOpBene;
	}


	public void setFecFinEntregaOpBene(Date fecFinEntregaOpBene) {
		this.fecFinEntregaOpBene = fecFinEntregaOpBene;
	}


	public String getEstadoBeneId() {
		return estadoBeneId;
	}


	public void setEstadoBeneId(String estadoBeneId) {
		this.estadoBeneId = estadoBeneId;
	}


	public String getNombresBene() {
		return nombresBene;
	}


	public void setNombresBene(String nombresBene) {
		this.nombresBene = nombresBene;
	}


	public String getApePaternoBene() {
		return apePaternoBene;
	}


	public void setApePaternoBene(String apePaternoBene) {
		this.apePaternoBene = apePaternoBene;
	}


	public String getApeMaternoBene() {
		return apeMaternoBene;
	}


	public void setApeMaternoBene(String apeMaternoBene) {
		this.apeMaternoBene = apeMaternoBene;
	}

	public List<SelectItem> getListaTipoDocBeneItem() {
		return listaTipoDocBeneItem;
	}


	public void setListaTipoDocBeneItem(List<SelectItem> listaTipoDocBeneItem) {
		this.listaTipoDocBeneItem = listaTipoDocBeneItem;
	}


	public List<SelectItem> getListaEstadoBeneItem() {
		return listaEstadoBeneItem;
	}


	public void setListaEstadoBeneItem(List<SelectItem> listaEstadoBeneItem) {
		this.listaEstadoBeneItem = listaEstadoBeneItem;
	}

	public String getNroRegistros() {
		return nroRegistros;
	}


	public void setNroRegistros(String nroRegistros) {
		this.nroRegistros = nroRegistros;
	}


	public Boolean getDisabledBtnExportar() {
		return disabledBtnExportar;
	}


	public void setDisabledBtnExportar(Boolean disabledBtnExportar) {
		this.disabledBtnExportar = disabledBtnExportar;
	}


	public List<SelectItem> getListaTipoSeguroItem() {
		return listaTipoSeguroItem;
	}


	public void setListaTipoSeguroItem(List<SelectItem> listaTipoSeguroItem) {
		this.listaTipoSeguroItem = listaTipoSeguroItem;
	}


	public SimpleSelection getSelection() {
		return selection;
	}


	public void setSelection(SimpleSelection selection) {
		this.selection = selection;
	}


	public Boolean getCheckAll() {
		return checkAll;
	}


	public void setCheckAll(Boolean checkAll) {
		this.checkAll = checkAll;
	}


	public Boolean getDisabledCheckAll() {
		return disabledCheckAll;
	}


	public void setDisabledCheckAll(Boolean disabledCheckAll) {
		this.disabledCheckAll = disabledCheckAll;
	}
	
	
	
}
