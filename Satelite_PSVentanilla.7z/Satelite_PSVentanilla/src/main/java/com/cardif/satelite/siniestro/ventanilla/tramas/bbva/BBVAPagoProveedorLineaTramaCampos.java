package com.cardif.satelite.siniestro.ventanilla.tramas.bbva;


	/**
	 * Representacion de campos arbitrarios de la estructura del archivo de incorporación de PAGO A PROVEEDORES del BBVA.
	 *
	 *
	 * @author  Gilder Ali Fonseca S.
	 * @version 1.0, 18/05/2017
	 *
	 */

public class BBVAPagoProveedorLineaTramaCampos {
	
	private String descripcionOrden;
	
	private String tipo;
	
	private String codigo;
	
	public BBVAPagoProveedorLineaTramaCampos(String descripcionOrden, String tipo, String codigo){
		
		this.descripcionOrden = descripcionOrden;
		this.tipo = tipo;
		this.codigo = codigo;
		
	}

	public String getDescripcionOrden() {
		return descripcionOrden;
	}

	public void setDescripcionOrden(String descripcionOrden) {
		this.descripcionOrden = descripcionOrden;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	

}


