package com.cardif.satelite.tesoreria.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.tesoreria.dao.ConsultaPagoBancarioMapper;
import com.cardif.satelite.tesoreria.model.ConsultaPagoBancario;
import com.cardif.satelite.tesoreria.service.ConsultaPagoBancarioService;
import com.cardif.satelite.util.Utilitarios;

@Service("consultaPagoBancarioService")
public class ConsultaPagoBancarioServiceImpl implements ConsultaPagoBancarioService {
	public static final Logger log = Logger.getLogger(ConsultaPagoBancarioServiceImpl.class);

	@Autowired
	private ConsultaPagoBancarioMapper consultaPagoBancarioMapper;
	
	@Override
	public List<ConsultaPagoBancario> buscarPagosBancarios(String tipoTrama,
			String numeroLote, Date fechaCargaInicio, Date fechaCargaFin)
			throws SyncconException {
		log.info("inicio buscarPagosBancarios");
		String tipoSiniestro="";
		String nuevoNumeroLoteFiltro=null;
		if(Utilitarios.getEmptyString(tipoTrama)!=null){
			if(tipoTrama.trim().equals(Constantes.TRAMA_GENERADA_BBVA)){
				tipoSiniestro = Constantes.MASIVO_PAGOS_SINIESTROS;
			}else{
				tipoSiniestro =tipoTrama.trim();
			}
		}
		if(numeroLote!=null){
			nuevoNumeroLoteFiltro=Utilitarios.getEmptyString(numeroLote);
			if(nuevoNumeroLoteFiltro!=null){
				nuevoNumeroLoteFiltro = nuevoNumeroLoteFiltro.trim().concat("%");
			}
		}
		
		log.info("tipoTrama: "+tipoTrama);
		log.info("numeroLote: "+ numeroLote);
		log.info("fechaCargaInicio: "+ fechaCargaInicio);
		log.info("fechaCargaFin: "+ fechaCargaFin);
		List<ConsultaPagoBancario> lista=null;
	    try {
	      lista = consultaPagoBancarioMapper.buscarPagosBancarios(Utilitarios.getEmptyString(tipoTrama),nuevoNumeroLoteFiltro, fechaCargaInicio, fechaCargaFin, Utilitarios.getEmptyString(tipoSiniestro));
	    } catch (Exception e) {
	      log.error(e.getMessage(), e);
	      throw new SyncconException(ErrorConstants.COD_ERROR_BD_BUSCAR);
	    }
	    log.info("Fin buscarPagosBancarios");
	    return lista;
	}

	

}
