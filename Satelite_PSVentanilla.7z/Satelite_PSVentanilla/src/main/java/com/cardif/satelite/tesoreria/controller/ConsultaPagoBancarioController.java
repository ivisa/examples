package com.cardif.satelite.tesoreria.controller;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR;
import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;
import com.cardif.satelite.siniestro.service.SiniTramaPagoVentanillaService;
import com.cardif.satelite.tesoreria.model.ConsultaPagoBancario;
import com.cardif.satelite.tesoreria.service.ConsultaPagoBancarioService;
import com.cardif.satelite.tesoreria.service.PagosBancariosService;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;

@Controller("consultaPagoBancarioController")
@Scope("request")
public class ConsultaPagoBancarioController extends BaseController {
	private final Logger log = Logger
			.getLogger(ConsultaPagoBancarioController.class);

	private Date filtroInicio;
	private Date filtroFin;
	private String filtroNumeroLote;
	private String filtroTipoTrama;
	private List<SelectItem> selectItemTramas;
	private List<Parametro> listaParametros;
	private List<ConsultaPagoBancario> listaConsultaPagoBancario;
	private ConsultaPagoBancario consultaPagoSeleccionado;

	@Autowired
	private ParametroService parametroService;

	@Autowired
	private ConsultaPagoBancarioService consulTaPagoBancarioService;

	@Autowired
	private PagosBancariosService pagosBancariosService;

	@Autowired
	private SiniTramaPagoVentanillaService siniTramaPagoVentanillaService;

	@Override
	@PostConstruct
	public String inicio() {
		log.info("Inicio");
		String respuesta = null;

		if (!tieneAcceso()) {
			log.debug("No cuenta con los accesos necesarios");
			return "accesoDenegado";
		}
		try {
			listaParametros = parametroService.buscar(
					Constantes.COD_PARAM_LISTA_TIPO_TRAMA_GENERADA,
					Constantes.TIP_PARAM_DETALLE);
			cargarItemCombo();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(
					FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = MSJ_ERROR;
		}

		log.info("Fin");
		return respuesta;
	}

	private void cargarItemCombo() {
		if (selectItemTramas == null) {
			selectItemTramas = new ArrayList<SelectItem>();
		} else {
			selectItemTramas.clear();
		}
		selectItemTramas.add(new SelectItem("", "-Seleccionar-"));
		if (listaParametros != null && listaParametros.size() > 0) {
			for (Parametro parametro : listaParametros) {
				selectItemTramas.add(new SelectItem(parametro.getCodValor()
						.trim(), parametro.getNomValor().trim()));
			}
		} else {
			log.debug("Parametros vacíos");
		}
	}

	public void buscar(ActionEvent event) {
		if (log.isInfoEnabled()) {
			log.info("Inicio busqueda");
		}

		try {
			if (validarFecha()) {
				if (listaConsultaPagoBancario == null) {
					listaConsultaPagoBancario = new ArrayList<ConsultaPagoBancario>();
				} else {
					listaConsultaPagoBancario.clear();
				}

				listaConsultaPagoBancario.addAll(consulTaPagoBancarioService
						.buscarPagosBancarios(filtroTipoTrama,
								filtroNumeroLote, filtroInicio, filtroFin));

			} else {
				SateliteUtil.mostrarMensaje("Rango de fechas inválido.");
			}

		} catch (SyncconException ex) {
			log.error(ErrorConstants.ERROR_SYNCCON + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(),
					ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			e.printStackTrace();

			if (e.getMessage() != null) {
				log.info("error!!!");
				SateliteUtil.mostrarMensaje(e.getMessage());
			}
		}

	}

	public void exportar() {
		if (log.isInfoEnabled()) {
			log.info("Inicio");
		}
		String respuesta = null;
		String nombreArchivo = "";
		String rutaTemp = "";
		TramaConfPagoSiniVentanilla tramaObtenida = null;
		try {

			log.debug("obteniendo nombre de archivo");
			nombreArchivo = consultaPagoSeleccionado.getNombreArchivo();
			log.debug("Nombre archivo: " + nombreArchivo);
			if (consultaPagoSeleccionado.getTipoTrama().equals(
					Constantes.TRAMA_GENERADA_BBVA)) {
				rutaTemp = pagosBancariosService.getRutaTramaSiniestro().trim()
						+ nombreArchivo;
			} else {

				tramaObtenida = siniTramaPagoVentanillaService.obtenerById(Long
						.parseLong(consultaPagoSeleccionado.getCodigoTrama()
								.trim()));
				/*String content = "This is the text content";
				byte[] contentInBytes = content.getBytes();*/
				rutaTemp = System.getProperty("java.io.tmpdir") + nombreArchivo;
				FileOutputStream fos = new FileOutputStream(rutaTemp);
				fos.write(tramaObtenida.getArchivoTrama());
				fos.flush();
				fos.close();
				/*BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
				String linea = "iavan igor zapata simbala";
				if (log.isDebugEnabled()) {
					log.debug("-->Linea: " + linea);
				}

				bw.write(linea);
				bw.newLine();
				bw.close();*/
			}
			log.info(rutaTemp);

			if (log.isDebugEnabled()) {
				log.debug("El ruta del archivo es: " + rutaTemp);
			}

			File archivoResp = new File(rutaTemp);
			log.info("archivoResp " + archivoResp);
			FileInputStream fis = new FileInputStream(archivoResp);

			ExternalContext contexto = FacesContext.getCurrentInstance()
					.getExternalContext();

			HttpServletResponse response = (HttpServletResponse) contexto
					.getResponse();
			byte[] loader = new byte[(int) archivoResp.length()];
			response.setContentType("application/octet-stream");
			response.addHeader("Content-Disposition", "attachment;filename="
					+ nombreArchivo);
			response.setContentType("text/plain");

			ServletOutputStream sos = response.getOutputStream();

			while ((fis.read(loader)) > 0) {
				sos.write(loader, 0, loader.length);
			}

			fis.close();
			sos.close();

			FacesContext.getCurrentInstance().responseComplete();
			if (log.isDebugEnabled()) {
				log.debug("Exportacion culminada.");
			}

		}

		catch (SyncconException e) {
			log.error("SyncconException() - " + ErrorConstants.ERROR_SYNCCON
					+ e.getMessageComplete());
			log.error("SyncconException() -->"
					+ ExceptionUtils.getStackTrace(e));
			FacesMessage facesMsg = new FacesMessage(e.getSeveridad(),
					e.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			log.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			log.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			FacesMessage facesMsg = new FacesMessage(
					FacesMessage.SEVERITY_ERROR,
					ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		if (log.isInfoEnabled()) {
			log.info("Fin");
		}

	} // exportar

	public void limpiar(ActionEvent event) {
		limpiarFiltros();
	}

	public void limpiarFiltros() {
		filtroTipoTrama = "";
		filtroInicio = null;
		filtroFin = null;
		filtroNumeroLote = "";
		if (listaConsultaPagoBancario != null) {
			listaConsultaPagoBancario.clear();
		}
	}

	public Date getFiltroInicio() {
		return filtroInicio;
	}

	public void setFiltroInicio(Date filtroInicio) {
		this.filtroInicio = filtroInicio;
	}

	public Date getFiltroFin() {
		return filtroFin;
	}

	public void setFiltroFin(Date filtroFin) {
		this.filtroFin = filtroFin;
	}

	public List<SelectItem> getSelectItemTramas() {
		return selectItemTramas;
	}

	public void setSelectItemTramas(List<SelectItem> selectItemTramas) {
		this.selectItemTramas = selectItemTramas;
	}

	public String getFiltroNumeroLote() {
		return filtroNumeroLote;
	}

	public void setFiltroNumeroLote(String filtroNumeroLote) {
		this.filtroNumeroLote = filtroNumeroLote;
	}

	public String getFiltroTipoTrama() {
		return filtroTipoTrama;
	}

	public void setFiltroTipoTrama(String filtroTipoTrama) {
		this.filtroTipoTrama = filtroTipoTrama;
	}

	public boolean validarFecha() {
		if (filtroInicio != null || filtroFin != null) {
			if (filtroInicio != null && filtroFin == null) {
				return false;
			}
			if (filtroInicio == null && filtroFin != null) {
				return false;
			}
			Calendar fecini = Calendar.getInstance();
			fecini.setTime(filtroInicio);
			Calendar fecfin = Calendar.getInstance();
			fecfin.setTime(filtroFin);
			return (Utilitarios.validarRangoFechas(fecini, fecfin));

		}
		return true;
	}

	public List<ConsultaPagoBancario> getListaConsultaPagoBancario() {
		return listaConsultaPagoBancario;
	}

	public void setListaConsultaPagoBancario(
			List<ConsultaPagoBancario> listaConsultaPagoBancario) {
		this.listaConsultaPagoBancario = listaConsultaPagoBancario;
	}

	public ConsultaPagoBancario getConsultaPagoSeleccionado() {
		return consultaPagoSeleccionado;
	}

	public void setConsultaPagoSeleccionado(
			ConsultaPagoBancario consultaPagoSeleccionado) {
		this.consultaPagoSeleccionado = consultaPagoSeleccionado;
	}

}
