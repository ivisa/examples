package com.cardif.satelite.siniestro.service;

import java.util.List;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;

public interface SiniTramaPagoVentanillaService {

	public void insertar(TramaConfPagoSiniVentanilla tramaConfPagoSiniVentanilla) throws SyncconException;
	
	public void eliminarByID(Long tramaId) throws SyncconException;
	
	public void modificarByID(TramaConfPagoSiniVentanilla tramaConfPagoSiniVentanilla) throws SyncconException;
	
	public TramaConfPagoSiniVentanilla obtenerById(Long tramaId) throws SyncconException;
	
	public void insertarListaTrama(List<TramaConfPagoSiniVentanilla> listaTramaSiniVentanilla) throws SyncconException;
	

}
