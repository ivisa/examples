package com.cardif.satelite.tesoreria.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.siniestro.model.SiniManual;
import com.cardif.satelite.tesoreria.dao.ConsultaPagoMapper;
import com.cardif.satelite.tesoreria.dao.TramaGeneraMapper;
import com.cardif.satelite.tesoreria.model.TramaGenera;
import com.cardif.satelite.tesoreria.model.TramaGeneraDet;
import com.cardif.satelite.tesoreria.service.TramaGeneraDetService;
import com.cardif.satelite.tesoreria.service.TramaGeneraService;

@Service("tramaGeneraService")
public class TramaGeneraServiceImpl implements TramaGeneraService {

	private final Logger logger = Logger
			.getLogger(TramaGeneraServiceImpl.class);

	@Autowired
	private TramaGeneraMapper tramaGeneraMapper;
	@Autowired
	private TramaGeneraDetService tramaGeneraDetService;
	
	@Override
	public List<TramaGenera> listaTramas(String nroLote, String tipoPago,
			Date fec1, Date fec2) throws SyncconException {
		// TODO Auto-generated method stub
		logger.debug("Inicio");
		logger.debug("nroLote: "+ nroLote);
		logger.debug("tipoPago: "+ tipoPago);
		logger.debug("fec1: "+ fec1);
		logger.debug("fec2: "+ fec2);

		List<TramaGenera> lista=null;
	    try {
	      lista = tramaGeneraMapper.listaTramas(nroLote, tipoPago, fec1, fec2);
	    } catch (Exception e) {
	      logger.error(e.getMessage(), e);
	      throw new SyncconException(ErrorConstants.COD_ERROR_BD_BUSCAR);
	    }
	    logger.info("Fin");
	    return lista;
	}

	@Override
	public void insertTramaGenera(TramaGenera tramaGenera)
			throws SyncconException {
		// TODO Auto-generated method stub
		if (logger.isInfoEnabled()) {
			logger.info("Inicio");
		}
		try {
			
			tramaGeneraMapper.insertTramaGenera(tramaGenera);
			logger.debug("inicio Insertando detalle");
			for(TramaGeneraDet tramaGeneraDet:tramaGenera.getDetalleTramaGenera()){
				tramaGeneraDetService.insertTramaGenera(tramaGeneraDet);
			}
			logger.debug("fin Insertando detalle");
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_INSERTAR);
		}
		if (logger.isInfoEnabled()) {
			logger.info("Fin");
		}
	}

	@Override
	public TramaGenera listaTramasById(String nroLote) throws SyncconException {
		// TODO Auto-generated method stub
		logger.debug("Inicio");
		logger.debug("nroLote: "+ nroLote);

		TramaGenera lista=null;
	    try {
	      lista = tramaGeneraMapper.listaTramasById(nroLote);
	    } catch (Exception e) {
	      logger.error(e.getMessage(), e);
	      throw new SyncconException(ErrorConstants.COD_ERROR_BD_BUSCAR);
	    }
	    logger.info("Fin");
	    return lista;
	}

	@Override
	public void updateTramaGeneraFechaGenera(String nroLote)
			throws SyncconException {
		// TODO Auto-generated method stub
		if (logger.isInfoEnabled()) {
			logger.info("Inicio");
		}
		try {
			logger.debug("inicio actualizando fecha de generacion detalle");
			tramaGeneraMapper.updateTramaGeneraFechaGenera(nroLote);
			logger.debug("fin actualizando fecha de generacion detalle");
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}
		if (logger.isInfoEnabled()) {
			logger.info("Fin");
		}
	}

}
