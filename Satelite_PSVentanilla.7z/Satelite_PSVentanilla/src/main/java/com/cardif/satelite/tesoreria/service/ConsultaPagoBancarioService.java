package com.cardif.satelite.tesoreria.service;

import java.util.Date;
import java.util.List;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.tesoreria.model.ConsultaPagoBancario;

public interface ConsultaPagoBancarioService {
	List<ConsultaPagoBancario> buscarPagosBancarios(String tipoTrama,String numeroLote,Date fechaCargaInicio,Date fechaCargaFin) throws SyncconException;
}
