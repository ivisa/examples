package com.cardif.satelite.siniestro.service.impl;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.satelite.CamposTramaSiniVentanilla;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanillaEstadosUpdate;
import com.cardif.satelite.siniestro.dao.CamposTramaPagoSiniVentanillaMapper;
import com.cardif.satelite.siniestro.dao.SiniManualMapper;
import com.cardif.satelite.siniestro.service.CamposTramaPagoSiniVentanillaService;
import com.cardif.satelite.siniestro.service.SiniBeneficiariosService;
import com.cardif.satelite.siniestro.ventanilla.tramas.bbva.BBVAPagoProveedor;

import com.cardif.satelite.util.Utilitarios;


@Service("camposTramaPagoSiniVentanillaService")
public class CamposTramaPagoSiniVentanillaServiceImpl implements CamposTramaPagoSiniVentanillaService {
	
	public static final Logger log = Logger.getLogger(CamposTramaPagoSiniVentanillaServiceImpl.class);
	
	@Autowired
	CamposTramaPagoSiniVentanillaMapper camposTramaPagoSiniVentanillaMapper;
	
	@Autowired
	SiniBeneficiariosService siniBeneficiariosService;
	
	

//	public Integer getLongitudTotalLineaTramaByBancoIdAndTramaId(String bancoId, String tramaId) throws SyncconException {
//		log.info("Inicio");
//		Integer longitudTotalLineaTrama = null;
//		try {
//			if (log.isDebugEnabled()) log.debug("Input [" + bancoId + ", " + tramaId + "]");
//			
//			longitudTotalLineaTrama = camposTramaPagoSiniVentanillaMapper.selectLongitudTotalLineaTrama(bancoId, tramaId);
//			
//			if (log.isDebugEnabled()) log.debug("Output [" + BeanUtils.describe(longitudTotalLineaTrama) + "]");
//
//		}catch (Exception e) {
//			  log.error(e.getMessage(), e);
//			  throw new SyncconException(COD_ERROR_BD_OBTENER);
//		}
//		log.info("Fin");
//		return longitudTotalLineaTrama;
//	}

	
	public Map<String, Object> procesoValidacionArchivosConf(List<TramaConfPagoSiniVentanilla> listaArchivoConfValidar) throws SyncconException {
			
			Map<String, Object> respuesta = null;
			List<TramaConfPagoSiniVentanilla> listaArchivoConfValidados = new ArrayList<TramaConfPagoSiniVentanilla>();
			List<String> listaBufferErrores = new ArrayList<String>();
			List<TramaConfPagoSiniVentanillaEstadosUpdate> listaBeneUpdateEstado = null;
			//Se asume que el primer archivo va estar ok 
			boolean isArchivoFail = false;
			try {
				
				for(TramaConfPagoSiniVentanilla objTramaConfSiniVentanilla : listaArchivoConfValidar){
					

					/**
					 * 	Validación vertical a los codigos de registro de cada linea del archivo.
					 */
					/*
					Map<Boolean, String> validacionVerticalMap = validacionVerticalCodigosTramasArchivoConf(objTramaConfSiniVentanilla.getNombreArchivo(), objTramaConfSiniVentanilla.getArchivoTramaFile());
					
					//1. Si hay key false significa que hubo un error en la validacion vertical
					if(validacionVerticalMap.containsKey(false)){
						//2. Se guarda mensaje de error
						listaBufferErrores.add(validacionVerticalMap.get(false));
						//3. Se procede a procesar el siguiente archivo.
						continue;
					}*/
						
					//Nivel de Archivo
					File archivoTramaFile = objTramaConfSiniVentanilla.getArchivoTramaFile();
					
					//Validación si existe el archivo o si el archivo esta vacío
					if( !archivoTramaFile.exists() || archivoTramaFile.length() == 0){
						listaBufferErrores.add(BBVAPagoProveedor.GET_MSJ_ERROR_ARCHIVO_VACIO(objTramaConfSiniVentanilla.getNombreArchivo()));
						continue;
					}
					
					//Validación si el nombre del archivo coincide con un LoteId existente
					String nombreArchivoSinExtension = objTramaConfSiniVentanilla.getNombreArchivo().split("\\.")[0];
					if(!siniBeneficiariosService.validarExisteLoteIdArchConf(nombreArchivoSinExtension)){
						listaBufferErrores.add(BBVAPagoProveedor.TRAMA_CONFIRMACION.GET_MSJ_ERROR_LOTE_SERIE_NO_EXISTE(objTramaConfSiniVentanilla.getNombreArchivo()));
						continue;
					}
					
					FileReader fr = new FileReader (archivoTramaFile);
					BufferedReader br = new BufferedReader(fr);					
					String lineaLeidaArchivoConf = null;
					int nroLinea = 0;
					
					Map<Boolean, Object> rptValLineMap = null;
					listaBeneUpdateEstado = new ArrayList<TramaConfPagoSiniVentanillaEstadosUpdate>();
					
					log.info("Leyendo el archivo de confirmacion : " + objTramaConfSiniVentanilla.getNombreArchivo());
					
					//Nivel de linea o fila del archivo
					while((lineaLeidaArchivoConf = br.readLine())!=null){
						
						log.info("Linea nro:" + (++nroLinea) + " | Linea Datos: '" + lineaLeidaArchivoConf + "'" );
						
						try{
							
							String codigoTrama = lineaLeidaArchivoConf.substring(0, 4);
							
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_ORDENANTE_3110.getValue())){
								rptValLineMap = validacion_REGISTRO_3110(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue())){
								rptValLineMap = validacion_REGISTRO_3120(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_ORDENANTE_3130.getValue())){
								rptValLineMap = validacion_REGISTRO_3130(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_PROVEEDOR_3210.getValue())){
								rptValLineMap = validacion_REGISTRO_3210(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue())){
								rptValLineMap = validacion_REGISTRO_3220(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue())){
								rptValLineMap = validacion_REGISTRO_3230(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240.getValue())){
								rptValLineMap = validacion_REGISTRO_3240(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue())){
								rptValLineMap = validacion_REGISTRO_3250(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue())){
								rptValLineMap = validacion_REGISTRO_3310(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_TOTALES_FACTURAS_3810.getValue())){
								rptValLineMap = validacion_REGISTRO_3810(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}else
							if(codigoTrama.equals(BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_PIE_FICHERO_3910.getValue())){
								rptValLineMap = validacion_REGISTRO_3910(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea, lineaLeidaArchivoConf);
							}
							
						}catch(Exception e){
							
							/**
							 * 	A. ERROR DESCONOCIDO, ERROR NO CONTROLADO
							 */
							//1. Si ocurre un error desconocido se procede a mostrar las traza de error.
							log.error(BBVAPagoProveedor.GET_MSJ_ERROR_DESCONOCIDO_PROCESAMIENTO_ARCHIVO(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea));
							//2. Se guarda mensaje en el buffer de errores.
							listaBufferErrores.add(BBVAPagoProveedor.GET_MSJ_ERROR_DESCONOCIDO_PROCESAMIENTO_ARCHIVO(objTramaConfSiniVentanilla.getNombreArchivo(), nroLinea));
							
							log.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
							log.error("Exception(" + e.getClass().getName()  + ") -->" + ExceptionUtils.getStackTrace(e));
							
							//3. Se procede a procesar el siguiente archivo.
							isArchivoFail = true;
							break;							
						}
						
						/**
						 * 	B. ERROR CONTROLADO A NIVEL DE CAMPO
						 */
						//1. Si hay key false significa que hubo un error 
						if(rptValLineMap.containsKey(false)){
							//2. Se guarda mensaje de error 
							listaBufferErrores.add((String) rptValLineMap.get(false));
							
							//3. Se procede a procesar el siguiente archivo.
							isArchivoFail = true;
							break;
						
						}else{
							//Solo para la trama 3210
							if(rptValLineMap.containsKey(true)){
								//Se obtienen los datos de cada beneficiario (nro documento + nroLoteSerie)
								TramaConfPagoSiniVentanillaEstadosUpdate dataUpdate = (TramaConfPagoSiniVentanillaEstadosUpdate) rptValLineMap.get(true);
								listaBeneUpdateEstado.add(dataUpdate);
							}
						}						
					}//Fin lectura lineas
					
					//Inicializar variables para lectura del siguiente archivo 
					archivoTramaFile = null;
					fr.close();
					br.close();
					
					//Si se llega hasta acá el archivo está OK, se agrega la lista de archivos de cobros validados
					if(!isArchivoFail){
						objTramaConfSiniVentanilla.setListaBeneUpdate(listaBeneUpdateEstado);
						listaArchivoConfValidados.add(objTramaConfSiniVentanilla);					
					}
					
					//Se asume que el siguiente archico va estar ok 
					isArchivoFail = false;
					
				}//Fin lectura de archivos
				
				//Se termina el proceso de archivos y se prepara la respuesta
				respuesta = new HashMap<String, Object>();
				respuesta.put(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_ARCHIVOS_VALIDOS.name(), listaArchivoConfValidados);
				respuesta.put(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_BUFFER_ERRORES.name(), listaBufferErrores);
				
				//Limpiar listas para optimizar memoria en el servidor
				listaArchivoConfValidados = null;
				listaBufferErrores = null;
				
				return respuesta;
				
			} catch(Exception e){
				log.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
				log.error("Exception(" + e.getClass().getName()  + ") -->" + ExceptionUtils.getStackTrace(e));
		    }
			
			return respuesta;
		}


	private Map<Boolean, String> validacionVerticalCodigosTramasArchivoConf(String nombreArchivo, File archivoTramaFile) throws Exception {
		
		//La respuesta se asume que es correcto hasta que se demuestre lo contrario
		Map<Boolean, String> respuestaMap = new HashMap<Boolean, String>();
		respuestaMap.put(true, "");
		
		FileReader fr = new FileReader (archivoTramaFile);
		BufferedReader br = new BufferedReader(fr);					
		String lineaLeidaArchivoConf = null;
		List<String> listaCodTramas = new ArrayList<String>();
		int nroLinea = 0;
		String msjError = "";
		
		//Nivel de linea o fila del archivo
		while((lineaLeidaArchivoConf = br.readLine()) != null){
			log.info("Linea nro:" + (++nroLinea) + " | Linea Datos: '" + lineaLeidaArchivoConf + "'" );
			
			String codigoRegistro = lineaLeidaArchivoConf.substring(0, 4);
			
			log.info("Validacion vertical, codigo trama de conf :" + codigoRegistro);
			
			//validacion del codigo de registro
			if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarCodigoRegistro(codigoRegistro.trim())){
				msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					BBVAPagoProveedor.TRAMA_CONFIRMACION.CAMPO_COD_REG.CODIGO_REGISTRO.ordenCampo,
					BBVAPagoProveedor.TRAMA_CONFIRMACION.CAMPO_COD_REG.CODIGO_REGISTRO.nombreCampo
			    );
				respuestaMap.put(false, msjError);
				br.close();
				return respuestaMap;
			}
			
			listaCodTramas.add(codigoRegistro);
		}
		br.close();
		
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.AutomataValidacionVerticalCodigosRegistros.runAutomata(listaCodTramas)){
			msjError = BBVAPagoProveedor.TRAMA_CONFIRMACION.AutomataValidacionVerticalCodigosRegistros.GET_MSJ_ERROR_SECUENCIA_COD_REG(nombreArchivo);
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		return respuestaMap;
	}


	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3110
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3110(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3110) throws Exception{
		
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3110 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_ORDENANTE_3110.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3110 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_ORDENANTE_3110.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3110.length() > longitudLineaTrama_3110){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_ORDENANTE_3110.getValue(),
					   		longitudLineaTrama_3110, 
					   		lineaLeidaArchivoConf_3110.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3110.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDENANTE_CAMPOS_3110.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDENANTE_CAMPOS_3110.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo() ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo() ,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Fecha de creación del fichero, cadena.substring(17, 25);
		 */
		String fechaCreacionFichero = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_CREACION_FICHERO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_CREACION_FICHERO.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoFecha(fechaCreacionFichero, BBVAPagoProveedor.TRAMA_CONFIRMACION.FORMATO_FECHA_DDMMYYYY)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_CREACION_FICHERO.getValue())).getNumOrdCampo() ,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_CREACION_FICHERO.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	5. Fecha de proceso, cadena.substring(25, 33);
		 */
		String fechaProceso = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_PROCESO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_PROCESO.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoFecha(fechaProceso, BBVAPagoProveedor.TRAMA_CONFIRMACION.FORMATO_FECHA_DDMMYYYY)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_PROCESO.getValue())).getNumOrdCampo() ,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.FECHA_PROCESO.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
			
		}
		
		/**
		 * 	6. Cuenta ordenante, cadena.substring(33, 53);
		 */
		String cuentaOrdenante = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.CUENTA_ORDENANTE.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.CUENTA_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(cuentaOrdenante, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NRO_CUENTA.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.CUENTA_ORDENANTE.getValue())).getNumOrdCampo() ,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.CUENTA_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
			
		}
		
		/**
		 * 	7. Divisa de la cuenta, cadena.substring(53, 56);
		 */
		String divisaCuenta = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DIVISA_CUENTA.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DIVISA_CUENTA.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarDivisa(divisaCuenta)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DIVISA_CUENTA.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.DIVISA_CUENTA.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}		
		
		/**
		 * 	8. Libre, cadena.substring(56, 68);
		 */
		String libre1 = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.LIBRE1.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.LIBRE1.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isNotBlank(libre1)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.LIBRE1.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.LIBRE1.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}		
		
		/**
		 * 	9. Validación de pertenencia, cadena.substring(68, 69);
		 */
		String validacionPertenencia = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.VALIDACION_PERTENENCIA.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.VALIDACION_PERTENENCIA.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarValidacionPertenencia(validacionPertenencia)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.VALIDACION_PERTENENCIA.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.VALIDACION_PERTENENCIA.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}		
		
		/**
		 * 	10. Indicador devolución, cadena.substring(69, 70);
		 */
		String indicadorDevolucion = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.INDICADOR_DEVOLUCION.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.INDICADOR_DEVOLUCION.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarIndicadorDevolucion(indicadorDevolucion)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.INDICADOR_DEVOLUCION.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.INDICADOR_DEVOLUCION.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}		
		
		/**
		 * 	11. Nombre del fichero, cadena.substring(70, 90);
		 */
		String nombreFichero = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.NOMBRE_ARCHIVO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.NOMBRE_ARCHIVO.getValue()).getPosFinal())
		);
		
		//validacion
		if(!nombreArchivo.equals(nombreFichero.trim())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.NOMBRE_ARCHIVO.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.NOMBRE_ARCHIVO.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}		
		
		/**
		 * 	12. Servicio, cadena.substring(90, 93); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String servicio = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.SERVICIO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.SERVICIO.getValue()).getPosFinal())
		);*/
		
		/**
		 * 	13. Libre, cadena.substring(93, 255); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String libre2 = lineaLeidaArchivoConf_3110.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.LIBRE2.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3110, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3110.LIBRE2.getValue()).getPosFinal())
		);*/
		
		return respuestaMap;
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3120
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3120(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3120) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3120 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3120 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3120.length() > longitudLineaTrama_3120){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue(),
					   		longitudLineaTrama_3120, 
					   		lineaLeidaArchivoConf_3120.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3120.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3120.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3120.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Nombre del Ordenante, cadena.substring(17, 52);
		 */
		String nombreOrd = lineaLeidaArchivoConf_3120.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.NOMBRE_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.NOMBRE_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isBlank(nombreOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.NOMBRE_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.NOMBRE_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	5. Domicilio del Ordenante, cadena.substring(52, 87); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String domicilioOrd = lineaLeidaArchivoConf_3120.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOMICILIO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOMICILIO_ORDENANTE.getValue()).getPosFinal())
		);*/
		
		/**
		 * 	6. Libre, cadena.substring(87, 255); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String libre = lineaLeidaArchivoConf_3120.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOMICILIO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3120, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3120.DOMICILIO_ORDENANTE.getValue()).getPosFinal())
		);*/
		
		return respuestaMap;
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3130
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3130(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3130) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3130 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_ORDENANTE_3130.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3130 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_ORDENANTE_3130.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3130.length() > longitudLineaTrama_3130){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_ORDENANTE_3130.getValue(),
					   		longitudLineaTrama_3130, 
					   		lineaLeidaArchivoConf_3130.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3130.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3130.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3130.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Distrito Ordenante, cadena.substring(17, 52);
		 */
		String distritoOrd = lineaLeidaArchivoConf_3130.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DISTRITO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DISTRITO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isBlank(distritoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DISTRITO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DISTRITO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	5. Provincia Ordenante, cadena.substring(52, 77);
		 */
		String provinciaOrd = lineaLeidaArchivoConf_3130.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.PROVINCIA_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.PROVINCIA_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isBlank(provinciaOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.PROVINCIA_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.PROVINCIA_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	6. Departamento Ordenante, cadena.substring(77, 102);
		 */
		String departamentoOrd = lineaLeidaArchivoConf_3130.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DEPARTAMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DEPARTAMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isBlank(departamentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DEPARTAMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.DEPARTAMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	7. Libre, cadena.substring(102, 255); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String libre = lineaLeidaArchivoConf_3130.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.LIBRE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3130.LIBRE.getValue()).getPosFinal())
		);
		*/
		return respuestaMap;
		
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3210
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3210(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3210) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3210 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_PROVEEDOR_3210.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3210 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_PROVEEDOR_3210.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3210.length() > longitudLineaTrama_3210){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_PROVEEDOR_3210.getValue(),
					   		longitudLineaTrama_3210, 
					   		lineaLeidaArchivoConf_3210.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3210.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3130, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Tipo de Doc. del Proveedor, cadena.substring(17, 18);
		 */
		String tipoDocumentoProv = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_PROVEEDOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_PROVEEDOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.TIP_DOC_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. Documento del Proveedor, cadena.substring(18, 30);
		 */
		String documentoProv = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DOCUMENTO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	6. Nombre del Proveedor, cadena.substring(30, 65);
		 */
		String nombreProv = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.NOMBRE_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.NOMBRE_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isBlank(nombreProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.NOMBRE_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.NOMBRE_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	7. Importe-1, cadena.substring(65, 77);
		 */
		String importeParteEntera = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_1_ENTEROS.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_1_ENTEROS.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeParteEntera, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_1_ENTEROS.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_1_ENTEROS.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	8. Importe-2, cadena.substring(77, 79);
		 */
		String importeParteDecimal = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_2_DECIMAL.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_2_DECIMAL.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeParteDecimal, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_2_DECIMAL.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.IMPORTE_2_DECIMAL.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	9. Divisa, cadena.substring(79, 82);
		 */
		String divisa = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DIVISA.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DIVISA.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarDivisa(divisa)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DIVISA.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.DIVISA.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	10. Libre, cadena.substring(82, 94);
		 */
		String libre1 = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.LIBRE1.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.LIBRE1.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isNotBlank(libre1)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.LIBRE1.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.LIBRE1.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	11. Código de devolución, cadena.substring(94, 98);
		 */
		String codDevolucion = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_DEVOLUCION.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_DEVOLUCION.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.CODIGO_DEVOLUCION.equals(codDevolucion)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_DEVOLUCION.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_DEVOLUCION.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	12. Mensaje de Devolución, cadena.substring(98, 138); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String msjDevolucion = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.MENSAJE_DEVOLUCION.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.MENSAJE_DEVOLUCION.getValue()).getPosFinal())
		);
		*/
		
		/**
		 * 	13. Libre, cadena.substring(138, 255); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String libre2 = lineaLeidaArchivoConf_3210.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.LIBRE2.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3210, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.LIBRE2.getValue()).getPosFinal())
		);
		*/
		
		
		/**
		 * 	Datos para la actualizacion de estado "Procesado por el banco"
		 */
		TramaConfPagoSiniVentanillaEstadosUpdate dataUpdate = new TramaConfPagoSiniVentanillaEstadosUpdate();
		
		dataUpdate.setBeneNumDoc(documentoOrd.trim());	
		String nombreArchivoSinExtension = nombreArchivo.split("\\.")[0];
		dataUpdate.setBeneLoteSerie(nombreArchivoSinExtension);
		respuestaMap.put(true, dataUpdate);
		
		return respuestaMap;
		
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3220
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3220(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3220) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3220 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3220 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3220.length() > longitudLineaTrama_3220){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue(),
					   		longitudLineaTrama_3220, 
					   		lineaLeidaArchivoConf_3220.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3220.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Tipo de Doc. del Proveedor, cadena.substring(17, 18);
		 */
		String tipoDocumentoProv = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_PROVEEDOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_PROVEEDOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIP_DOC_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. Documento del Proveedor, cadena.substring(18, 30);
		 */
		String documentoProv = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOCUMENTO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	6. Código de Banco del Proveedor, cadena.substring(30, 34);
		 */
		String codBancoProv = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.COD_BANCO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.COD_BANCO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(codBancoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.COD_BANCO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.COD_BANCO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	7. Cuenta del Proveedor, cadena.substring(34, 54);
		 */
		String cuentaProv = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.CUENTA_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.CUENTA_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isBlank(cuentaProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.CUENTA_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.CUENTA_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	8. Domicilio del Proveedor, cadena.substring(54, 89); //Opcional
		 */
		@SuppressWarnings("unused")
		String domicilioProv = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOMICILIO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.DOMICILIO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		/**
		 * 	9. Forma de pago, cadena.substring(89, 90);
		 */
		String formaPago = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.FORMA_PAGO.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.FORMA_PAGO.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarFormaPago(formaPago)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.FORMA_PAGO.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.FORMA_PAGO.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	10. Libre, cadena.substring(90, 114);
		 */
		String libre1 = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.LIBRE1.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.LIBRE1.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isNotBlank(libre1)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.LIBRE1.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.LIBRE1.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	11. Tipo de cuenta, cadena.substring(114, 116);
		 */
		String tipoCuenta = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIPO_CUENTA.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIPO_CUENTA.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoCuenta(tipoCuenta)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIPO_CUENTA.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.TIPO_CUENTA.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	12. Libre, cadena.substring(116, 255); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String libre2 = lineaLeidaArchivoConf_3220.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.LIBRE1.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3220, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3220.LIBRE1.getValue()).getPosFinal())
		);
		*/
		
		return respuestaMap;
		
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3230
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3230(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3230) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3230 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3230 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3230.length() > longitudLineaTrama_3230){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue(),
					   		longitudLineaTrama_3230, 
					   		lineaLeidaArchivoConf_3230.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3230.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Tipo de Doc. del Proveedor, cadena.substring(17, 18);
		 */
		String tipoDocumentoProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_PROVEEDOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_PROVEEDOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TIP_DOC_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. Documento del Proveedor, cadena.substring(18, 30);
		 */
		String documentoProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DOCUMENTO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	6. Distrito del Proveedor, cadena.substring(30, 65); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String distritoProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DISTRITO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DISTRITO_PROVEEDOR.getValue()).getPosFinal())
		);*/
		
		/**
		 * 	7. Provincia del Proveedor, cadena.substring(65, 90); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String provinciaProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.PROVINCIA_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.PROVINCIA_PROVEEDOR.getValue()).getPosFinal())
		);*/
		
		/**
		 * 	8. Departamento del Proveedor, cadena.substring(90, 115); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String departamentoProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DEPARTAMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.DEPARTAMENTO_PROVEEDOR.getValue()).getPosFinal())
		);*/

		/**
		 * 	9. Confirmación a Proveedor, cadena.substring(115, 116); //Opcional
		 */
		String confProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CONFIRMACION_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CONFIRMACION_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isNotBlank(confProv)){
			if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarConfProveedor(confProv)){
				msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
						nombreArchivo, 
						nroLinea,
						(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CONFIRMACION_PROVEEDOR.getValue())).getNumOrdCampo(),
						(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CONFIRMACION_PROVEEDOR.getValue()).getDesCampo())
				);
				respuestaMap.put(false, msjError);
				return respuestaMap;			
			}
		}
		
		/**
		 * 	10. Correo electrónico del Proveedor, cadena.substring(116, 176); //Opcional
		 */
		String correoElecProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CORREO_ELEC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CORREO_ELEC_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isNotBlank(correoElecProv)){
			if(!Utilitarios.validateCorreoElectronico(correoElecProv.trim())){
				msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
						nombreArchivo, 
						nroLinea,
						(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CORREO_ELEC_PROVEEDOR.getValue())).getNumOrdCampo(),
						(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.CORREO_ELEC_PROVEEDOR.getValue()).getDesCampo())
				);
				respuestaMap.put(false, msjError);
				return respuestaMap;			
			}
		}
		
		/**
		 * 	11. Teléfono Celular / Fax del Proveedor, cadena.substring(176, 188); //Opcional
		 */
		String telefonoCelularFaxProv = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TELEFONO_CELULAR_FAX_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TELEFONO_CELULAR_FAX_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(StringUtils.isNotBlank(telefonoCelularFaxProv)){
			if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
				msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
						nombreArchivo, 
						nroLinea,
						(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TELEFONO_CELULAR_FAX_PROVEEDOR.getValue())).getNumOrdCampo(),
						(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.TELEFONO_CELULAR_FAX_PROVEEDOR.getValue()).getDesCampo())
				);
				respuestaMap.put(false, msjError);
				return respuestaMap;			
			}
		}
		
		/**
		 * 	12. Libre, cadena.substring(188, 255); //Opcional
		 */
		String libre = lineaLeidaArchivoConf_3230.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.LIBRE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.LIBRE.getValue()).getPosFinal())
		);
		/*
		//validacion
		if(StringUtils.isNotBlank(libre.trim())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.LIBRE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3230.LIBRE.getValue()).getDesCampo())
			);			
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}*/
		
		return respuestaMap;
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3240
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3240(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3240) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3240 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3240 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3240.length() > longitudLineaTrama_3240){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240.getValue(),
					   		longitudLineaTrama_3240, 
					   		lineaLeidaArchivoConf_3240.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3230.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3240.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3240.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Tipo de Doc. del Proveedor, cadena.substring(17, 18);
		 */
		String tipoDocumentoProv = lineaLeidaArchivoConf_3240.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_PROVEEDOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_PROVEEDOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.TIP_DOC_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. Documento del Proveedor, cadena.substring(18, 30);
		 */
		String documentoProv = lineaLeidaArchivoConf_3240.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.DOCUMENTO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}

		/**
		 * 	6. Concepto-1, cadena.substring(30, 65);
		 */
		String concepto1 = lineaLeidaArchivoConf_3240.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.CONCEPTO_1.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.CONCEPTO_1.getValue()).getPosFinal())
		);
		
		//validacion
		if(!StringUtils.isNotBlank(concepto1)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.CONCEPTO_1.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.CONCEPTO_1.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	7. Concepto-2, cadena.substring(64, 100); //Opcional
		 */
		@SuppressWarnings("unused")
		String concepto2 = lineaLeidaArchivoConf_3240.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.CONCEPTO_1.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.CONCEPTO_1.getValue()).getPosFinal())
		);
		
		/**
		 * 	8. Libre, cadena.substring(100, 255); //Opcional
		 */
		@SuppressWarnings("unused")
		String libre = lineaLeidaArchivoConf_3240.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.LIBRE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3240, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3240.LIBRE.getValue()).getPosFinal())
		);
		
		return respuestaMap;
		
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3250
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3250(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3250) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3250 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3250 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3250.length() > longitudLineaTrama_3250){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue(),
					   		longitudLineaTrama_3250, 
					   		lineaLeidaArchivoConf_3250.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3230.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3250.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3250.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Tipo de Doc. del Proveedor, cadena.substring(17, 18);
		 */
		String tipoDocumentoProv = lineaLeidaArchivoConf_3250.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_PROVEEDOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_PROVEEDOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.TIP_DOC_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. Documento del Proveedor, cadena.substring(18, 30);
		 */
		String documentoProv = lineaLeidaArchivoConf_3250.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.DOCUMENTO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}

		/**
		 * 	6. Concepto-3, cadena.substring(30, 65);
		 */
		String concepto1 = lineaLeidaArchivoConf_3250.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.CONCEPTO_3.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.CONCEPTO_3.getValue()).getPosFinal())
		);
		
		//validacion
		if(!StringUtils.isNotBlank(concepto1)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.CONCEPTO_3.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.CONCEPTO_3.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	7. Concepto-4, cadena.substring(65, 100); //Opcional
		 */
		@SuppressWarnings("unused")
		String concepto2 = lineaLeidaArchivoConf_3250.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.CONCEPTO_4.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.CONCEPTO_4.getValue()).getPosFinal())
		);
		
		/**
		 * 	8. Libre, cadena.substring(100, 255); //Opcional
		 */
		@SuppressWarnings("unused")
		String libre = lineaLeidaArchivoConf_3250.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.LIBRE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3250, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3250.LIBRE.getValue()).getPosFinal())
		);
		
		return respuestaMap;
		
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3310
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3310(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3310) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3310 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3310 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3310.length() > longitudLineaTrama_3310){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue(),
					   		longitudLineaTrama_3310, 
					   		lineaLeidaArchivoConf_3310.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3230.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Emisor, cadena.substring(4, 5);
		 */
		String tipoDocumentoEmisor = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_EMISOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_EMISOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoEmisor)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_EMISOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_EMISOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Emisor, cadena.substring(5, 17);
		 */
		String documentoEmisor = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_EMISOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_EMISOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoEmisor, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_EMISOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_EMISOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Tipo de Doc. del Proveedor, cadena.substring(17, 18);
		 */
		String tipoDocumentoProv = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PROVEEDOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PROVEEDOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. Documento del Proveedor, cadena.substring(18, 30);
		 */
		String documentoProv = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	6. Tipo de Documento pagado al Proveedor, cadena.substring(30, 31);
		 */
		String tipDocumentoPagoProv = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PAGADO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PAGADO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocPagoProveedor(tipDocumentoPagoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PAGADO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.TIP_DOC_PAGADO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	7. Documento pagado al Proveedor, cadena.substring(31, 43);
		 */		
		String documentoPagadoProv = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PAGADO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PAGADO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoPagadoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NRO_DOC_PAG_PROVEEDOR.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PAGADO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DOCUMENTO_PAGADO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}

		/**
		 * 	8. Fecha de Doc. pagado / Fecha de documento, cadena.substring(43, 51);
		 */			
		String fechaDocPagado = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_DOC_PAGADO.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_DOC_PAGADO.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoFecha(fechaDocPagado, BBVAPagoProveedor.TRAMA_CONFIRMACION.FORMATO_FECHA_DDMMYYYY)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_DOC_PAGADO.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_DOC_PAGADO.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	9. Fecha de Vencimiento de documento, cadena.substring(51, 59);
		 */			
		String fechaVencimientoDoc = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_VENCIMIENTO_DOCUMENTO.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_VENCIMIENTO_DOCUMENTO.getValue()).getPosFinal())
		);
		/*
		//validacion
		if(!BBVAPagoProveedor.validarCampoFecha(fechaVencimientoDoc, BBVAPagoProveedor.TRAMA_CONFIRMACION.FORMATO_FECHA_DDMMYYYY)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_VENCIMIENTO_DOCUMENTO.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.FECHA_VENCIMIENTO_DOCUMENTO.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}*/
		
		/**
		 * 	10. Divisa de Documento pagado, cadena.substring(59, 62);
		 */			
		String divisaDocPagado = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DIVISA_DOC_PAGADO.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DIVISA_DOC_PAGADO.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarDivisa(divisaDocPagado)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DIVISA_DOC_PAGADO.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.DIVISA_DOC_PAGADO.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	11. Importe 1, cadena.substring(62, 74);
		 */			
		String importeParteEntera = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_1_PARTE_ENTERA.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_1_PARTE_ENTERA.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeParteEntera, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_1_PARTE_ENTERA.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_1_PARTE_ENTERA.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	12. Importe 2, cadena.substring(74, 76);
		 */			
		String importeParteDecimal = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_2_PARTE_DECIMAL.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_2_PARTE_DECIMAL.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeParteDecimal, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_2_PARTE_DECIMAL.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.IMPORTE_2_PARTE_DECIMAL.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	13. Signo del importe, cadena.substring(76, 77);
		 */			
		String signoImporte = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.SIGNO_IMPORTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.SIGNO_IMPORTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarSignoImporte(signoImporte)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.SIGNO_IMPORTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.SIGNO_IMPORTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	14. Concepto de Doc. Pagado, cadena.substring(77, 102); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String conceptoDocPagado = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.CONCEPTO_DOC_PAGADO.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.CONCEPTO_DOC_PAGADO.getValue()).getPosFinal())
		);*/
		
		/**
		 * 	15. Libre, cadena.substring(102, 255); //Opcional
		 */
		/*
		@SuppressWarnings("unused")
		String libre = lineaLeidaArchivoConf_3310.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.LIBRE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3310, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3310.LIBRE.getValue()).getPosFinal())
		);*/
		
		return respuestaMap;
		
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3810
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3810(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3810) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3810 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_TOTALES_FACTURAS_3810.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3810 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_TOTALES_FACTURAS_3810.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3810.length() > longitudLineaTrama_3810){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_TOTALES_FACTURAS_3810.getValue(),
					   		longitudLineaTrama_3810, 
					   		lineaLeidaArchivoConf_3810.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3230.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Emisor, cadena.substring(4, 5);
		 */
		String tipoDocumentoEmisor = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_EMISOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_EMISOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoEmisor)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_EMISOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_EMISOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Emisor, cadena.substring(5, 17);
		 */
		String documentoEmisor = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_EMISOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_EMISOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoEmisor, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_EMISOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_EMISOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. Tipo de Doc. del Proveedor, cadena.substring(17, 18);
		 */
		String tipoDocumentoProv = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_PROVEEDOR.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoProv)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_PROVEEDOR.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.TIP_DOC_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. Documento del Proveedor, cadena.substring(18, 30);
		 */
		String documentoProv = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_PROVEEDOR.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_PROVEEDOR.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoProv, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_PROVEEDOR.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.DOCUMENTO_PROVEEDOR.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	6. Nro. De registros, cadena.substring(30, 40);
		 */
		String nroRegistros = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_REGISTROS.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_REGISTROS.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(nroRegistros, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_REGISTROS.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_REGISTROS.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	7. Nro. Total de documentos, cadena.substring(40, 48);
		 */
		String nroTotalDocumentos = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_TOTAL_DOCUMENTOS.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_TOTAL_DOCUMENTOS.getValue()).getPosFinal())
		);	

		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(nroTotalDocumentos, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_TOTAL_DOCUMENTOS.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.NRO_TOTAL_DOCUMENTOS.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}		
		
		/**
		 * 	8. Importe Total de documentos - parte entera, cadena.substring(48, 60);
		 */
		String importeTotalDocumentosEntera = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_ENTERA.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_ENTERA.getValue()).getPosFinal())
		);	

		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeTotalDocumentosEntera, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_ENTERA.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_ENTERA.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	9. Importe Total de documentos - parte decimal, cadena.substring(60, 62);
		 */
		String importeTotalDocumentosDecimal = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_DECIMAL.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_DECIMAL.getValue()).getPosFinal())
		);	

		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeTotalDocumentosDecimal, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_DECIMAL.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.IMPORTE_TOTAL_DOCUMENTOS_PARTE_DECIMAL.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	8. Libre, cadena.substring(62, 255);
		 */
		/*
		String libre = lineaLeidaArchivoConf_3810.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.LIBRE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3810, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3810.LIBRE.getValue()).getPosFinal())
		);	
		*/	
		
		return respuestaMap;
		
	}
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param lineaLeidaArchivoConf_3910
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.
	 * @throws Exception
	 */
	private Map<Boolean, Object> validacion_REGISTRO_3910(String nombreArchivo, int nroLinea, String lineaLeidaArchivoConf_3910) throws Exception{
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		//Obtener Datos de campos configurados de la trama de cobros en la BD.
		List<CamposTramaSiniVentanilla> lstCamposTrama_3910 = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_PIE_FICHERO_3910.getValue());
		
		//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
		int longitudLineaTrama_3910 =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
				BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_PIE_FICHERO_3910.getValue());
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoConf_3910.length() > longitudLineaTrama_3910){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(
					   		nombreArchivo, 
					   		nroLinea, 
					   		BBVAPagoProveedor.TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_PIE_FICHERO_3910.getValue(),
					   		longitudLineaTrama_3910, 
					   		lineaLeidaArchivoConf_3910.length()
					   );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Código de registro, cadena.substring(0, 4); // EL AUTOMATA YA VALIDO EL CODIGO Y LA SECUENCIA CORRECTA.
		 */
//		String codigoRegistro = lineaLeidaArchivoConf_3230.substring(
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue())).getPosInicial() - 1 ,
//				(getCampoFromListaByNumeroOrden(lstCamposTrama_3230, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3210.CODIGO_REGISTRO.getValue()).getPosFinal())
//		);
		
		/**
		 * 	2. Tipo de Documento del Ordenante, cadena.substring(4, 5);
		 */
		String tipoDocumentoOrd = lineaLeidaArchivoConf_3910.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.TIP_DOC_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.TIP_DOC_ORDENANTE.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.TRAMA_CONFIRMACION.validarTipoDocumento(tipoDocumentoOrd)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.TIP_DOC_ORDENANTE.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.TIP_DOC_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	3. Documento del Ordenante, cadena.substring(5, 17);
		 */
		String documentoOrd = lineaLeidaArchivoConf_3910.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.DOCUMENTO_ORDENANTE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.DOCUMENTO_ORDENANTE.getValue()).getPosFinal())
		);
		
		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(documentoOrd, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
					nombreArchivo, 
					nroLinea,
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.DOCUMENTO_ORDENANTE.getValue())).getNumOrdCampo(),
					(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.DOCUMENTO_ORDENANTE.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;			
		}
		
		/**
		 * 	4. N° Total de registros, cadena.substring(17, 27);
		 */
		String nroTotalRegistros = lineaLeidaArchivoConf_3910.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_REGISTROS.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_REGISTROS.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(nroTotalRegistros, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_REGISTROS.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_REGISTROS.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	5. N° Total de operaciones, cadena.substring(27, 35);
		 */
		String nroTotalOperaciones = lineaLeidaArchivoConf_3910.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_OPERACIONES.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_OPERACIONES.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(nroTotalOperaciones, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_OPERACIONES.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.NRO_TOTAL_OPERACIONES.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	6. Importe-parte entera, cadena.substring(35, 47);
		 */
		String importeParteEntera = lineaLeidaArchivoConf_3910.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_ENTERA.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_ENTERA.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeParteEntera, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_ENTERA.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_ENTERA.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}
		
		/**
		 * 	7. Importe-parte decimal, cadena.substring(47, 49);
		 */
		String importeParteDecimal = lineaLeidaArchivoConf_3910.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_DECIMAL.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_DECIMAL.getValue()).getPosFinal())
		);

		//validacion
		if(!BBVAPagoProveedor.AutomataValidarCampoNumerico.runAutomata(importeParteDecimal, BBVAPagoProveedor.AutomataValidarCampoNumerico.TIPO.NUMERICO.name())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_DECIMAL.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.IMPORTE_PARTE_DECIMAL.getValue()).getDesCampo())
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;	
		}		
		
		/**
		 * 	8. Libre, cadena.substring(49, 155);
		 */
		/*
		String libre = lineaLeidaArchivoConf_3910.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.LIBRE.getValue())).getPosInicial() - 1,
				(getCampoFromListaByNumeroOrden(lstCamposTrama_3910, BBVAPagoProveedor.TRAMA_CONFIRMACION.ORDEN_CAMPOS_3910.LIBRE.getValue()).getPosFinal())
		);*/	

		return respuestaMap;
		
	}


	public Map<String, Object> procesoValidacionArchivosCobros(List<TramaConfPagoSiniVentanilla> listaArchivoCobrosValidar) throws SyncconException{
		
		Map<String, Object> respuesta = null;
		List<TramaConfPagoSiniVentanilla> listaArchivoCobrosValidados = new ArrayList<TramaConfPagoSiniVentanilla>();
		List<String> listaBufferErrores = new ArrayList<String>();
		List<TramaConfPagoSiniVentanillaEstadosUpdate> listaBeneUpdateEstado = null;
		//Se asume que el primer archivo va estar ok 
		boolean isArchivoFail = false;
		try {
			
			//Obtener Datos de campos configurados de la trama de cobros en la BD.
			List<CamposTramaSiniVentanilla> lstCamposTramaCobros = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
					BBVAPagoProveedor.TRAMA_COBROS.TRAMA_ID);
			
			//Validacion de tamaño, si los tamaños son diferentes se informa en el buffer de errores y se pasa al siguiente Archivo
			int longitudLineaTramaCobros =  camposTramaPagoSiniVentanillaMapper.getLongitudTotalCamposTramaByBancoIdAndTramaId(BBVAPagoProveedor.BANCO_BBVA_ID, 
					BBVAPagoProveedor.TRAMA_COBROS.TRAMA_ID);
			
			for(TramaConfPagoSiniVentanilla objTramaPagosSiniVentanilla : listaArchivoCobrosValidar){
				String lineaLeidaArchivoCobros = null;
				int nroLinea = 0;
				
				//Nivel de Archivo
				File archivoTramaFile = objTramaPagosSiniVentanilla.getArchivoTramaFile();
				
				//Validación si existe el archivo o si el archivo esta vacío
				if( !archivoTramaFile.exists() || archivoTramaFile.length() == 0){
					listaBufferErrores.add(BBVAPagoProveedor.GET_MSJ_ERROR_ARCHIVO_VACIO(objTramaPagosSiniVentanilla.getNombreArchivo()));
					continue;
				}
				
				FileReader fr = new FileReader(archivoTramaFile);
				BufferedReader br = new BufferedReader(fr);
				
				Map<Boolean, Object> rptValLineMap = null;
				listaBeneUpdateEstado = new ArrayList<TramaConfPagoSiniVentanillaEstadosUpdate>();
				
				log.info("Leyendo el archivo de cobros : " + objTramaPagosSiniVentanilla.getNombreArchivo());					

				//Nivel de linea o fila del archivo
				while( (lineaLeidaArchivoCobros = br.readLine()) != null ){
					
					log.info("Linea nro:" + (++nroLinea) + " | Linea Datos: '" + lineaLeidaArchivoCobros + "'" );
					
					try{
						
						rptValLineMap = validacionLineaArchivoCobro(objTramaPagosSiniVentanilla.getNombreArchivo(), nroLinea,
								lineaLeidaArchivoCobros, longitudLineaTramaCobros, lstCamposTramaCobros);
						
					}catch(Exception e){
						/**
						 * 	A. ERROR DESCONOCIDO, ERROR NO CONTROLADO
						 */
						//1. Si ocurre un error desconocido se procede a mostrar las traza de error.
						log.error(BBVAPagoProveedor.GET_MSJ_ERROR_DESCONOCIDO_PROCESAMIENTO_ARCHIVO(objTramaPagosSiniVentanilla.getNombreArchivo(), nroLinea));
						//2. Se guarda mensaje en el buffer de errores.
						listaBufferErrores.add(BBVAPagoProveedor.GET_MSJ_ERROR_DESCONOCIDO_PROCESAMIENTO_ARCHIVO(objTramaPagosSiniVentanilla.getNombreArchivo(), nroLinea));
						
						log.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
						log.error("Exception(" + e.getClass().getName()  + ") -->" + ExceptionUtils.getStackTrace(e));
						
						//3. Se procede a procesar el siguiente archivo.
						isArchivoFail = true;
						break;
					}
					
					/**
					 * 	B. ERROR CONTROLADO A NIVEL DE CAMPO
					 */
					//1. Si hay key false significa que hubo un error 
					if(rptValLineMap.containsKey(false)){
						//2. Se guarda mensaje de error 
						listaBufferErrores.add((String) rptValLineMap.get(false));
						
						//3. Se procede a procesar el siguiente archivo.
						isArchivoFail = true;
						break;
						
					}else{
						//Se obtienen los datos de cada beneficiario (nro documento + monto)
						TramaConfPagoSiniVentanillaEstadosUpdate dataUpdate = (TramaConfPagoSiniVentanillaEstadosUpdate) rptValLineMap.get(true);
						listaBeneUpdateEstado.add(dataUpdate);
					}
				}//Fin lectura lineas
				
				//Inicializar variables para lectura del siguiente archivo 
				archivoTramaFile = null;
				fr.close();
				br.close();
				
				//Si se llega hasta acá el archivo está OK, se agrega la lista de archivos de cobros validados
				if(!isArchivoFail){
					//Se cargan los datos del beneficiario que son necesarios para la actualizacion de estado "PROCESADO POR BANCO (14)"
					objTramaPagosSiniVentanilla.setListaBeneUpdate(listaBeneUpdateEstado);
					listaArchivoCobrosValidados.add(objTramaPagosSiniVentanilla);					
				}
				
				//Se asume que el siguiente archico va estar ok 
				isArchivoFail = false;
			
			}//Fin lectura de archivos
			
			//Se termina el proceso de archivos y se prepara la respuesta
			respuesta = new HashMap<String, Object>();
			respuesta.put(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_ARCHIVOS_VALIDOS.name(), listaArchivoCobrosValidados);
			respuesta.put(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_BUFFER_ERRORES.name(), listaBufferErrores);
			
			//Limpiar listas para optimizar memoria en el servidor
			listaArchivoCobrosValidados = null;
			listaBufferErrores = null;
			
			return respuesta;				
		
		} catch(Exception e){
			log.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			log.error("Exception(" + e.getClass().getName()  + ") -->" + ExceptionUtils.getStackTrace(e));
	    }
		
		return respuesta;
		
	}
	
	
	/**
	 * 
	 * @param nombreArchivo
	 * @param nroLinea
	 * @param lineaLeidaArchivoCobros
	 * @param longitudLineaTramaCobros
	 * @param lstCamposTramaCobros
	 * @return MapMap<Boolean, String> Se retorna inicializado si no se encontró algun error, en caso contrario retorna un key como true y el value con el mensaje de error.   
	 * @throws Exception
	 */
	public Map<Boolean, Object> validacionLineaArchivoCobro(String nombreArchivo, int nroLinea, String lineaLeidaArchivoCobros, int longitudLineaTramaCobros, 
								List<CamposTramaSiniVentanilla> lstCamposTramaCobros) throws Exception{
		
			
		Map<Boolean,Object> respuestaMap = new HashMap<Boolean,Object>();
		String msjError = "";
		
		/**
		 * 	Validacion de la longitud de la linea.
		 */
		if(lineaLeidaArchivoCobros.length() != longitudLineaTramaCobros){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(nombreArchivo, nroLinea, longitudLineaTramaCobros, lineaLeidaArchivoCobros.length());
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	1. Nombre del Archivo, cadena.substring(0, 12);
		 */
		String campoNombreArchivo = lineaLeidaArchivoCobros.substring( 
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NOMBRE_ARCHIVO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NOMBRE_ARCHIVO.getValue()).getPosFinal()) 
		);
		
		//validacion
		if(!BBVAPagoProveedor.TRAMA_COBROS.validarNomArchivo(campoNombreArchivo)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea, 
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NOMBRE_ARCHIVO.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NOMBRE_ARCHIVO.getValue())).getDesCampo()
			);
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	2. Fecha de Emisión, cadena.substring(12, 20);
		 */
		String campoFechaEmision = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_EMISION.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_EMISION.getValue()).getPosFinal())		
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoFecha(campoFechaEmision, BBVAPagoProveedor.TRAMA_COBROS.FORMATO_FECHA_YYYYMMDD)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_EMISION.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_EMISION.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	3. Fecha de Cobro, substring(20, 28);
		 */
		String campoFechaCobro = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_COBRO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_COBRO.getValue()).getPosFinal())		
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoFecha(campoFechaCobro, BBVAPagoProveedor.TRAMA_COBROS.FORMATO_FECHA_YYYYMMDD)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_COBRO.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.FECHA_COBRO.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
				
		/**
		 * 	4. Nro. de documento del Beneficiario, cadena.substring(28, 39);
		 */
		String campoNroDocBene = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NRO_DOC_BENEFICIARIO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NRO_DOC_BENEFICIARIO.getValue()).getPosFinal())		
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoNumerico(campoNroDocBene.trim())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NRO_DOC_BENEFICIARIO.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NRO_DOC_BENEFICIARIO.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	5. Nombre del Beneficiario, cadena.substring(39, 74);
		 */
		@SuppressWarnings("unused")
		String campoNomBene = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NOMBRE_BENEFICIARIO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NOMBRE_BENEFICIARIO.getValue()).getPosFinal())		
		);
		
		/**
		 * 	6. Importe (Parte entera), cadena.substring(74, 88);
		 */
		String campoParteImporteEntero = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_ENTERA.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_ENTERA.getValue()).getPosFinal())		
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoNumerico(campoParteImporteEntero.trim())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_ENTERA.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_ENTERA.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	7. Importe (Parte decimal), cadena.substring(88, 90);
		 */
		String campoParteImporteDecimal = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_DECIMAL.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_DECIMAL.getValue()).getPosFinal())		
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoNumerico(campoParteImporteDecimal.trim())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_DECIMAL.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.IMPORTE_PARTE_DECIMAL.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	8. Divisa, cadena.substring(90, 93);
		 */
		String campoDivisa = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.DIVISA.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.DIVISA.getValue()).getPosFinal())		
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarDivisa(campoDivisa)){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.DIVISA.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.DIVISA.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		
		/**
		 * 	9. Número de Orden, cadena.substring(93, 100);
		 */
		@SuppressWarnings("unused")
		String campoNroOrden = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NUMERO_ORDEN.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NUMERO_ORDEN.getValue()).getPosFinal())		
		);
		
		/**
		 * 	10. Código interno, cadena.substring(100, 115);
		 */
		@SuppressWarnings("unused")
		String CampoCodInterno = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.CODIGO_INTERNO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.CODIGO_INTERNO.getValue()).getPosFinal())		
		);
		
		/**
		 * 	11. Número de Cheque, cadena.substring(115, 128);
		 */
		@SuppressWarnings("unused")
		String campoNroCheke = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NUMERO_CHEQUE.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.NUMERO_CHEQUE.getValue()).getPosFinal())		
		);
		
		/**
		 * 	12. Código de OFICINA EMI/COBRO, cadena.substring(128, 132);
		 */
		String campoCodOfiEmiCobro = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.COD_OFICINA_EMI_COBRO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.COD_OFICINA_EMI_COBRO.getValue()).getPosFinal())		
		);
		
		//validacion
		if(!BBVAPagoProveedor.validarCampoNumerico(campoCodOfiEmiCobro.trim())){
			msjError = BBVAPagoProveedor.GET_MSJ_ERROR_CAMPO(
				nombreArchivo, 
				nroLinea,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.COD_OFICINA_EMI_COBRO.getValue())).getNumOrdCampo(),
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.COD_OFICINA_EMI_COBRO.getValue())).getDesCampo()
		    );
			respuestaMap.put(false, msjError);
			return respuestaMap;
		}
		
		/**
		 * 	13. OFICINA EMI/COBRO, cadena.substring(132, 155);
		 */
		@SuppressWarnings("unused")
		String campoDescOfiEmiCobro = lineaLeidaArchivoCobros.substring(
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.OFICINA_EMI_COBRO.getValue())).getPosInicial() - 1 ,
				(getCampoFromListaByNumeroOrden(lstCamposTramaCobros, BBVAPagoProveedor.TRAMA_COBROS.NUM_ORDEN_CAMPO.OFICINA_EMI_COBRO.getValue()).getPosFinal())		
		);
		
		/**
		 * 	Datos para la actualizacion de estado "Procesado por el banco"
		 */
		TramaConfPagoSiniVentanillaEstadosUpdate dataUpdate = new TramaConfPagoSiniVentanillaEstadosUpdate();

		BigDecimal parteImporteEntero = new BigDecimal(campoParteImporteEntero.trim());
		String montoCompleto = parteImporteEntero.toString() + "." + campoParteImporteDecimal.trim();
		dataUpdate.setBeneMonto(montoCompleto);
		BigDecimal nroDocBene = new BigDecimal(campoNroDocBene.trim());
		dataUpdate.setBeneNumDoc(nroDocBene.toString());		
		respuestaMap.put(true, dataUpdate);
		
		return respuestaMap;
		
	}
	
	
	public CamposTramaSiniVentanilla getCampoFromListaByNumeroOrden(List<CamposTramaSiniVentanilla> lstCamposTramaCobrosByTrama, int numOrdenCampo){
		
		CamposTramaSiniVentanilla objCamposTramaSiniVentanillaFinal = null;
		
		for(CamposTramaSiniVentanilla objCamposTramaSiniVentanilla : lstCamposTramaCobrosByTrama){
			if(objCamposTramaSiniVentanilla.getNumOrdCampo().intValue() == numOrdenCampo){
				objCamposTramaSiniVentanillaFinal = objCamposTramaSiniVentanilla;
				break;
			}
		}
		
		return objCamposTramaSiniVentanillaFinal;
	}


	@Override
	public List<CamposTramaSiniVentanilla> getCamposTramaByBancoIdAndTramaId(
			String bancoId, String tramaId) throws SyncconException {
		// TODO Auto-generated method stub
		log.debug("Inicio");
		log.debug("bancoId: "+ bancoId);
		log.debug("tramaId: "+ tramaId);
		List<CamposTramaSiniVentanilla> lista=null;
	    try {
	      lista = camposTramaPagoSiniVentanillaMapper.getCamposTramaByBancoIdAndTramaId(bancoId, tramaId);
	    } catch (Exception e) {
	      log.error(e.getMessage(), e);
	      throw new SyncconException(ErrorConstants.COD_ERROR_BD_BUSCAR);
	    }
	    log.info("Fin");
	    return lista;
	}
	
	
}

