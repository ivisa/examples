package com.cardif.satelite.tesoreria.service.impl;


import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.tesoreria.dao.TramaGeneraDetMapper;
import com.cardif.satelite.tesoreria.model.TramaGeneraDet;
import com.cardif.satelite.tesoreria.service.TramaGeneraDetService;

@Service("tramaGeneraDetService")
public class TramaGeneraDetServiceImpl implements TramaGeneraDetService {

	private final Logger logger = Logger
			.getLogger(TramaGeneraDetServiceImpl.class);

	@Autowired
	private TramaGeneraDetMapper tramaGeneraDetMapper;
	
	@Override
	public List<TramaGeneraDet> listaTramas(String nroLote) throws SyncconException {
		// TODO Auto-generated method stub
		logger.debug("Inicio");
		logger.debug("nroLote: "+ nroLote);

		List<TramaGeneraDet> lista=null;
	    try {
	      lista = tramaGeneraDetMapper.listaTramas(nroLote);
	    } catch (Exception e) {
	      logger.error(e.getMessage(), e);
	      throw new SyncconException(ErrorConstants.COD_ERROR_BD_BUSCAR);
	    }
	    logger.info("Fin");
	    return lista;
	}

	@Override
	public void insertTramaGenera(TramaGeneraDet tramaGenera)
			throws SyncconException {
		// TODO Auto-generated method stub
		if (logger.isInfoEnabled()) {
			logger.info("Inicio");
		}
		try {
			
			tramaGeneraDetMapper.insertTramaGeneraDet(tramaGenera);
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_INSERTAR);
		}
		if (logger.isInfoEnabled()) {
			logger.info("Fin");
		}
	}

}
