package com.cardif.satelite.util;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.model.satelite.CamposTramaSiniVentanilla;
import com.cardif.satelite.siniestro.service.CamposTramaPagoSiniVentanillaService;
import com.cardif.satelite.tesoreria.model.TramaGenera;
import com.cardif.satelite.tesoreria.model.TramaGeneraDet;

@Component
public class TramaUtilBBVA {
	@Autowired
	private  CamposTramaPagoSiniVentanillaService camposTramaPagoSiniVentanillaService;
	@Autowired
	private  ParametroService parametroService;
	
	static final String CODIGO_REGISTRO_3110 = "3110";
	static final String CODIGO_REGISTRO_3120 = "3120";
	static final String CODIGO_REGISTRO_3130 = "3130";
	static final String CODIGO_REGISTRO_3210 = "3210";
	static final String CODIGO_REGISTRO_3220 = "3220";
	static final String CODIGO_REGISTRO_3910 = "3910";
	static final String CODIGO_BANCO_DB ="200";
	static final String TIPO_DOCUMENTO_ORDENANTE ="R";
	static final String PARAMETRO_089 ="089";
	static final String PARAMETRO_036 ="036";
	static final String PARAMETRO_001 ="001";
	static final String PARAMETRO_086 ="086";
	static final String PARAMETRO_100 ="100";
	static final String VALIDACION_PERTENENCIA ="1";
	static final String INDICADOR_DEVOLUCION ="0";
	static final String CODIGO_DEVOLUCION = "0000";
	static final String ORDEN_DE_PAGO="0011";
	static final String CUENTA_ORDEN_DE_PAGO="00000000000000000000";
	static final String FORMA_ORDEN_DE_PAGO="O";
	static final String TIPO_CUENTA_ORDEN_DE_PAGO="00";
	static final int REGISTROS_DEFAULT=4;
	static final int NUMERO_CORRIDAS=2;
	
	public String getCabeceraOrdenante3110(String nombreFichero,String extension,Calendar fechaFichero,Calendar fechaProceso,TramaGenera tramaGenera) throws SyncconException{
		String lineaCabecera="";
		String fechaTemporal="";
		List<CamposTramaSiniVentanilla> camposTramaSiniVentanilla=camposTramaPagoSiniVentanillaService.getCamposTramaByBancoIdAndTramaId(CODIGO_BANCO_DB, CODIGO_REGISTRO_3110);
		Map<Integer,CamposTramaSiniVentanilla> registroOrdenate=registroOrdenate(camposTramaSiniVentanilla);
		for(CamposTramaSiniVentanilla campos:registroOrdenate.values()){
			switch(campos.getNumOrdCampo()){
				case 1:
					lineaCabecera= lineaCabecera.concat(CODIGO_REGISTRO_3110);
					break;
				case 2:
					lineaCabecera= lineaCabecera.concat(TIPO_DOCUMENTO_ORDENANTE);
					break;
				case 3:
					Parametro parametro= parametroService.obtener(PARAMETRO_089 , "D", "SEGUROS_RUC");
					String rucParibas =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(rucParibas,campos));
					break;
				case 4:
					fechaTemporal=Utilitarios.personalizarFecha(fechaFichero.getTime(), "ddMMyyyy");
					lineaCabecera= lineaCabecera.concat(fechaTemporal.trim());
					break;
				case 5:
					fechaTemporal=Utilitarios.personalizarFecha(fechaProceso.getTime(), "ddMMyyyy");
					lineaCabecera= lineaCabecera.concat(fechaTemporal.trim());
					break;
				case 6:
					lineaCabecera= lineaCabecera.concat(valorFormateado(tramaGenera.getCuentaOrdenante().trim(),campos));
					break;
				case 7:
					lineaCabecera= lineaCabecera.concat(valorFormateado(tramaGenera.getMoneda().trim(),campos));
					break;
				case 8:
					campos.setTipoDato("A");
					lineaCabecera= lineaCabecera.concat(valorFormateado("",campos));
					break;
				case 9:
					lineaCabecera= lineaCabecera.concat(VALIDACION_PERTENENCIA);
					break;
				case 10:
					lineaCabecera= lineaCabecera.concat(INDICADOR_DEVOLUCION);
					break;
				case 11:
					String nombreExtension = nombreFichero+""+extension;
					lineaCabecera= lineaCabecera.concat(valorFormateado(nombreExtension, campos));
					break;
				case 12:					
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
				case 13:					
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
			}
		}
		return lineaCabecera;
	}
	public String getCabeceraOrdenante3120()throws SyncconException{
		String lineaCabecera="";
		List<CamposTramaSiniVentanilla> camposTramaSiniVentanilla=camposTramaPagoSiniVentanillaService.getCamposTramaByBancoIdAndTramaId(CODIGO_BANCO_DB, CODIGO_REGISTRO_3120);
		Map<Integer,CamposTramaSiniVentanilla> registroOrdenate=registroOrdenate(camposTramaSiniVentanilla);
		Parametro parametro=null;
		for(CamposTramaSiniVentanilla campos:registroOrdenate.values()){
			switch(campos.getNumOrdCampo()){
				case 1:
					lineaCabecera= lineaCabecera.concat(CODIGO_REGISTRO_3120);
					break;
				case 2:
					lineaCabecera= lineaCabecera.concat(TIPO_DOCUMENTO_ORDENANTE);
					break;
				case 3:
					parametro= parametroService.obtener(PARAMETRO_089 , "D", "SEGUROS_RUC");
					String rucParibas =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(rucParibas,campos));
					break;
				case 4:
					parametro= parametroService.obtener(PARAMETRO_001 , "D", "1");
					String nombreParibas =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(nombreParibas, campos));
					break;
				case 5:
					parametro= parametroService.obtener(PARAMETRO_086 , "D", "1");
					String domicilio =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(domicilio, campos));
					break;
				case 6:					
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
			}
		}
		return lineaCabecera;
	}
	public String getCabeceraOrdenante3130()throws SyncconException{
		String lineaCabecera="";
		List<CamposTramaSiniVentanilla> camposTramaSiniVentanilla=camposTramaPagoSiniVentanillaService.getCamposTramaByBancoIdAndTramaId(CODIGO_BANCO_DB, CODIGO_REGISTRO_3130);
		Map<Integer,CamposTramaSiniVentanilla> registroOrdenate=registroOrdenate(camposTramaSiniVentanilla);
		Parametro parametro=null;
		for(CamposTramaSiniVentanilla campos:registroOrdenate.values()){
			switch(campos.getNumOrdCampo()){
				case 1:
					lineaCabecera= lineaCabecera.concat(CODIGO_REGISTRO_3130);
					break;
				case 2:
					lineaCabecera= lineaCabecera.concat(TIPO_DOCUMENTO_ORDENANTE);
					break;
				case 3:
					parametro= parametroService.obtener(PARAMETRO_089 , "D", "SEGUROS_RUC");
					String rucParibas =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(rucParibas,campos));
					break;
				case 4:
					parametro= parametroService.obtener(PARAMETRO_086 , "D", "5");
					String distrito =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(distrito, campos));
					break;
				case 5:
					parametro= parametroService.obtener(PARAMETRO_086 , "D", "4");
					String provincia =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(provincia, campos));
					break;
				case 6:
					parametro= parametroService.obtener(PARAMETRO_086 , "D", "3");
					String departamento =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(departamento, campos));
					break;
				case 7:					
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
			}
		}
		return lineaCabecera;
	}
	public String getCabeceraOrdenante3210(TramaGenera tramaGenera,TramaGeneraDet tramaGeneraDet)throws SyncconException{
		String lineaCabecera="";
		List<CamposTramaSiniVentanilla> camposTramaSiniVentanilla=camposTramaPagoSiniVentanillaService.getCamposTramaByBancoIdAndTramaId(CODIGO_BANCO_DB, CODIGO_REGISTRO_3210);
		Map<Integer,CamposTramaSiniVentanilla> registroOrdenate=registroOrdenate(camposTramaSiniVentanilla);
		Parametro parametro=null;
		for(CamposTramaSiniVentanilla campos:registroOrdenate.values()){
			switch(campos.getNumOrdCampo()){
				case 1:
					lineaCabecera= lineaCabecera.concat(CODIGO_REGISTRO_3210);
					break;
				case 2:
					lineaCabecera= lineaCabecera.concat(TIPO_DOCUMENTO_ORDENANTE);
					break;
				case 3:
					parametro= parametroService.obtener(PARAMETRO_089 , "D", "SEGUROS_RUC");
					String rucParibas =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(rucParibas,campos));
					break;
				case 4:
					parametro= parametroService.obtener(PARAMETRO_100 , "D", tramaGeneraDet.getTipoDocBenef().trim());
					lineaCabecera= lineaCabecera.concat(parametro.getNomValor().trim());
					break;
				case 5:
					lineaCabecera= lineaCabecera.concat(valorFormateado(tramaGeneraDet.getNumDocBenef().trim(), campos));
					break;
				case 6:
					lineaCabecera= lineaCabecera.concat(valorFormateado(tramaGeneraDet.getBenefNomComp().trim(), campos));
					break;
				case 7:	
					String entero = SateliteUtil.obtieneParteEntera(tramaGeneraDet.getBenefImporte());
					lineaCabecera= lineaCabecera.concat(valorFormateado(entero, campos));
					break;
				case 8:
					String decimal = SateliteUtil.obtieneParteDecimal(tramaGeneraDet.getBenefImporte());
					lineaCabecera= lineaCabecera.concat(valorFormateadoDecimal(decimal, campos));
					break;
				case 9:					
					lineaCabecera= lineaCabecera.concat(valorFormateado(tramaGenera.getMoneda().trim(), campos));
					break;
				case 10:		
					campos.setTipoDato("A");
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
				case 11:	
					lineaCabecera= lineaCabecera.concat(CODIGO_DEVOLUCION);
					break;
				case 12:		
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
				case 13:		
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
			}
		}
		return lineaCabecera;
	}
	public String getCabeceraOrdenante3220(TramaGenera tramaGenera,TramaGeneraDet tramaGeneraDet)throws SyncconException{
		String lineaCabecera="";
		List<CamposTramaSiniVentanilla> camposTramaSiniVentanilla=camposTramaPagoSiniVentanillaService.getCamposTramaByBancoIdAndTramaId(CODIGO_BANCO_DB, CODIGO_REGISTRO_3220);
		Map<Integer,CamposTramaSiniVentanilla> registroOrdenate=registroOrdenate(camposTramaSiniVentanilla);
		Parametro parametro=null;
		for(CamposTramaSiniVentanilla campos:registroOrdenate.values()){
			switch(campos.getNumOrdCampo()){
				case 1:
					lineaCabecera= lineaCabecera.concat(CODIGO_REGISTRO_3220);
					break;
				case 2:
					lineaCabecera= lineaCabecera.concat(TIPO_DOCUMENTO_ORDENANTE);
					break;
				case 3:
					parametro= parametroService.obtener(PARAMETRO_089 , "D", "SEGUROS_RUC");
					String rucParibas =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(rucParibas,campos));
					break;
				case 4:
					parametro= parametroService.obtener(PARAMETRO_100 , "D", tramaGeneraDet.getTipoDocBenef().trim());
					lineaCabecera= lineaCabecera.concat(parametro.getNomValor().trim());
					break;
				case 5:
					lineaCabecera= lineaCabecera.concat(valorFormateado(tramaGeneraDet.getNumDocBenef().trim(), campos));
					break;
				case 6:
					lineaCabecera= lineaCabecera.concat(ORDEN_DE_PAGO);
					break;
				case 7:	
					lineaCabecera= lineaCabecera.concat(CUENTA_ORDEN_DE_PAGO);
					break;
				case 8:
					if(tramaGeneraDet.getDireccionBenef()==null){
						tramaGeneraDet.setDireccionBenef("");
					}
					lineaCabecera= lineaCabecera.concat(valorFormateado(tramaGeneraDet.getDireccionBenef().trim(), campos));
					break;
				case 9:					
					lineaCabecera= lineaCabecera.concat(FORMA_ORDEN_DE_PAGO);
					break;
				case 10:		
					campos.setTipoDato("A");
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
				case 11:	
					lineaCabecera= lineaCabecera.concat(TIPO_CUENTA_ORDEN_DE_PAGO);
					break;
				case 12:		
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
			}
		}
		return lineaCabecera;
	}
	public String getCabeceraOrdenante3910(TramaGenera tramaGenera)throws SyncconException{
		String lineaCabecera="";
		List<CamposTramaSiniVentanilla> camposTramaSiniVentanilla=camposTramaPagoSiniVentanillaService.getCamposTramaByBancoIdAndTramaId(CODIGO_BANCO_DB, CODIGO_REGISTRO_3910);
		Map<Integer,CamposTramaSiniVentanilla> registroOrdenate=registroOrdenate(camposTramaSiniVentanilla);
		Parametro parametro=null;
		for(CamposTramaSiniVentanilla campos:registroOrdenate.values()){
			switch(campos.getNumOrdCampo()){
				case 1:
					lineaCabecera= lineaCabecera.concat(CODIGO_REGISTRO_3910);
					break;
				case 2:
					lineaCabecera= lineaCabecera.concat(TIPO_DOCUMENTO_ORDENANTE);
					break;
				case 3:
					parametro= parametroService.obtener(PARAMETRO_089 , "D", "SEGUROS_RUC");
					String rucParibas =parametro.getNomValor().trim();
					lineaCabecera= lineaCabecera.concat(valorFormateado(rucParibas,campos));
					break;
				case 4:
					int totalRegistros = REGISTROS_DEFAULT + NUMERO_CORRIDAS*tramaGenera.getDetalleTramaGenera().size();
					lineaCabecera= lineaCabecera.concat(valorFormateado(String.valueOf(totalRegistros), campos));
					break;
				case 5:
					lineaCabecera= lineaCabecera.concat(valorFormateado(String.valueOf(tramaGenera.getDetalleTramaGenera().size()), campos));
					break;
				case 6:
					String entero = SateliteUtil.obtieneParteEntera(tramaGenera.getTramaMonto());
					lineaCabecera= lineaCabecera.concat(valorFormateado(entero, campos));
					break;
				case 7:	
					String decimal = SateliteUtil.obtieneParteDecimal(tramaGenera.getTramaMonto());
					lineaCabecera= lineaCabecera.concat(valorFormateadoDecimal(decimal, campos));
					break;
				case 8:		
					lineaCabecera= lineaCabecera.concat(valorFormateado("", campos));
					break;
			}
		}
		return lineaCabecera;
	}
	public static Map<Integer,CamposTramaSiniVentanilla> registroOrdenate(List<CamposTramaSiniVentanilla> lista){
		Map<Integer,CamposTramaSiniVentanilla> mapaRegistroOrdenate=new HashMap<Integer, CamposTramaSiniVentanilla>();
		for(CamposTramaSiniVentanilla campos:lista){
			mapaRegistroOrdenate.put(campos.getNumOrdCampo(), campos);
		}
		return mapaRegistroOrdenate;		
	}
	public static String valorFormateado(String valor,CamposTramaSiniVentanilla campos){
		String nuevoValor="";
		int completa = 0;
		if(campos.getTipoDato().trim().equals("A")){
			if(valor.trim().length()<campos.getLongCampo()){
				completa = campos.getLongCampo()-valor.trim().length();
				nuevoValor = valor.trim().concat(SateliteUtil.completaVacios(completa)); 
			}else if(valor.trim().length()>campos.getLongCampo()){
				nuevoValor = valor.trim().substring(0,campos.getLongCampo());
			}else{
				nuevoValor = valor.trim();
			}
		}
		if(campos.getTipoDato().trim().equals("N")){
			completa = 0;
			nuevoValor="";
			if(valor.trim().length()<campos.getLongCampo()){
				completa = campos.getLongCampo()-valor.trim().length();
				nuevoValor = SateliteUtil.completaCerosIzquierda(completa,valor.trim()); 
			}else if(valor.trim().length()>campos.getLongCampo()){
				nuevoValor = valor.trim().substring(0,campos.getLongCampo());
			}else{
				nuevoValor = valor.trim();
			}
		}
		return nuevoValor;
	}
	public static String valorFormateadoDecimal(String valor,CamposTramaSiniVentanilla campos){
		String nuevoValor="";
		int completa = 0;
		
			if(valor.trim().length()<campos.getLongCampo()){
				completa = campos.getLongCampo()-valor.trim().length();
				nuevoValor = SateliteUtil.completaCerosDerecha(completa,valor.trim()); 
			}else{
				if(valor.trim().length()==campos.getLongCampo()){
					nuevoValor= valor;
				}else{
					nuevoValor= valor.substring(0,campos.getLongCampo());
				}
			}
		
		return nuevoValor;
	}
	
}
