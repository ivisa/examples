package com.cardif.satelite.tesoreria.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.jfree.util.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.siniestro.dao.BeneficiarioSiniestroMapper;
import com.cardif.satelite.siniestro.dao.SiniManualMapper;
import com.cardif.satelite.tesoreria.bean.ConsultaPagoResultado;
import com.cardif.satelite.tesoreria.bean.JournalBean;
import com.cardif.satelite.tesoreria.dao.ConsultaPagoMapper;
import com.cardif.satelite.tesoreria.service.ConsultaPagoService;
import com.cardif.satelite.util.Utilitarios;

@Service("consultaPagoService")
public class ConsultaPagoServiceImpl implements ConsultaPagoService {

	private final Logger logger = Logger
			.getLogger(ConsultaPagoServiceImpl.class);

	@Autowired
	private ConsultaPagoMapper consultaPagoMapper;
	
	@Autowired
	private SiniManualMapper siniManualMapper;
	
	@Autowired
	private BeneficiarioSiniestroMapper beneficiarioSiniestroMapper;

	@Override
	public ConsultaPagoResultado  obtenerNumeroDeLote(Integer anio, String moneda,
			String usuario) throws SyncconException {
		String numeroDelote = null;
		ConsultaPagoResultado consultaPagoResultado=new ConsultaPagoResultado();
		if (logger.isInfoEnabled()) {
			logger.info("Inicio");
		}
		try {
			consultaPagoResultado.setAnio(anio);
			consultaPagoResultado.setMoneda(moneda);
			consultaPagoResultado.setUsuario(usuario);
			consultaPagoResultado.setResultado("");
			consultaPagoMapper.obtenerNumeroDeLote(consultaPagoResultado);
			logger.debug("resultado: "+consultaPagoResultado.getResultado());
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_INSERTAR);
		}
		if (logger.isInfoEnabled()) {
			logger.info("Fin");
		}
		return consultaPagoResultado;
	}

	@Override
	public int deleteSiniGeneraLote(String loteId) throws SyncconException {
		// TODO Auto-generated method stub
		if (logger.isInfoEnabled()) {
			logger.info("Inicio");
		}
		try {
			
			consultaPagoMapper.deleteSiniGeneraLote(loteId.trim());
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ELIMINAR);
		}
		if (logger.isInfoEnabled()) {
			logger.info("Fin");
		}
		return 0;
	}

	@Override
	public void actualizarFechaProvisionadoSiniestro(List<JournalBean> listaActualizar,String usuario) throws SyncconException {
		// TODO Auto-generated method stub
		logger.info("inicia actualizarFechaProvisionadoSiniestro");
		try{
			for(JournalBean journalBean: listaActualizar){
				Date fechaProvisionado = Utilitarios.convertStringToDate(journalBean.getFechaTransaccion(), Constantes.FORMATO_FECHA_DDMMYYYY);
				String nombres="";
      			nombres=journalBean.getGlosa().trim();
      			nombres=nombres.replace(',',' ');
      			nombres=Utilitarios.limpiarEspacios(nombres);
      			double importe = (double)journalBean.getImporteTransaccion();
      			logger.info("Actualiza siniestro");
      			beneficiarioSiniestroMapper.updateSiniestroFechaProvisionado(journalBean.getReferenciaTransaccion().trim(), nombres, importe, fechaProvisionado, usuario);
      			logger.info("Actualiza siniestro manuales");
      			siniManualMapper.updateSiniestroFechaProvisionado(journalBean.getReferenciaTransaccion().trim(), nombres, importe, fechaProvisionado, usuario);
  			}
			logger.info("fin actualizarFechaProvisionadoSiniestro");
		}catch(Exception e){
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}
	}
	@Override
	public void actualizarFechaRegistroPagoSiniestro(List<JournalBean> listaActualizar,String usuario) throws SyncconException {
		// TODO Auto-generated method stub
		logger.info("actualizarFechaRegistroPagoSiniestro");
		try{
			for(JournalBean journalBean: listaActualizar){				
				String nombres="";
      			nombres=journalBean.getGlosa().trim();
      			nombres=nombres.replace(',',' ');
      			nombres=Utilitarios.limpiarEspacios(nombres);
      			double importe = (double)journalBean.getImporteTransaccion();
      			logger.info("Actualiza siniestro");
      			beneficiarioSiniestroMapper.updateSiniestroFechaRegistroPago(journalBean.getReferenciaTransaccion().trim(), nombres, importe, usuario);
      			logger.info("Actualiza siniestro manuales");
      			siniManualMapper.updateSiniestroFechaRegistroPago(journalBean.getReferenciaTransaccion().trim(), nombres, importe, usuario);
  			}
			logger.info("fin actualizarFechaRegistroPagoSiniestro");
		}catch(Exception e){
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: "
					+ e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->"
					+ ExceptionUtils.getStackTrace(e));
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}
	}
	

}
