package com.cardif.satelite.tesoreria.model;

import java.util.Date;

public class FirmanteLoteEnvioAdjunto {
	private String loteId;
	private Integer envioId;
	private Date fecha;
	private byte[] adjunto;
	public String getLoteId() {
		return loteId;
	}
	public void setLoteId(String loteId) {
		this.loteId = loteId;
	}
	
	public Integer getEnvioId() {
		return envioId;
	}
	public void setEnvioId(Integer envioId) {
		this.envioId = envioId;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public byte[] getAdjunto() {
		return adjunto;
	}
	public void setAdjunto(byte[] adjunto) {
		this.adjunto = adjunto;
	}
	
}
