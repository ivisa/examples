package com.cardif.satelite.tesoreria.dao;


import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


import com.cardif.satelite.tesoreria.model.TramaGeneraDet;

public interface TramaGeneraDetMapper {
	final String LISTA_TRAMAS ="SELECT * FROM SINI_TRAMA_GENERA_DET"
			+ " WHERE"
			+ " LOTEID = #{nroLote,jdbcType=VARCHAR}";
	
	final String INSERT_TRAMA ="INSERT INTO SINI_TRAMA_GENERA_DET("
			+ "loteId,tipoDocBenef,numDocBenef,benefNomComp,"
			+ "benefImporte,tipCodSunat,cuentaContable,referencia,"
			+ "direccionBenef,"
			+ "usuarioCrea,fechaCrea)"
			+ " VALUES("
			+ "#{loteId,jdbcType=NVARCHAR},"
			+ "#{tipoDocBenef,jdbcType=NVARCHAR},"
			+ "#{numDocBenef,jdbcType=NVARCHAR},"
			+ "#{benefNomComp,jdbcType=NVARCHAR},"
			+ "#{benefImporte,javaType=double,jdbcType=NUMERIC},"
			+ "#{tipCodSunat,jdbcType=VARCHAR},"
			+ "#{cuentaContable,jdbcType=NVARCHAR},"
			+ "#{referencia,jdbcType=NVARCHAR},"
			+ "#{direccionBenef,jdbcType=NVARCHAR},"
			+ "#{usuarioCrea,jdbcType=VARCHAR},"
			+ "GETDATE())"
			+ "";
	
	
	@Select(LISTA_TRAMAS)
	public List<TramaGeneraDet> listaTramas(@Param("nroLote") String nroLote);
	
	@Insert(INSERT_TRAMA)
	public void insertTramaGeneraDet(TramaGeneraDet tramaGenera);
}
