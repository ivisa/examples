package com.cardif.satelite.siniestro.service.impl;

import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_INSERTAR;
import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_OBTENER;
import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_ELIMINAR;
import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_ACTUALIZAR;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.satelite.BeneficiarioSiniestro;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanillaEstadosUpdate;
import com.cardif.satelite.siniestro.dao.BeneficiarioSiniestroMapper;
import com.cardif.satelite.siniestro.dao.SiniManualMapper;
import com.cardif.satelite.siniestro.service.SiniBeneficiariosService;


@Service("siniBeneficiariosService")
public class SiniBeneficiariosServiceImpl implements SiniBeneficiariosService{

	public static final Logger log = Logger.getLogger(SiniBeneficiariosServiceImpl.class);
	
	@Autowired
	BeneficiarioSiniestroMapper beneficiarioSiniestroMapper;
	
	@Autowired
	SiniManualMapper siniManualMapper;
	
	
	public int insertarSiniBeneficiario(BeneficiarioSiniestro beneficiarioSiniestro) throws SyncconException{
		log.info("Inicio");
		
		try{
			if (log.isDebugEnabled()) log.debug("Input [ " + BeanUtils.describe(beneficiarioSiniestro) + " ]");
			
			beneficiarioSiniestroMapper.insert(beneficiarioSiniestro);
			
			if (log.isDebugEnabled()) log.debug("Output [OK]");
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
			e.printStackTrace();
		    throw new SyncconException(COD_ERROR_BD_INSERTAR);
		}
		
		log.info("Fin");

	    return 0;
	}
	
	public List<BeneficiarioSiniestro> listarBeneficiariosBySiniestro(String siniestroID) throws SyncconException{
		log.info("Inicio");
		List<BeneficiarioSiniestro> listaBeneficiario;
		try{
			listaBeneficiario = beneficiarioSiniestroMapper.listarBeneficiariosBySiniestro(siniestroID);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_OBTENER);
		}
		log.info("Fin");
		return listaBeneficiario;
	}
	
	public void eliminarBeneficiarioByID(Long beneficiarioID) throws SyncconException{
		log.info("Inicio");
		try{
			beneficiarioSiniestroMapper.deleteByPrimaryKey(beneficiarioID);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ELIMINAR);
		}
		log.info("Fin");
	}
	
	public void eliminarBeneficiariosByNroSiniestro(List<BeneficiarioSiniestro> listaSiniBeneficiario) throws SyncconException{
		log.info("Inicio");
		try{
			
			for(BeneficiarioSiniestro bene : listaSiniBeneficiario){
				eliminarBeneficiarioByID(bene.getBeneficiarioID());
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ELIMINAR);
		}
		
		log.info("Fin");
	}
	
	public void modificarBeneficiarioByID(BeneficiarioSiniestro beneficiarioSiniestro) throws SyncconException{
		log.info("Inicio");
		try{
			beneficiarioSiniestroMapper.updateByPrimaryKeySelective(beneficiarioSiniestro);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}
	
	/*
	 * 
	 * */
	public void actualizarParticipacionBeneComun(List<BeneficiarioSiniestro> listaSiniBeneficiario, BigDecimal impPagos) throws SyncconException{
		log.info("Inicio");
		try{
			if(listaSiniBeneficiario != null && listaSiniBeneficiario.size()>0){
			
	//			Double  benePartComun = (double) Math.round((100.00/nroBenef) * 100) / 100;
				BigDecimal benePartComun = Constantes.CIEN_PORCIENTO_BENEF.divide(new BigDecimal(listaSiniBeneficiario.size()), 
										Constantes.PRESICION_DECIMAL_BENEF, RoundingMode.HALF_UP);
				
				BigDecimal beneMontoComun = impPagos.divide(new BigDecimal(listaSiniBeneficiario.size()), 
										Constantes.PRESICION_DECIMAL_BENEF, RoundingMode.HALF_UP);
				
				BigDecimal montoResultado = beneMontoComun.multiply(new BigDecimal(listaSiniBeneficiario.size()));
				
				int comparacionRpt = impPagos.compareTo(montoResultado);
				
				BigDecimal beneMontoComunMasCentesima = null;
				int countBandera = 0;
				if(comparacionRpt == 0){//Son iguales
					
				}else if(comparacionRpt == 1){//primer valor es mayor
					beneMontoComunMasCentesima = new BigDecimal(0);
					beneMontoComunMasCentesima = beneMontoComun.add((impPagos.subtract(montoResultado)));
				}else if(comparacionRpt == -1){//segundo valor es mayor
					
				}
				
				for(BeneficiarioSiniestro bene : listaSiniBeneficiario ){
					if(beneMontoComunMasCentesima != null && countBandera == 0){
						bene.setBenePart(benePartComun);
						bene.setBeneMonto(beneMontoComunMasCentesima);//Aplicar centesima al primer registro
						countBandera++;
					}else{
						bene.setBenePart(benePartComun);
						bene.setBeneMonto(beneMontoComun);
					}
					modificarBeneficiarioByID(bene);
				}
			
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		
		log.info("Fin");
	}
	
	public void actualizarParticipacionBeneComun(List<BeneficiarioSiniestro> listaSiniBeneficiario, Long beneficiarioID, 
			BigDecimal benePart, BigDecimal partComun, BigDecimal impPagos) throws SyncconException{
		log.info("Inicio");
		try{
			
			if(listaSiniBeneficiario != null && listaSiniBeneficiario.size()>0){
			
				BigDecimal montoUnico = impPagos.multiply(benePart.divide(Constantes.CIEN_PORCIENTO_BENEF, 
																				Constantes.PRESICION_DECIMAL_BENEF, RoundingMode.HALF_UP));
				
				BigDecimal sizeLista = null;
				if(listaSiniBeneficiario.size() > 1){
					sizeLista = new BigDecimal(listaSiniBeneficiario.size() - 1);
				}else{
					sizeLista = new BigDecimal(listaSiniBeneficiario.size());
				}
				
				BigDecimal montoComun = (impPagos.subtract(montoUnico)).divide(sizeLista, RoundingMode.HALF_UP);
				
				//Monto comun con centesima 
				BigDecimal montoRestanteTotal = impPagos.subtract(montoUnico);
				int comparacionRpt = montoRestanteTotal.compareTo(montoComun.multiply(sizeLista));
				BigDecimal beneMontoComunMasCentesima = null;
				int countBandera = 0;
				if(comparacionRpt == 0){//Son iguales
					
				}else if(comparacionRpt == 1){//primer valor es mayor
					beneMontoComunMasCentesima = new BigDecimal(0);
					beneMontoComunMasCentesima = montoComun.add((montoRestanteTotal.subtract(montoComun.multiply(sizeLista))));
					
				}else if(comparacionRpt == -1){//segundo valor es mayor
					beneMontoComunMasCentesima = new BigDecimal(0);
					beneMontoComunMasCentesima = montoComun.subtract((montoComun.multiply(sizeLista)).subtract(montoRestanteTotal));
				}
				
				for(BeneficiarioSiniestro bene : listaSiniBeneficiario ){
					
					if(bene.getBeneficiarioID().longValue() == beneficiarioID.longValue()){
						bene.setBenePart(benePart);	
						bene.setBeneMonto(montoUnico);
					}else{
						if(beneMontoComunMasCentesima != null && countBandera == 0){
							bene.setBenePart(partComun);
							bene.setBeneMonto(beneMontoComunMasCentesima);//Aplicar centesima al primer registro
							countBandera++;
						}else{
							bene.setBenePart(partComun);
							bene.setBeneMonto(montoComun);
						}
					}
					modificarBeneficiarioByID(bene);
				}
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}
	
	public void updateBeneficiarioFecOpContable(List<BeneficiarioSiniestro> listaSiniBeneficiario) throws SyncconException{
		try{
			if(listaSiniBeneficiario != null && listaSiniBeneficiario.size() > 0 ){
				
				for(BeneficiarioSiniestro reg : listaSiniBeneficiario){
					beneficiarioSiniestroMapper.updateBeneficiarioFecOpContable(reg.getBeneficiarioID());
				}
				
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}

	@Override
	public void updateBeneficiarioLoteId(String siniestroId, String nombres,
			String loteId, String usuario) throws SyncconException{
		// TODO Auto-generated method stub
		log.debug("Inicio");
		try{
			beneficiarioSiniestroMapper.updateBeneficiarioLoteId(siniestroId, nombres, loteId, usuario);
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}

	@Override
	public BeneficiarioSiniestro beneficiariosBySiniestroNombres(
			String siniestroId, String nombres) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		log.info("siniestroId: "+siniestroId);
		log.info("nombres: "+ nombres);
		
		BeneficiarioSiniestro beneficiario=null;
		try{
			beneficiario = beneficiarioSiniestroMapper.beneficiariosBySiniestroNombres(siniestroId, nombres);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_OBTENER);
		}
		log.info("Fin");
		return beneficiario;
	}
	
	

	public void updateBeneTramaConfirmados_SB(String beneNumDoc, String numLoteSerie) throws SyncconException{
		log.info("Inicio");
		try{
			beneficiarioSiniestroMapper.updateBeneTramaConfirmados(Constantes.SINI_BENEF_ESTADO_PROCESADO, beneNumDoc, numLoteSerie);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}
	
	private void updateBeneTramaConfirmados_SM(String beneNumDoc, String numLoteSerie) throws SyncconException{
		log.info("Inicio");
		try{
			siniManualMapper.updateBeneTramaConfirmados(Constantes.SINI_BENEF_ESTADO_PROCESADO, beneNumDoc, numLoteSerie);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}
	
	public void actualizarBeneficiariosTramaConfirmados(List<TramaConfPagoSiniVentanilla> listaArchivoValidadosConf) throws SyncconException{
		log.info("Inicio");
		try{
			for(TramaConfPagoSiniVentanilla archivoValidadoConf: listaArchivoValidadosConf){
				
				List<TramaConfPagoSiniVentanillaEstadosUpdate> listatBeneUpdateEstado = archivoValidadoConf.getListaBeneUpdate();
				
				//Se envia numero de documento y numeroLote (8 digitos)
				for(TramaConfPagoSiniVentanillaEstadosUpdate beneUpdateEstado : listatBeneUpdateEstado){
					updateBeneTramaConfirmados_SB(beneUpdateEstado.getBeneNumDoc(), beneUpdateEstado.getBeneLoteSerie());
				}
				//Siniestros Manuales
				for(TramaConfPagoSiniVentanillaEstadosUpdate beneUpdateEstado : listatBeneUpdateEstado){
					updateBeneTramaConfirmados_SM(beneUpdateEstado.getBeneNumDoc(), beneUpdateEstado.getBeneLoteSerie());
				}
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
		
	}
	
	public void updateBeneTramaCobros_SB(String beneNumDoc, String beneMonto) throws SyncconException{
		log.info("Inicio");
		try{
			beneficiarioSiniestroMapper.updateBeneTramaCobrados(Constantes.SINI_BENEF_ESTADO_COBRADO, beneNumDoc, beneMonto);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}
	
	public void updateBeneTramaCobros_SM(String beneNumDoc, String beneMonto) throws SyncconException{
		log.info("Inicio");
		try{
			siniManualMapper.updateBeneTramaCobrados(Constantes.SINI_BENEF_ESTADO_COBRADO, beneNumDoc, beneMonto);
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}
	
	public void actualizarBeneficiariosTramaCobros(List<TramaConfPagoSiniVentanilla> listaArchivoValidadosCobros) throws SyncconException{
		log.info("Inicio");
		try{
			for(TramaConfPagoSiniVentanilla archivoValidadoCobros: listaArchivoValidadosCobros){
				
				List<TramaConfPagoSiniVentanillaEstadosUpdate> listatBeneUpdateEstado = archivoValidadoCobros.getListaBeneUpdate();
				
				//Se envia numero de documento y monto.
				for(TramaConfPagoSiniVentanillaEstadosUpdate beneUpdateEstado : listatBeneUpdateEstado){
					updateBeneTramaCobros_SB(beneUpdateEstado.getBeneNumDoc(), beneUpdateEstado.getBeneMonto());
				}
				//Siniestros Manuales
				for(TramaConfPagoSiniVentanillaEstadosUpdate beneUpdateEstado : listatBeneUpdateEstado){
					updateBeneTramaCobros_SM(beneUpdateEstado.getBeneNumDoc(), beneUpdateEstado.getBeneMonto());
				}
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
		
	}

	@Override
	public void updateBeneficiarioFechaAsigna(String loteId, String usuario) throws SyncconException {
		log.info("Inicio");
		try {
			
			log.debug("loteId: "+ loteId);
			log.debug("usuario: "+ usuario);
			beneficiarioSiniestroMapper.updateBeneficiarioFechaAsigna(loteId, usuario);		

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}

		log.info("Fin");
		
	}

	@Override
	public void updateListaBeneficiarioFechaAsigna(List<String> loteId, String usuario) throws SyncconException {
		// TODO Auto-generated method stub
		log.info("Inicio");
		try {
			
			for(String nroLote:loteId){
				updateBeneficiarioFechaAsigna(nroLote, usuario);
			}	

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SyncconException(ErrorConstants.COD_ERROR_BD_ACTUALIZAR);
		}

		log.info("Fin");
	}
	
	public boolean validarExisteLoteIdArchConf(String loteId) throws SyncconException{
		log.info("Inicio");
		Integer cant1 = new Integer(0);
		Integer cant2 = new Integer(0);
		boolean rpt = false;
		try{
			cant1 = beneficiarioSiniestroMapper.validarExisteLoteIdArchConf_SB(loteId);
			cant2 = siniManualMapper.validarExisteLoteIdArchConf_SM(loteId);
			
			if(cant1.intValue() > 0 || cant2.intValue() > 0){
				rpt = true;
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_OBTENER);
		}
		log.info("Fin");
		return rpt;
	}
	
}
