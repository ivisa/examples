package com.cardif.satelite.suscripcion.bean;

public class TipoArchivoBean implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	
	public String tipoArchivo;
	
	
	public String getTipoArchivo()
	{
		return tipoArchivo;
	}

	public void setTipoArchivo(String tipoArchivo)
	{
		this.tipoArchivo = tipoArchivo;
	}
	
} //TipoArchivoBean
