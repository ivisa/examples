package com.cardif.satelite.siniestro.ventanilla.tramas.bbva;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;


	/**
	 * Componente UTIL para la representación de las estructuras e implementación de las validaciones
	 * de los archivos PAGO A PROVEEDORES del BBVA (Confirmados y Cobros). 
	 *
	 *
	 * @author Gilder Ali Fonseca Salvador.
	 * @version 1.0, 18/05/2017
	 *
	 */

public class BBVAPagoProveedor {
	
	//TODO Verificar el codigo de banco para el BBVA
	public static final String BANCO_BBVA_ID = "200";
	
	public static enum DATOS_BENE_UPDATE_ESTADO { PROCESADO_BANCO, COBRADO }
	
	public static enum TIPO_OBLIGATORIEDAD { OBLIGATORIO, OPCIONAL }
	
	public static enum DIVISA_CUENTA_ENUM { PEN, USD };
	
	public static enum DOC_IDENTIDAD_ENUM {	CARNET_DIPLOMATICO("D"), LIBRETA_MILITAR("M"), CARNE_EXTRANGERIA("E"), PASAPORTE("P"), RUC("R"), LIBRETA_ELECTORAL_Y_DNI("L"), SIN_DOCUMENTOS("S");
		
		   private String value;
		   private DOC_IDENTIDAD_ENUM(String value) {
		      this.value = value;
		   }
		   public String getValue() {
		      return value;
		   }
		   
	}
	
	public static enum TIPO_ENUM {	
		   
		ARCHIVO_CONFIRMACION("Archivos de Confirmación."),
		ARCHIVO_COBROS("Archivos de Cobros.");
		
		private String value;
		
		private TIPO_ENUM(String value) {
			this.value = value;
		}
		
		public String getValue() {
		      return value;
		}
		
	}
	
	public static class TRAMA_CONFIRMACION {
		
		public static final String FORMATO_FECHA_DDMMYYYY = "ddMMyyyy";
		
		public static final String CODIGO_DEVOLUCION = "0000";
		
		public static enum VALIDACION_PERTENENCIA { 
			VALIDA("1"), NO_VALIDA("0");
			
			public String value;
			private VALIDACION_PERTENENCIA(String value){
				this.value = value;
			}
		};
		
		public static enum SIGNO_IMPORTE { 
			POSITIVO("1"), NEGATIVO("2");
			
			public String value;
			private SIGNO_IMPORTE(String value){
				this.value = value;
			}
		};
		
		public static boolean validarSignoImporte(String signoImporte){
			if(SIGNO_IMPORTE.POSITIVO.value.equals(signoImporte) || SIGNO_IMPORTE.NEGATIVO.value.equals(signoImporte)){
				return true;
			}
			return false;
		}
		
		
		public enum TIPO_TRAMA{
			
			PRIMER_REGISTRO_ORDENANTE_3110("3110", 1),
			SEGUNDO_REGISTRO_ORDENANTE_3120("3120", 2),
			TERCER_REGISTRO_ORDENANTE_3130("3130", 3),

			PRIMER_REGISTRO_PROVEEDOR_3210("3210", 4),
			SEGUNDO_REGISTRO_PROVEEDOR_3220("3220", 5),
			TERCER_REGISTRO_PROVEEDOR_3230("3230", 6),
			CUARTO_REGISTRO_PROVEEDOR_3240("3240", 7),
			QUINTO_REGISTRO_PROVEEDOR_3250("3250", 8),
			REGISTRO_DETALLE_FACTURAS_3310("3310", 9),
			REGISTRO_TOTALES_FACTURAS_3810("3810", 10),

			REGISTRO_PIE_FICHERO_3910("3910", 11);
			
			private String value;
			private int orden;
			
			private TIPO_TRAMA(String value, int orden) {
				this.value = value;
				this.orden = orden;
			}
			
			public String getValue() {
			    return value;
			}
			
			public int getOrden(){
				return orden;
			}
		};
		
		public enum CAMPO_COD_REG {
			
			CODIGO_REGISTRO("Código de registro", 1);
			
			public String nombreCampo;
			public int ordenCampo;
			
			private CAMPO_COD_REG(String nombreCampo, int ordenCampo){
				this.nombreCampo = nombreCampo;
				this.ordenCampo = ordenCampo;
			}
			
		}
		
		public enum ORDEN_CAMPOS_3110 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			FECHA_CREACION_FICHERO(4),
			FECHA_PROCESO(5),
			CUENTA_ORDENANTE(6),
			DIVISA_CUENTA(7),
			LIBRE1(8),
			VALIDACION_PERTENENCIA(9),
			INDICADOR_DEVOLUCION(10),
			NOMBRE_ARCHIVO(11),
			SERVICIO(12),
			LIBRE2(13);
			
			private int value;
			
			private ORDEN_CAMPOS_3110(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3120 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			NOMBRE_ORDENANTE(4),
			DOMICILIO_ORDENANTE(5),
			LIBRE(6);
			
			private int value;
			
			private ORDEN_CAMPOS_3120(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3130 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			DISTRITO_ORDENANTE(4),
			PROVINCIA_ORDENANTE(5),
			DEPARTAMENTO_ORDENANTE(6),
			LIBRE(7);
			
			private int value;
			
			private ORDEN_CAMPOS_3130(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3210 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			TIP_DOC_PROVEEDOR(4),
			DOCUMENTO_PROVEEDOR(5),
			NOMBRE_PROVEEDOR(6),
			IMPORTE_1_ENTEROS(7),
			IMPORTE_2_DECIMAL(8),
			DIVISA(9),
			LIBRE1(10),
			CODIGO_DEVOLUCION(11),
			MENSAJE_DEVOLUCION(12),
			LIBRE2(13);
			
			private int value;
			
			private ORDEN_CAMPOS_3210(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3220 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			TIP_DOC_PROVEEDOR(4),
			DOCUMENTO_PROVEEDOR(5),
			COD_BANCO_PROVEEDOR(6),
			CUENTA_PROVEEDOR(7),
			DOMICILIO_PROVEEDOR(8),
			FORMA_PAGO(9),
			LIBRE1(10),
			TIPO_CUENTA(11),
			LIBRE2(12);
			
			private int value;
			
			private ORDEN_CAMPOS_3220(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3230 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			TIP_DOC_PROVEEDOR(4),
			DOCUMENTO_PROVEEDOR(5),
			DISTRITO_PROVEEDOR(6),
			PROVINCIA_PROVEEDOR(7),
			DEPARTAMENTO_PROVEEDOR(8),
			CONFIRMACION_PROVEEDOR(9),
			CORREO_ELEC_PROVEEDOR(10),
			TELEFONO_CELULAR_FAX_PROVEEDOR(11),
			LIBRE(12);
		
			private int value;
			
			private ORDEN_CAMPOS_3230(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3240 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			TIP_DOC_PROVEEDOR(4),
			DOCUMENTO_PROVEEDOR(5),
			CONCEPTO_1(6),
			CONCEPTO_2(7),
			LIBRE(8);
		
			private int value;
			
			private ORDEN_CAMPOS_3240(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3250{
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			TIP_DOC_PROVEEDOR(4),
			DOCUMENTO_PROVEEDOR(5),
			CONCEPTO_3(6),
			CONCEPTO_4(7),
			LIBRE(8);
		
			private int value;
			
			private ORDEN_CAMPOS_3250(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3310 {
		
			CODIGO_REGISTRO(1),
			TIP_DOC_EMISOR(2),
			DOCUMENTO_EMISOR(3),
			TIP_DOC_PROVEEDOR(4),
			DOCUMENTO_PROVEEDOR(5),
			TIP_DOC_PAGADO_PROVEEDOR(6),
			DOCUMENTO_PAGADO_PROVEEDOR(7),
			FECHA_DOC_PAGADO(8),
			FECHA_VENCIMIENTO_DOCUMENTO(9),
			DIVISA_DOC_PAGADO(10),
			IMPORTE_1_PARTE_ENTERA(11),
			IMPORTE_2_PARTE_DECIMAL(12),
			SIGNO_IMPORTE(13),
			CONCEPTO_DOC_PAGADO(14),
			LIBRE(15);
		
			private int value;
			
			private ORDEN_CAMPOS_3310(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3810 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_EMISOR(2),
			DOCUMENTO_EMISOR(3),
			TIP_DOC_PROVEEDOR(4),
			DOCUMENTO_PROVEEDOR(5),
			NRO_REGISTROS(6),
			NRO_TOTAL_DOCUMENTOS(7),
			IMPORTE_TOTAL_DOCUMENTOS_PARTE_ENTERA(8),
			IMPORTE_TOTAL_DOCUMENTOS_PARTE_DECIMAL(9),
			LIBRE(10);
			
			private int value;
			
			private ORDEN_CAMPOS_3810(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public enum ORDEN_CAMPOS_3910 {
			
			CODIGO_REGISTRO(1),
			TIP_DOC_ORDENANTE(2),
			DOCUMENTO_ORDENANTE(3),
			NRO_TOTAL_REGISTROS(4),
			NRO_TOTAL_OPERACIONES(5),
			IMPORTE_PARTE_ENTERA(6),
			IMPORTE_PARTE_DECIMAL(7),
			LIBRE(8);
			
			private int value;
			
			private ORDEN_CAMPOS_3910(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		public static boolean validarTipoDocumento(String tipDocOrdenanteLineaTrama){
					
					if(BBVAPagoProveedor.DOC_IDENTIDAD_ENUM.CARNET_DIPLOMATICO.getValue().equals(tipDocOrdenanteLineaTrama) ||
							BBVAPagoProveedor.DOC_IDENTIDAD_ENUM.LIBRETA_MILITAR.getValue().equals(tipDocOrdenanteLineaTrama) || 
								BBVAPagoProveedor.DOC_IDENTIDAD_ENUM.CARNE_EXTRANGERIA.getValue().equals(tipDocOrdenanteLineaTrama) || 
									BBVAPagoProveedor.DOC_IDENTIDAD_ENUM.PASAPORTE.getValue().equals(tipDocOrdenanteLineaTrama) ||
										BBVAPagoProveedor.DOC_IDENTIDAD_ENUM.RUC.getValue().equals(tipDocOrdenanteLineaTrama) ||
											BBVAPagoProveedor.DOC_IDENTIDAD_ENUM.LIBRETA_ELECTORAL_Y_DNI.getValue().equals(tipDocOrdenanteLineaTrama) ||
												BBVAPagoProveedor.DOC_IDENTIDAD_ENUM.SIN_DOCUMENTOS.getValue().equals(tipDocOrdenanteLineaTrama)){
						return true;
					}
					
					return false;
		}
		
		public static boolean validarCodigoRegistro(String codigoRegistro){
			
			if(TIPO_TRAMA.PRIMER_REGISTRO_ORDENANTE_3110.getValue().equals(codigoRegistro) || 
					TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue().equals(codigoRegistro) ||
							TIPO_TRAMA.TERCER_REGISTRO_ORDENANTE_3130.getValue().equals(codigoRegistro) ||
									TIPO_TRAMA.PRIMER_REGISTRO_PROVEEDOR_3210.getValue().equals(codigoRegistro) ||
											TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue().equals(codigoRegistro) ||
													TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue().equals(codigoRegistro) ||
															TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240.getValue().equals(codigoRegistro) ||
																	TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue().equals(codigoRegistro) ||
																			TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue().equals(codigoRegistro) ||
																					TIPO_TRAMA.REGISTRO_TOTALES_FACTURAS_3810.getValue().equals(codigoRegistro) ||
																							TIPO_TRAMA.REGISTRO_PIE_FICHERO_3910.getValue().equals(codigoRegistro)){
				return true;
			
			}
			
			return false;
		}
		
		
		public enum TIPO_DOC_PAGO_PROVEEDOR {
			
			FACTURA("1"),
			NOTA_CREDITO("2"),
			NOTA_DEBITO("3");
			
			public String value;
			
			private TIPO_DOC_PAGO_PROVEEDOR(String value) {
				this.value = value;
			}
		}
		
		public static boolean validarTipoDocPagoProveedor(String tipDocPagProv){
			if(TIPO_DOC_PAGO_PROVEEDOR.FACTURA.value.equals(tipDocPagProv) ||
					TIPO_DOC_PAGO_PROVEEDOR.NOTA_CREDITO.value.equals(tipDocPagProv) ||
						TIPO_DOC_PAGO_PROVEEDOR.NOTA_DEBITO.value.equals(tipDocPagProv)){
				return true;
			}
			return false;
		}
		
		
		public enum CONFIRMACION_PROVEEDOR {
			
			NO_ENVIAR("N"),
			CORREO_ELECTRONICO("E"),
			MENSAJE_SMS("S"),
			CORREO_ELECTRONICO_y_SMS("A"),
			ENVIO_FAX("F");
			
			public String value;
			
			private CONFIRMACION_PROVEEDOR(String value) {
				this.value = value;
			}
		}
		
		public static boolean validarConfProveedor(String confProv){
			if(CONFIRMACION_PROVEEDOR.NO_ENVIAR.value.equals(confProv) ||
					CONFIRMACION_PROVEEDOR.CORREO_ELECTRONICO.value.equals(confProv) ||
						CONFIRMACION_PROVEEDOR.MENSAJE_SMS.value.equals(confProv) ||
							CONFIRMACION_PROVEEDOR.CORREO_ELECTRONICO_y_SMS.value.equals(confProv) ||
								CONFIRMACION_PROVEEDOR.ENVIO_FAX.value.equals(confProv)){
				return true;
			}
			
			return false;
		}
		
		/**
		 * 
		 * @author Gilder Ali Fonseca Salvador.
		 * @version 1.0, 25/05/2017
		 * 
		 * I. Descripcion
		 * --------------
		 * Implementacion de Automata para Validar secuencialmente los codigos de los registros 
		 * del archivo de confirmacion del BBVA (PAGO A PROVEEDORES), se
		 * detalla la especificacion por el BBVA:
		 * 
		 * Especificacion por el BBVA
		 * ------------------------
		 * 
		 * Datos del Ordenante:
		 * Primer registro de ordenante		        Obligatorio		3110
		 * Segundo Registro de ordenante    		Obligatorio     3120
		 * Tercer registro de ordenante     		Opcional        3130
		 * 
		 * Datos del Proveedor:
		 * Primer registro de Proveedor     		Obligatorio     3210
		 * Segundo registro de Proveedor    		Obligatorio     3220
		 * Tercer registro de Proveedor     		Opcional        3230
		 * Cuarto registro de Proveedor (Conceptos)	Opcional        3240
		 * Quinto registro de Proveedor (Conceptos) Opcional        3250
		 * Registro de detalle de facturas          Opcional        3310
		 * Registro de totales de facturas          Opcional        3810
		 * 
		 * Datos de Control:
		 * Registro de pie de fichero   			Obligatorio     3910
		 * 
		 * Notas :
		 * - Por cada Proveedor puede informarse “n” registros 3310 
		 *   que corresponden a cada una de las facturas pagadas.
		 * - En caso de informar por lo menos un registro 3310, se deberá informar 
		 *   un registro 3810 de total de facturas informadas.
		 * 
		 *
		 */
		public static class AutomataValidacionVerticalCodigosRegistros{
		
			private static List<String> lstCodReg = null;
			private static int estado;
			private static int ind;
			private static String codRegActual = null;
			private static String codRegAnterior = null;
			
			
			public static boolean runAutomata(List<String> listaCodReg){
				
				if(listaCodReg == null || listaCodReg.size() == 0){
					return false;
				}
				
				lstCodReg = listaCodReg;
				estado = 0;
				ind = 0;
				codRegActual = "";
				codRegAnterior = "";
				
				for(;;){
					estado = scanerCodReg();
					switch(estado){
					//3110
					case 1: if(ind == 0){
								ind++;
								codRegAnterior = new String(codRegActual);
								continue;
							}else return false;
					//3120
					case 2: if(TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_ORDENANTE_3110.getValue().equals(codRegAnterior)){
								ind++;
								codRegAnterior = new String(codRegActual);
								continue;
							}else return false;
					//3130	
					case 3: if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;					
					//3210	
					case 4: if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_ORDENANTE_3130.getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;		
					//3220
					case 5: if(TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_PROVEEDOR_3210.getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;
					//3230
					case 6: if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;
					//3240
					case 7: if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;
					//3250
					case 8: if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240 .getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;
					//3310
					case 9: if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue().equals(codRegAnterior) ||
								TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;
					//3810
					case 10: if(TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue().equals(codRegAnterior)){
								codRegAnterior = new String(codRegActual);
								ind++;
								continue;
							}else return false;
					//3910
					case 11: if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue().equals(codRegAnterior) ||
								 TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue().equals(codRegAnterior) ||
								 TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240.getValue().equals(codRegAnterior) ||
								 TRAMA_CONFIRMACION.TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue().equals(codRegAnterior) ||
								 TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_TOTALES_FACTURAS_3810.getValue().equals(codRegAnterior)){
								return true;
							}else return false;
					
					case 999:  return false;
						
					}
				}
				
			}
			
			private static int scanerCodReg(){
				
				//Si el indice es igual al size de la lista, significa que ya se termino de leer todos los elementos.
				if(lstCodReg.size() == ind){
					return 999;
				}
				
				codRegActual = lstCodReg.get(ind);
				
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_ORDENANTE_3110.getValue().equals(codRegActual)){
					estado = 1;
					return estado;
				}else
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_ORDENANTE_3120.getValue().equals(codRegActual)){
					estado = 2;
					return estado;
				}else
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_ORDENANTE_3130.getValue().equals(codRegActual)){
					estado = 3;
					return estado;
				}else
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.PRIMER_REGISTRO_PROVEEDOR_3210.getValue().equals(codRegActual)){
					estado = 4;
					return estado;
				}else 
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.SEGUNDO_REGISTRO_PROVEEDOR_3220.getValue().equals(codRegActual)){
					estado = 5;
					return estado;
				}else 
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.TERCER_REGISTRO_PROVEEDOR_3230.getValue().equals(codRegActual)){
					estado = 6;
					return estado;
				}else 
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.CUARTO_REGISTRO_PROVEEDOR_3240 .getValue().equals(codRegActual)){
					estado = 7;
					return estado;
				}else 
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.QUINTO_REGISTRO_PROVEEDOR_3250.getValue().equals(codRegActual)){
					estado = 8;
					return estado;
				}else 
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_DETALLE_FACTURAS_3310.getValue().equals(codRegActual)){
					estado = 9;
					return estado;
				}else 
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_TOTALES_FACTURAS_3810.getValue().equals(codRegActual)){
					estado = 10;
					return estado;
				}else 
				if(TRAMA_CONFIRMACION.TIPO_TRAMA.REGISTRO_PIE_FICHERO_3910.getValue().equals(codRegActual)){
					estado = 11;
					return estado;
				}
				
				return 999;
			}
			
			/**
			 * 
			 * @param String, nombreArchivo
			 * @return String, mensaje de error de secuencia de codigo de registro al procesar el archivo.
			 */
			public static String GET_MSJ_ERROR_SECUENCIA_COD_REG(String nombreArchivo){
				
				return "Error en la secuencia en el campo 'Código de registro' del archivo: '" + nombreArchivo + "'.";
			
			}
		}
		
		public static boolean validarValidacionPertenencia(String validacionPertenencia){
			if(VALIDACION_PERTENENCIA.NO_VALIDA.value.equals(validacionPertenencia) ||
					VALIDACION_PERTENENCIA.VALIDA.value.equals(validacionPertenencia)){
				return true;
			}
			return false;
		}
		
		private static final String INDICADOR_DEVOLUCION = "0";
		
		public static boolean validarIndicadorDevolucion(String indicadorDevolucion){
			if(INDICADOR_DEVOLUCION.equals(indicadorDevolucion)){
				return true;
			}
			return false;
		}
		
		
		
		public enum FORMA_PAGO {
			
			ABONO_CTA_PROPIO_BANCO("P"),
			ABONO_CTA_INTERBANCARIA("I"),
			ORDEN_PAGO("O");
			
			public String value;
			
			private FORMA_PAGO(String value) {
				this.value = value;
			}
		}
		
		public static boolean validarFormaPago(String formaPago){
			if(FORMA_PAGO.ABONO_CTA_INTERBANCARIA.value.equals(formaPago) || 
						FORMA_PAGO.ABONO_CTA_PROPIO_BANCO.value.equals(formaPago) ||
								FORMA_PAGO.ORDEN_PAGO.value.equals(formaPago)){
				return true;
			}
			return false;
		}
		
		public enum TIPO_CUENTA {
			
			PROPIO_TITULAR("01"),
			OTRO_TITULAR("02"),
			ABONO_CTA_PROPIO_BANCO_y_ORDEN_PAGO ("00");
			
			public String value;
			
			private TIPO_CUENTA(String value) {
				this.value = value;
			}
		}
		
		public static boolean validarTipoCuenta(String tipoCuenta){
			
			if(TIPO_CUENTA.PROPIO_TITULAR.value.equals(tipoCuenta) ||
					TIPO_CUENTA.OTRO_TITULAR.value.equals(tipoCuenta) ||
						TIPO_CUENTA.ABONO_CTA_PROPIO_BANCO_y_ORDEN_PAGO.value.equals(tipoCuenta)){
				return true;				
			}
			return false;
		}
		
		public static String GET_MSJ_ERROR_LOTE_SERIE_NO_EXISTE(String nombreArchivo){
			
			return "El nombre del archivo '" + nombreArchivo + "' no coincide con ningún Número de Lote existente.";
			
		}
		
	}
	
	public static enum RPT_PROC_TRAMA_ENUM { LISTA_ARCHIVOS_VALIDOS, LISTA_BUFFER_ERRORES }
	
	public static class TRAMA_COBROS {
		
		//TODO Configurar el id correcto
		public static final String TRAMA_ID = "9999";
		
		public static final String MSJ_ERROR_CAMPO = "Error en la linea ";
		
		public static final String FORMATO_FECHA_YYYYMMDD = "yyyyMMdd";
		
		public static enum NUM_ORDEN_CAMPO {	
			   
			NOMBRE_ARCHIVO(1),
			FECHA_EMISION(2),
			FECHA_COBRO(3),
			NRO_DOC_BENEFICIARIO(4),
			NOMBRE_BENEFICIARIO(5),
			IMPORTE_PARTE_ENTERA(6),
			IMPORTE_PARTE_DECIMAL(7),
			DIVISA(8),
			NUMERO_ORDEN(9),
			CODIGO_INTERNO(10),
			NUMERO_CHEQUE(11),
			COD_OFICINA_EMI_COBRO(12),
			OFICINA_EMI_COBRO(13);
			
			private int value;
			
			private NUM_ORDEN_CAMPO(int value) {
				this.value = value;
			}
			
			public int getValue() {
			      return value;
			}
		}
		
		/**
		 * 
		 * @param nombreArchivo, Formato: 23010901.PAP
		 * @return
		 */
		public static boolean validarNomArchivo(String nombreArchivo){
			
			try{
				
				String [] arraySplit = nombreArchivo.split("\\.");
				
				if(arraySplit[0].length() != 8){
					return false;
				}
				
				@SuppressWarnings("unused")
				Long parteNumero = new Long(arraySplit[0]);
				//log.
				if(arraySplit[1].equals("PAP"))
					return true;
				
			}catch(Exception e){
				//e.printStackTrace();
				return false;
			}
			
			return false;
			
		}
		
	}
	
	
	public static String GET_MSJ_ERROR_CAMPO(String nombreArchivo, int nroLinea, int numOrdCampo, String nombreCampo){
		
		return "Error en el archivo '" + nombreArchivo + "', en la linea: '" + nroLinea + "', en el campo: " + "'(" + numOrdCampo + ") " + nombreCampo + "'.";
		
	}
	
	
	public static String GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(String nombreArchivo, int nroLinea, int longitudLineaOK, int longitudLineaERROR){
		
		return "Error en el archivo '" + nombreArchivo + "', en la linea: '" + nroLinea + "', Se esperaba una linea de (" + longitudLineaOK + " caracteres) "
				+ "pero la actual tiene una longitud de (" + longitudLineaERROR + " caracteres).";
		
	}
	
	public static String GET_MSJ_ERROR_LONGITUD_LINEA_CAMPOS(String nombreArchivo, int nroLinea, String codRegistro, int longitudLineaOK, int longitudLineaERROR){
		
		return "Error en el archivo '" + nombreArchivo + "', en la linea: '" + nroLinea + " (código de registro = " + codRegistro + ")', Se esperaba una linea de (" + longitudLineaOK + " caracteres) "
				+ "pero la actual tiene una longitud de (" + longitudLineaERROR + " caracteres).";
		
	}
	
	/**
	 * 
	 * @param String, nombreArchivo
	 * @param String, linea
	 * @return String, mensaje de error general al procesar el archivo.
	 */
	public static String GET_MSJ_ERROR_DESCONOCIDO_PROCESAMIENTO_ARCHIVO(String nombreArchivo, int linea){
		
		return "Error desconocido en el procesamiento del archivo '" + nombreArchivo + "', en la linea: '" + linea + ".";
		
	}
	
	public static String GET_MSJ_ERROR_ARCHIVO_VACIO(String nombreArchivo){
		
		return "El archivo '" + nombreArchivo + "' está vacío.";
		
	}
	
	/**
	 * 
	 * @param cadenaFecha, Formato: AAAAMMDD 
	 * @return boolean
	 */
	public static boolean validarCampoFecha(String cadenaFecha, String formatoFecha){
		try{
			
			cadenaFecha = cadenaFecha.trim();
			int anioIngresado = 0;
			
			if(BBVAPagoProveedor.TRAMA_CONFIRMACION.FORMATO_FECHA_DDMMYYYY.equals(formatoFecha)){
				anioIngresado = Integer.valueOf(cadenaFecha.substring(4));
			}else if(BBVAPagoProveedor.TRAMA_COBROS.FORMATO_FECHA_YYYYMMDD.equals(formatoFecha)){
				anioIngresado = Integer.valueOf(cadenaFecha.substring(0, 4));
			}
			
			/**
			 * El año ingresado no puede ser mayor al año actual ni menor al 2005.
			 */
			int anioActual = Calendar.getInstance().get(Calendar.YEAR);
			
			if(anioIngresado < 2000 || anioIngresado > anioActual){				return false;
			}

			SimpleDateFormat sdf = new SimpleDateFormat(formatoFecha);
			/**
			 *  setLenient(false), método que permite que sea posible validar la fecha exacta
			 *  por ejemplo si tenemos la fecha 20170229 devuelve false por que febrero del 2017 solo tiene hasta el dia 28,
			 *  la fecha correcta seria 20170228.
			 */
			sdf.setLenient(false);
			
			/**
			 *  Comprueba si la fecha es valida.
			 */
			@SuppressWarnings("unused")
			Date fechita = sdf.parse(cadenaFecha);
			return true;
			
		}catch(Exception e){
			//e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * 
	 * @param campoNumerico
	 * @return boolean
	 */
	public static boolean validarCampoNumerico(String campoNumerico){
		
		try{
			@SuppressWarnings("unused")
			Long nroDocumentoLong = new Long(campoNumerico);
			//log.
			return true;
			
		}catch(Exception e){
			//e.printStackTrace();
			return false;
		}
		
	}
	
	
	public static class AutomataValidarCampoNumerico{
		
		static private String campoNumero;
		static private char car;
		static private int estado=0;
		static private int estadoAnt=0;
		static private int ind = 0;
		static private String TOKEN_FIN = "#";
		
		static public enum TIPO {NRO_CUENTA, NUMERICO, NRO_DOC_PAG_PROVEEDOR};
		
		public static boolean runAutomata(String valorNumerico, String tipoDato){
			
			//Inicializar valores
			campoNumero = "";
			estado=0;
			estadoAnt=0;
			ind = 0;
			
			if(StringUtils.isBlank(valorNumerico)){
				return false;
			}
			//Quitar espacios adelante y al final si hubieran.
			valorNumerico = valorNumerico.trim();
			
			if(TIPO.NRO_CUENTA.name().equals(tipoDato)){
				//Reemplazar si hay espacios en blanco intermedios.
				campoNumero = valorNumerico.replaceAll("\\s", "") + TOKEN_FIN;
			}else if(TIPO.NUMERICO.name().equals(tipoDato)){
				campoNumero = valorNumerico + TOKEN_FIN;
			}else if(TIPO.NRO_DOC_PAG_PROVEEDOR.name().equals(tipoDato)){
				//Reemplazar si hay espacios en blanco intermedios.
				campoNumero = valorNumerico.replaceAll("-", "") + TOKEN_FIN;
			}
			
			for(;;){
				
				estado = scannerCaracter();
				
				switch(estado){
				case 1: 	ind++;
							estadoAnt = estado;
							continue;					
				case 2: if(car == '#' && estadoAnt == 1){
							return true;
						}
				case 999: return false;
				}
			}
			
		}
		
		private static int scannerCaracter() {
			
//			if(ind >= campoNumero.length()){
//				return 999;
//			}
			
			car = campoNumero.charAt(ind);
			
			if(Character.isDigit(car)){
				estado = 1;
				return estado;
			}else if(car == '#'){
				estado = 2;
				return estado;
			}
			
			return 999;
		}
		
		
		
	}
	
	/**
	 * 
	 * @param divisa
	 * @return boolean
	 */
	public static boolean validarDivisa(String divisa){
		
		if(DIVISA_CUENTA_ENUM.PEN.name().equals(divisa) || DIVISA_CUENTA_ENUM.USD.name().equals(divisa)){
			return true;
		}
		return false;
	}
	


	
}
