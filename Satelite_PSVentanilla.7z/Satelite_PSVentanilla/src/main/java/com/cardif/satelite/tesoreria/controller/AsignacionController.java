package com.cardif.satelite.tesoreria.controller;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.print.attribute.standard.Severity;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.richfaces.model.selection.SimpleSelection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.FirmantePar;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.siniestro.service.SiniBeneficiariosService;
import com.cardif.satelite.siniestro.service.SiniManualService;
import com.cardif.satelite.tesoreria.bean.JournalBean;
import com.cardif.satelite.tesoreria.model.Cheque;
import com.cardif.satelite.tesoreria.model.FirmanteLoteEnvioAdjunto;
import com.cardif.satelite.tesoreria.model.TramaGeneraDet;
import com.cardif.satelite.tesoreria.service.ChequeService;
import com.cardif.satelite.tesoreria.service.FirmanteLoteEnvioAdjuntoService;
import com.cardif.satelite.tesoreria.service.FirmanteService;
import com.cardif.satelite.tesoreria.service.ProcesoPagos;
import com.cardif.satelite.tesoreria.service.TramaGeneraDetService;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;
import com.cardif.sunsystems.util.ConstantesSun;

@Controller
@Scope("request")
public class AsignacionController extends BaseController implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final Logger LOGGER = Logger.getLogger(AsignacionController.class);

	private String banco;
	private List<SelectItem> bancos;
	private Date fechaDesde;
	private Date fechaHasta;
	private String numeroCheque;
	private List<Cheque> cheques;
	private Long par;
	private List<SelectItem> pares;
	private Boolean mostrar;
	private String nroLote;

	private List<SelectItem> tipoPagoItems;
	private List<SelectItem> medioPagoItems;
	private String idTipoPago;
	private String idMedioPago;
	private Cheque chequeSeleccionado;
	static final String VER_DETALLE = "ver detalle";
	static final String TIPO_PAGO_MASIVO = "1";
	static final String MEDIO_PAGO_ELECTRONICO = "5";
	static final String PAGO_ELECTRONIC = "PAGO ELECTRONIC";
	private List<TramaGeneraDet> listaTramaGeneraDetalle;
	private ArrayList<File> archivosAdjuntos = new ArrayList<File>();
	private int cantidadArchivos;
	private SimpleSelection selection;
	private boolean existeCarga;
	private long tamanioMaximoArchivos;
	private String mensajeError;
	private List<Cheque> listaSiniestros;

	public List<TramaGeneraDet> getListaTramaGeneraDetalle() {
		return listaTramaGeneraDetalle;
	}

	public void setListaTramaGeneraDetalle(List<TramaGeneraDet> listaTramaGeneraDetalle) {
		this.listaTramaGeneraDetalle = listaTramaGeneraDetalle;
	}

	@Autowired
	private ChequeService chequeService;

	@Autowired
	private FirmanteService firmanteService;

	@Autowired(required = true)
	private ProcesoPagos procesoPagos;

	@Autowired
	private TramaGeneraDetService tramaGeneraDetService;

	@Autowired
	private ParametroService parametroServcie;

	@Autowired
	private FirmanteLoteEnvioAdjuntoService firmanteLoteEnvioAdjuntoService;

	@Autowired
	private SiniBeneficiariosService siniBeneficiariosService;

	@Autowired
	private SiniManualService siniManualService;

	@Override
	@PostConstruct
	public String inicio() {

		try {
			if (tieneAcceso()) {

				LOGGER.info("Inicio");
				this.bancos = new ArrayList<SelectItem>();
				this.bancos.add(new SelectItem(null, "Seleccionar banco"));
				List<String> bancos = chequeService.obtenerBancos();
				for (String banco : bancos) {
					this.bancos.add(new SelectItem(banco, banco));
				}

				this.pares = new ArrayList<SelectItem>();
				this.pares.add(new SelectItem(null, "Seleccionar"));
				List<FirmantePar> pares = firmanteService.buscarPares();
				for (FirmantePar par : pares) {
					this.pares.add(new SelectItem(par.getCodigo(), par.getFirmante1() + " - " + par.getFirmante2()));
				}
				tipoPagoItems = new ArrayList<SelectItem>();
				List<SelectItem> listaTipoPagoItems = procesoPagos.traerListaTipoPagoItems();
				for (SelectItem a : listaTipoPagoItems) {
					tipoPagoItems.add(a);
				}
				medioPagoItems = new ArrayList<SelectItem>();
				List<SelectItem> listaMedioPagoItems = procesoPagos.traerListaMedioPagoItems();
				for (SelectItem b : listaMedioPagoItems) {
					medioPagoItems.add(b);
				}
				Parametro parametro = new Parametro();
				parametro = parametroServcie.obtener(Constantes.COD_PARAM_SIZE_MAX_ADJUNTOS, Constantes.TIP_PARAM_DETALLE, "1");
				tamanioMaximoArchivos = Long.parseLong(parametro.getNomValor().trim());
				mostrar = Boolean.FALSE;
				LOGGER.info("Fin");
			}
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			LOGGER.error("Hay una excepcion");
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}

	public String buscar() {
		cantidadArchivos = 0;
		if (this.fechaHasta != null && this.fechaDesde != null) {
			if (!this.fechaHasta.after(this.fechaDesde) && !this.fechaDesde.equals(this.fechaHasta)) {

				SateliteUtil.mostrarMensaje("La fecha desde debe ser menor a la fecha hasta");
				return null;
			}
		}
		if(banco==null || banco.trim().length()==0){
			SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN,"Debe seleccionar banco");
			return null;
		}
		buscarCheques();
		LOGGER.info("Fin");

		return null;
	}

	private void buscarCheques() {
		existeCarga = false;
		cantidadArchivos = 0;
		String fechaDesde = SateliteUtil.getFormatDate(this.fechaDesde);
		String fechaHasta = SateliteUtil.getFormatDate(this.fechaHasta);
		LOGGER.info("Fecha desde: " + fechaDesde);
		LOGGER.info("Fecha hasta: " + fechaHasta);
		LOGGER.info("Banco: " + banco);
		LOGGER.info("Número de cheque: " + numeroCheque);

		cheques = chequeService.buscar(banco, numeroCheque, fechaDesde, fechaHasta);
		if (cheques != null && cheques.size() > 0) {
			for (Cheque itemCheque : cheques) {
				if (isSiniestro(itemCheque.getNumero())) {
					itemCheque.setVerDetalle(VER_DETALLE);
				}
			}
			if (nroLote != null && nroLote.trim().length() > 0) {
				listaSiniestros = new ArrayList<Cheque>();
				for (Cheque itemCheque : cheques) {
					if (itemCheque.getNumero().trim().contains(nroLote)) {
						listaSiniestros.add(itemCheque);
					}
				}
				cheques.clear();
				cheques.addAll(listaSiniestros);
			}
			if (banco.trim().equals(Constantes.ELECTRONICO_SINIESTRO_BBVA)) {

				listaSiniestros = new ArrayList<Cheque>();
				for (Cheque itemCheque : cheques) {
					if (isSiniestro(itemCheque.getNumero().trim())) {
						listaSiniestros.add(itemCheque);
					}
				}
				Collections.sort(listaSiniestros, Cheque.referenciaDiarioComparator);

				cheques.clear();
				cheques.addAll(agruparSiniestros(listaSiniestros));
			}
		}
	}

	private List<Cheque> agruparSiniestros(List<Cheque> listaChequesAgrupar) {
		List<Cheque> chequesAgrupados = new ArrayList<Cheque>();
		BigDecimal montoTotal = new BigDecimal("0");
		Cheque agregaItem = new Cheque();
		int band = 0;
		for (Cheque itemCheque : listaChequesAgrupar) {
			if (band == 0) {
				agregaItem = itemCheque;
				montoTotal = montoTotal.add(itemCheque.getImporte());
				band = 1;
			} else {
				if (itemCheque.getNumero().trim().equals(agregaItem.getNumero().trim()) && itemCheque.getDiario().equals(agregaItem.getDiario())) {
					montoTotal = montoTotal.add(itemCheque.getImporte());
				} else {
					agregaItem.setNombreBeneficiario("-------");
					agregaItem.setImporte(montoTotal);
					chequesAgrupados.add(agregaItem);
					agregaItem = new Cheque();
					montoTotal = new BigDecimal("0");
					agregaItem = itemCheque;
					montoTotal = montoTotal.add(itemCheque.getImporte());
				}
			}
		}
		if (montoTotal.doubleValue() > 0 && agregaItem != null) {
			agregaItem.setNombreBeneficiario("-------");
			agregaItem.setImporte(montoTotal);
			chequesAgrupados.add(agregaItem);
		}
		return chequesAgrupados;
	}

	private boolean isSiniestro(String numeroLoteCheque) {
		if (numeroLoteCheque.contains(Constantes.SINIESTRO_SOLES) || numeroLoteCheque.contains(Constantes.SINIESTRO_DOLAR)) {
			return true;
		}
		return false;
	}

	public String limpiar() {
		LOGGER.info("limpia filtros: ");
		fechaDesde = null;
		fechaHasta = null;
		numeroCheque = null;
		banco = null;
		nroLote = "";
		cheques = new ArrayList<Cheque>();
		par=null;
		return null;
	}

	public void pintar(OutputStream os, Object obj) {
		String path = SateliteUtil.getPath("/templates");
		String rutaPDF = path + File.separator + "PDF_CHEQUE_MAQUETA.pdf";

		try {

			File archivo = new File(rutaPDF);

			byte[] bytes = new byte[(int) archivo.length()];

			FileInputStream input = new FileInputStream(archivo);
			input.read(bytes);
			input.close();
			os.write(bytes);
			// os.flush();

		} catch (IOException e) {
			log.error("Erreur lors de la generation du PDF", e);
		}
	}

	public String prepararVisualizacion() {
		mostrar = Boolean.FALSE;
		String mensaje = chequeService.generarPrevisualizacion(cheques, par, Boolean.FALSE);
		if (mensaje.equalsIgnoreCase(SateliteConstants.MENSAJE_PDF_EXITO)) {
			mostrar = Boolean.TRUE;
		} else {
			SateliteUtil.mostrarMensaje(mensaje);
		}
		return null;

	}

	public String asignar() {
		mensajeError="";
		String usuario = SecurityContextHolder.getContext().getAuthentication().getName();
		String mensaje = "Los cheques han sido registrados";
		try {
			if (validarFormulario()) {
				validarArchivo();
				List<String> rutaAdjuntos = new ArrayList<String>();
				List<FirmanteLoteEnvioAdjunto> firmantesAdjunto = new ArrayList<FirmanteLoteEnvioAdjunto>();
				for (File itemFile : archivosAdjuntos) {
					rutaAdjuntos.add(itemFile.getPath());
					FirmanteLoteEnvioAdjunto firmanteAdjunto = new FirmanteLoteEnvioAdjunto();
					firmanteAdjunto.setAdjunto(Utilitarios.readBytesFromFile(itemFile.getPath()));
					String[] obtenerNombre = itemFile.getName().split("_");
					String nombreFinal = obtenerNombre[1].toLowerCase().replace(".pdf", "");
					firmanteAdjunto.setLoteId(nombreFinal);
					firmantesAdjunto.add(firmanteAdjunto);
				}
				if (firmantesAdjunto.size() > 0 && banco.trim().equals(Constantes.ELECTRONICO_SINIESTRO_BBVA) ) {
					firmanteLoteEnvioAdjuntoService.insertFirmanteLoteEnvioAdjuntos(firmantesAdjunto);
					desagruparLotes();
					mensaje = "Los lotes han sido registrados";
				}
				chequeService.asignar(cheques, usuario, par, rutaAdjuntos);
				
				actualizarFechafirmantes();
				buscarCheques();
				SateliteUtil.mostrarMensaje(mensaje);
			}else{
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN,mensajeError);
			}
		} catch (Exception ex) {
			SateliteUtil.mostrarMensaje(ex.getMessage());
			cheques.clear();
			buscarCheques();
		}
		return null;
	}
	public void desagruparLotes(){
		List<Cheque> nuevoGrupo=new ArrayList<Cheque>();
		for(Cheque itemCheque:cheques){
			if(itemCheque.getSeleccionado()!=null && itemCheque.getSeleccionado()==true){
				for(Cheque itemChequeSiniestro:listaSiniestros){
					if(itemCheque.getNumero().trim().equals(itemChequeSiniestro.getNumero().trim()) &&
							itemCheque.getDiario().intValue()==itemChequeSiniestro.getDiario().intValue()){
						itemChequeSiniestro.setSeleccionado(true);
						nuevoGrupo.add(itemChequeSiniestro);
					}
				}
			}
		}
		cheques.clear();
		cheques.addAll(nuevoGrupo);
	}
	public boolean validarFormulario(){
		boolean band=true;
		if(banco==null || banco.trim().length()==0){
			mensajeError ="Seleccione un banco";
			return false;
		}
		if (par == null || par==0){
			mensajeError ="Seleccione firmante";
			return false;
		}
		if(cheques==null ||cheques.size()==0){
			mensajeError ="No hay cheques/lotes a asignar";
			return false;
		}else{
			int cantidad=0;
			for(Cheque chequeItem:cheques){
				if(chequeItem.getSeleccionado()!=null && chequeItem.getSeleccionado()==true){
					cantidad= 1;
				}
				if(cantidad==1){
					break;
				}
			}
			if(cantidad==0){
				mensajeError ="No ha seleccionado cheques/lotes a asignar";
				return false;
			}
		}
		
		return band;
	}

	public void actualizarFechafirmantes() throws Exception {
		String usuarioModifica = SecurityContextHolder.getContext().getAuthentication().getName();
		List<Cheque> listaSeleccionados = chequeService.filtrarSeleccionado(cheques);
		List<String> chequeSiniestros = new ArrayList<String>();
		if (listaSeleccionados != null && listaSeleccionados.size() > 0) {
			for (Cheque siniestro : listaSeleccionados) {
				if (isSiniestro(siniestro.getNumero().trim())) {
					chequeSiniestros.add(siniestro.getNumero().trim());
				}
			}
			if (chequeSiniestros.size() > 0) {
				try {
					siniBeneficiariosService.updateListaBeneficiarioFechaAsigna(chequeSiniestros, usuarioModifica);
					siniManualService.updateListaManualBeneficiarioFechaAsigna(chequeSiniestros, usuarioModifica);
				} catch (SyncconException e) {
					throw new Exception(e.getMessage());
				}
			}
		}
	}

	public void listener(UploadEvent event) throws Exception {
		UploadItem item = event.getUploadItem();
		String nombreArchivo = "";
		File archivoCargado = null;
		File archivo = item.getFile();
		log.debug(archivo.getAbsolutePath());
		nombreArchivo = item.getFileName().substring(item.getFileName().lastIndexOf("\\") + 1);
		archivoCargado = File.createTempFile("ASI", "_" + nombreArchivo);
		FileUtils.copyFile(archivo, archivoCargado);
		archivosAdjuntos.add(archivoCargado);

	}

	public String verDetalles() {
		log.debug("Ingresa para ver detalle");
		if (chequeSeleccionado != null) {
			log.info("" + chequeSeleccionado.getNumero());
			try {

				listaTramaGeneraDetalle = tramaGeneraDetService.listaTramas(chequeSeleccionado.getNumero().trim());

			} catch (SyncconException ex) {
				log.error("ERROR SYNCCON: " + ex.getMessageComplete());
				FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
				FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			}

		}
		return null;
	}

	public void onSelectOneBooleanChange(ValueChangeEvent event) {
		log.info("Inicio");
		int cuentaSeleccionados = 0;
		cantidadArchivos = 0;
		Iterator<Object> iterator = getSelection().getKeys();
		existeCarga = false;
		if (archivosAdjuntos != null) {
			archivosAdjuntos.clear();
		}
		try {
			if (iterator.hasNext()) {
				int indice_modificar = (Integer) iterator.next();
				check(indice_modificar, event);
			}
			log.debug(event.getOldValue() + " --- " + event.getNewValue());
			for (Cheque chequeItem : cheques) {
				if (chequeItem.getSeleccionado() != null && chequeItem.getSeleccionado().booleanValue()) {
					if (isSiniestro(chequeItem.getNumero().trim())) {
						existeCarga = true;
						cantidadArchivos = cantidadArchivos + 1;
					}
					cuentaSeleccionados = cuentaSeleccionados + 1;
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}

		log.debug("seleccionado: " + cuentaSeleccionados);
		log.debug("cantidadArchivos: " + cantidadArchivos);

	}

	private void validarArchivo() throws Exception {
		if (existeCarga) {
			if (archivosAdjuntos == null || archivosAdjuntos.size() == 0) {
				throw new Exception("Debe ingresar archivos Para el Pago Masivo Electrónico del BBVA ");
			}
			if (Utilitarios.excedeTamanioArchivos(archivosAdjuntos, tamanioMaximoArchivos)) {
				throw new Exception("La suma de los archivos adjuntos es mayor al parámetro. Por favor, desmarque algunos lotes y realice una nueva asignación de firmantes ");
			}
			List<Cheque> siniestros = chequesSiniestros();
			int siContiene = 0;
			for (Cheque chequeItem : siniestros) {
				for (File itemFile : archivosAdjuntos) {
					if (itemFile.getName().contains(chequeItem.getNumero().trim())) {
						siContiene = siContiene + 1;
						break;
					}
				}
			}
			if (siContiene != siniestros.size()) {
				throw new Exception("No ha subido los archivos de siniestros con nombre de lote para los siniestros seleccionados");
			}
		}
	}

	private List<Cheque> chequesSiniestros() {
		List<Cheque> siniestros = new ArrayList<Cheque>();
		for (Cheque chequeItem : cheques) {
			if (isSiniestro(chequeItem.getNumero().trim()) && chequeItem.getSeleccionado().booleanValue()) {
				siniestros.add(chequeItem);
			}
		}
		return siniestros;
	}

	private synchronized void check(int cod, ValueChangeEvent event) throws Exception {
		boolean nuevo = ((Boolean) event.getNewValue()).booleanValue();
		boolean antiguo = false;
		Boolean actual = (Boolean) event.getOldValue();
		if (actual != null) {
			antiguo = actual.booleanValue();
		}
		if (nuevo != antiguo) {
			log.error(event.getOldValue() + " --- " + event.getNewValue());
			Cheque bean;
			bean = cheques.get(cod);
			boolean flag = ((Boolean) event.getNewValue()).booleanValue();
			if (flag == true) {
				bean.setSeleccionado(true);
			} else {
				bean.setSeleccionado(false);
			}
			cheques.set(cod, bean);
		}

	}

	public void limpiarUpload(ActionEvent event) {
		log.debug("entra aqui");
	}

	public void cancelarArchivoCargado(ActionEvent event) {
		log.debug("cancelo archivo");
	}

	// Getters & Setters
	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public List<SelectItem> getBancos() {
		return bancos;
	}

	public void setBancos(List<SelectItem> bancos) {
		this.bancos = bancos;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getNumeroCheque() {
		return numeroCheque;
	}

	public void setNumeroCheque(String numeroCheque) {
		this.numeroCheque = numeroCheque;
	}

	public List<Cheque> getCheques() {
		return cheques;
	}

	public void setCheques(List<Cheque> cheques) {
		this.cheques = cheques;
	}

	public Long getPar() {
		return par;
	}

	public void setPar(Long par) {
		this.par = par;
	}

	public List<SelectItem> getPares() {
		return pares;
	}

	public void setPares(List<SelectItem> pares) {
		this.pares = pares;
	}

	public Boolean getMostrar() {
		return mostrar;
	}

	public void setMostrar(Boolean mostrar) {
		this.mostrar = mostrar;
	}

	public String getIdTipoPago() {
		return idTipoPago;
	}

	public void setIdTipoPago(String idTipoPago) {
		this.idTipoPago = idTipoPago;
	}

	public List<SelectItem> getTipoPagoItems() {
		return tipoPagoItems;
	}

	public void setTipoPagoItems(List<SelectItem> tipoPagoItems) {
		this.tipoPagoItems = tipoPagoItems;
	}

	public String getNroLote() {
		return nroLote;
	}

	public void setNroLote(String nroLote) {
		this.nroLote = nroLote;
	}

	public List<SelectItem> getMedioPagoItems() {
		return medioPagoItems;
	}

	public void setMedioPagoItems(List<SelectItem> medioPagoItems) {
		this.medioPagoItems = medioPagoItems;
	}

	public String getIdMedioPago() {
		return idMedioPago;
	}

	public void setIdMedioPago(String idMedioPago) {
		this.idMedioPago = idMedioPago;
	}

	public Cheque getChequeSeleccionado() {
		return chequeSeleccionado;
	}

	public void setChequeSeleccionado(Cheque chequeSeleccionado) {
		this.chequeSeleccionado = chequeSeleccionado;
	}

	public int getCantidadArchivos() {
		return cantidadArchivos;
	}

	public void setCantidadArchivos(int cantidadArchivos) {
		this.cantidadArchivos = cantidadArchivos;
	}

	public SimpleSelection getSelection() {
		return selection;
	}

	public void setSelection(SimpleSelection selection) {
		this.selection = selection;
	}

	public boolean isExisteCarga() {
		return existeCarga;
	}

	public void setExisteCarga(boolean existeCarga) {
		this.existeCarga = existeCarga;
	}

}
