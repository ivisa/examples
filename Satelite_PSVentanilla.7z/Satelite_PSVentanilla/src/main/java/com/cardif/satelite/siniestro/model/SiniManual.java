package com.cardif.satelite.siniestro.model;

import java.io.Serializable;
import java.util.Date;

public class SiniManual implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String siniestroId;
	private String beneTipoDocumento;
	private String beneNumeroDocumento;
	private String beneSocio;
	private String beneProducto;
	private String beneNumeroPoliza;
	private Date beneFechaOcurrencia;
	private String beneNumeroPlanilla;
	private double beneMontoPagar;
	private String beneMoneda;
	private Date beneFechaAproRechCarta;
	private String beneMesAproRechCarta;
	private String beneApellidoPaterno;
	private String beneApellidoMaterno;
	private String beneNombre;
	private String benePais;
	private String beneEmail;
	private String beneNumeroCuentaBan;
	private String beneTelefono1;
	private String beneTelefono2;
	private String beneDireccion;
	private String beneParentesco;
	private double benePorcentajeParticipacion;
	private Date beneFechaEntregaOpConta;
	private String beneEstado;
	private Date beneFechaPendiente;
	private Date beneFechaEnvioOpConta;
	private Date beneFechaProvisionado;
	private Date beneFechaRegistroPago;
	private Date beneFechaAsignaFirmantes;
	private Date beneFechaProcesado;
	private Date beneFechaCobro;
	private String beneLoteId;
	private String beneUsuarioRegistra;
	private Date benefechaRegistro;
	private String beneUsuarioModifica;
	private Date benefechaModifica;
	private Date beneFechaNotificacion;
	private Date beneFechaUltimaDocument;
	private String beneNombreCompleto;
	private Date beneFechaContabilizado;
	private Date beneFechaCargaBanco;
	
	
	private String ramo;
	private String descripcionEstado;
	private String decripcionMoneda;
	private String descripcionTipoDocumento;
	public String getSiniestroId() {
		return siniestroId;
	}
	public void setSiniestroId(String siniestroId) {
		this.siniestroId = siniestroId;
	}
	public String getBeneTipoDocumento() {
		return beneTipoDocumento;
	}
	public void setBeneTipoDocumento(String beneTipoDocumento) {
		this.beneTipoDocumento = beneTipoDocumento;
	}
	public String getBeneNumeroDocumento() {
		return beneNumeroDocumento;
	}
	public void setBeneNumeroDocumento(String beneNumeroDocumento) {
		this.beneNumeroDocumento = beneNumeroDocumento;
	}
	
	public String getBeneParentesco() {
		return beneParentesco;
	}
	public void setBeneParentesco(String beneParentesco) {
		this.beneParentesco = beneParentesco;
	}
	public double getBenePorcentajeParticipacion() {
		return benePorcentajeParticipacion;
	}
	public void setBenePorcentajeParticipacion(double benePorcentajeParticipacion) {
		this.benePorcentajeParticipacion = benePorcentajeParticipacion;
	}
	public String getBeneMoneda() {
		return beneMoneda;
	}
	public void setBeneMoneda(String beneMoneda) {
		this.beneMoneda = beneMoneda;
	}
	public double getBeneMontoPagar() {
		return beneMontoPagar;
	}
	public void setBeneMontoPagar(double beneMontoPagar) {
		this.beneMontoPagar = beneMontoPagar;
	}
	
	public String getBeneSocio() {
		return beneSocio;
	}
	public void setBeneSocio(String beneSocio) {
		this.beneSocio = beneSocio;
	}
	public String getBeneProducto() {
		return beneProducto;
	}
	public void setBeneProducto(String beneProducto) {
		this.beneProducto = beneProducto;
	}
	public String getBeneNumeroPoliza() {
		return beneNumeroPoliza;
	}
	public void setBeneNumeroPoliza(String beneNumeroPoliza) {
		this.beneNumeroPoliza = beneNumeroPoliza;
	}
	public Date getBeneFechaOcurrencia() {
		return beneFechaOcurrencia;
	}
	public void setBeneFechaOcurrencia(Date beneFechaOcurrencia) {
		this.beneFechaOcurrencia = beneFechaOcurrencia;
	}
	public String getBeneNumeroPlanilla() {
		return beneNumeroPlanilla;
	}
	public void setBeneNumeroPlanilla(String beneNumeroPlanilla) {
		this.beneNumeroPlanilla = beneNumeroPlanilla;
	}
	public Date getBeneFechaAproRechCarta() {
		return beneFechaAproRechCarta;
	}
	public void setBeneFechaAproRechCarta(Date beneFechaAproRechCarta) {
		this.beneFechaAproRechCarta = beneFechaAproRechCarta;
	}
	public String getBeneMesAproRechCarta() {
		return beneMesAproRechCarta;
	}
	public void setBeneMesAproRechCarta(String beneMesAproRechCarta) {
		this.beneMesAproRechCarta = beneMesAproRechCarta;
	}
	public Date getBeneFechaEntregaOpConta() {
		return beneFechaEntregaOpConta;
	}
	public void setBeneFechaEntregaOpConta(Date beneFechaEntregaOpConta) {
		this.beneFechaEntregaOpConta = beneFechaEntregaOpConta;
	}
	
	public Date getBeneFechaCobro() {
		return beneFechaCobro;
	}
	public void setBeneFechaCobro(Date beneFechaCobro) {
		this.beneFechaCobro = beneFechaCobro;
	}
	
	public String getBeneEmail() {
		return beneEmail;
	}
	public void setBeneEmail(String beneEmail) {
		this.beneEmail = beneEmail;
	}
	public String getBeneNumeroCuentaBan() {
		return beneNumeroCuentaBan;
	}
	public void setBeneNumeroCuentaBan(String beneNumeroCuentaBan) {
		this.beneNumeroCuentaBan = beneNumeroCuentaBan;
	}
	public String getBeneEstado() {
		return beneEstado;
	}
	public void setBeneEstado(String beneEstado) {
		this.beneEstado = beneEstado;
	}
	
	public Date getBeneFechaRegistroPago() {
		return beneFechaRegistroPago;
	}
	public void setBeneFechaRegistroPago(Date beneFechaRegistroPago) {
		this.beneFechaRegistroPago = beneFechaRegistroPago;
	}
	public Date getBeneFechaAsignaFirmantes() {
		return beneFechaAsignaFirmantes;
	}
	public void setBeneFechaAsignaFirmantes(Date beneFechaAsignaFirmantes) {
		this.beneFechaAsignaFirmantes = beneFechaAsignaFirmantes;
	}
	public String getBeneApellidoPaterno() {
		return beneApellidoPaterno;
	}
	public void setBeneApellidoPaterno(String beneApellidoPaterno) {
		this.beneApellidoPaterno = beneApellidoPaterno;
	}
	public String getBeneApellidoMaterno() {
		return beneApellidoMaterno;
	}
	public void setBeneApellidoMaterno(String beneApellidoMaterno) {
		this.beneApellidoMaterno = beneApellidoMaterno;
	}
	public String getBeneNombre() {
		return beneNombre;
	}
	public void setBeneNombre(String beneNombre) {
		this.beneNombre = beneNombre;
	}
	public String getRamo() {
		return ramo;
	}
	public void setRamo(String ramo) {
		this.ramo = ramo;
	}
	public String getBenePais() {
		return benePais;
	}
	public void setBenePais(String benePais) {
		this.benePais = benePais;
	}
	public String getBeneTelefono1() {
		return beneTelefono1;
	}
	public void setBeneTelefono1(String beneTelefono1) {
		this.beneTelefono1 = beneTelefono1;
	}
	public String getBeneTelefono2() {
		return beneTelefono2;
	}
	public void setBeneTelefono2(String beneTelefono2) {
		this.beneTelefono2 = beneTelefono2;
	}
	public String getBeneDireccion() {
		return beneDireccion;
	}
	public void setBeneDireccion(String beneDireccion) {
		this.beneDireccion = beneDireccion;
	}
	
	public Date getBeneFechaPendiente() {
		return beneFechaPendiente;
	}
	public void setBeneFechaPendiente(Date beneFechaPendiente) {
		this.beneFechaPendiente = beneFechaPendiente;
	}
	public Date getBeneFechaEnvioOpConta() {
		return beneFechaEnvioOpConta;
	}
	public void setBeneFechaEnvioOpConta(Date beneFechaEnvioOpConta) {
		this.beneFechaEnvioOpConta = beneFechaEnvioOpConta;
	}
	public Date getBeneFechaProvisionado() {
		return beneFechaProvisionado;
	}
	public void setBeneFechaProvisionado(Date beneFechaProvisionado) {
		this.beneFechaProvisionado = beneFechaProvisionado;
	}
	public Date getBeneFechaProcesado() {
		return beneFechaProcesado;
	}
	public void setBeneFechaProcesado(Date beneFechaProcesado) {
		this.beneFechaProcesado = beneFechaProcesado;
	}
	public String getBeneLoteId() {
		return beneLoteId;
	}
	public void setBeneLoteId(String beneLoteId) {
		this.beneLoteId = beneLoteId;
	}
	public String getBeneUsuarioRegistra() {
		return beneUsuarioRegistra;
	}
	public void setBeneUsuarioRegistra(String beneUsuarioRegistra) {
		this.beneUsuarioRegistra = beneUsuarioRegistra;
	}
	public Date getBenefechaRegistro() {
		return benefechaRegistro;
	}
	public void setBenefechaRegistro(Date benefechaRegistro) {
		this.benefechaRegistro = benefechaRegistro;
	}
	public String getBeneUsuarioModifica() {
		return beneUsuarioModifica;
	}
	public void setBeneUsuarioModifica(String beneUsuarioModifica) {
		this.beneUsuarioModifica = beneUsuarioModifica;
	}
	public Date getBenefechaModifica() {
		return benefechaModifica;
	}
	public void setBenefechaModifica(Date benefechaModifica) {
		this.benefechaModifica = benefechaModifica;
	}
	public Date getBeneFechaNotificacion() {
		return beneFechaNotificacion;
	}
	public void setBeneFechaNotificacion(Date beneFechaNotificacion) {
		this.beneFechaNotificacion = beneFechaNotificacion;
	}
	public Date getBeneFechaUltimaDocument() {
		return beneFechaUltimaDocument;
	}
	public void setBeneFechaUltimaDocument(Date beneFechaUltimaDocument) {
		this.beneFechaUltimaDocument = beneFechaUltimaDocument;
	}
	public String getBeneNombreCompleto() {
		return beneNombreCompleto;
	}
	public void setBeneNombreCompleto(String beneNombreCompleto) {
		this.beneNombreCompleto = beneNombreCompleto;
	}
	public Date getBeneFechaContabilizado() {
		return beneFechaContabilizado;
	}
	public void setBeneFechaContabilizado(Date beneFechaContabilizado) {
		this.beneFechaContabilizado = beneFechaContabilizado;
	}
	public Date getBeneFechaCargaBanco() {
		return beneFechaCargaBanco;
	}
	public void setBeneFechaCargaBanco(Date beneFechaCargaBanco) {
		this.beneFechaCargaBanco = beneFechaCargaBanco;
	}
	public String getDescripcionEstado() {
		return descripcionEstado;
	}
	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}
	public String getDecripcionMoneda() {
		return decripcionMoneda;
	}
	public void setDecripcionMoneda(String decripcionMoneda) {
		this.decripcionMoneda = decripcionMoneda;
	}
	public String getDescripcionTipoDocumento() {
		return descripcionTipoDocumento;
	}
	public void setDescripcionTipoDocumento(String descripcionTipoDocumento) {
		this.descripcionTipoDocumento = descripcionTipoDocumento;
	}
	
	
}
