package com.cardif.satelite.siniestro.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;
import com.cardif.satelite.siniestro.service.CamposTramaPagoSiniVentanillaService;
import com.cardif.satelite.siniestro.service.SiniBeneficiariosService;
import com.cardif.satelite.siniestro.service.SiniTramaPagoVentanillaService;
import com.cardif.satelite.siniestro.ventanilla.tramas.bbva.BBVAPagoProveedor;
import com.cardif.satelite.siniestro.ventanilla.tramas.bbva.LogErroresArchivosBean;
import com.cardif.satelite.util.SateliteUtil;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.apache.log4j.Logger;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.exception.ExceptionUtils;


	/**
	 * Controlador para cargar las tramas de confirmación y cobro. 
	 *
	 *
	 * @author  Gilder Ali Fonseca S.
	 * @version 0.9, 15/05/2017
	 *
	 */

@Scope("request")
@Controller("cargTramaPagoSiniVentanillaController")
public class CargTramaPagoSiniVentanillaController extends BaseController{
	
	private static final Logger logger = Logger.getLogger(CargTramaPagoSiniVentanillaController.class);

	
	/**
	 * 	======================= VARIABLES PARA LAS TRAMAS DE CONFIRMACION =======================================
	 * 
	 **/
	private List<TramaConfPagoSiniVentanilla> listaArchivoConf; /* Archivos de confirmacion o tambien llamados procesados */
	private String nombreArchivoConf;
	private File archivoFinalConf;
	private boolean archivoConfNombreEsRepetido;
	List<String> listaBufferErroresArchivoConf = null;
	private boolean deshabilitarUploadArchivosConf;
	
	/**
	 * 	======================= VARIABLES PARA LAS TRAMAS DE COBROS =======================================
	 * 
	 **/
	private List<TramaConfPagoSiniVentanilla> listaArchivoCobros;
	private String nombreArchivoCobros;
	private File archivoFinalCobros;
	private boolean archivoCobrosNombreEsRepetido;
	List<String> listaBufferErroresArchivoCobros = null;
	private boolean deshabilitarUploadArchivosCobros;
	
	/**
	 * 	======================= VARIABLES COMUNES =======================================
	 * 
	 **/
	private String usuarioActual = null;
	private Boolean deshabilitarBotones;
	private Boolean mostrarDetalleLogErrores;
	private List<LogErroresArchivosBean> listaDetalleResultadoProceso;
	
	
	/**
	 * 	======================= VARIABLES CAPA SERVICE ==================================
	 * 
	 **/
	
	@Autowired
	SiniTramaPagoVentanillaService siniTramaPagoVentanillaService;
	
	@Autowired
	CamposTramaPagoSiniVentanillaService camposTramaPagoSiniVentanillaService;
	
	@Autowired
	SiniBeneficiariosService siniBeneficiariosService;
	

	
	@PostConstruct
	@Override
	public String inicio()
	{
		if (logger.isInfoEnabled()) {logger.info("Inicio");}
		String respuesta = null;
		
		if (!tieneAcceso())
		{
			if (logger.isDebugEnabled()) {logger.debug("No cuenta con los accesos necesarios.");}
			return "accesoDenegado";
		}
		
		//Obteniendo usuario logueado
		usuarioActual = SecurityContextHolder.getContext().getAuthentication().getName().toUpperCase();
		
		//Inicializacion de variables
		listaArchivoConf = null;
		listaArchivoCobros = null;
		
		//Deshabilitar botones
		deshabilitarBotones = true;
		
		//Ocultar detalle de errores
		mostrarDetalleLogErrores = false;
		
		//Habilitar uploads
		deshabilitarUploadArchivosConf = false;
		deshabilitarUploadArchivosCobros = false;
		
		if (logger.isInfoEnabled()) {logger.info("Fin");}
		return respuesta;
	} 
	

	/**
	 * 	======================= METODOS PARA LAS TRAMAS DE CONFIRMACION =======================================
	 * 
	 **/
	
	public String fileUpLoadlistenerTramaConf(UploadEvent event) {

		log.debug("Inicio");
		String respuesta = null;
		try {

			nombreArchivoConf = new String();
			UploadItem item = event.getUploadItem();
			File archivo = item.getFile();
			nombreArchivoConf = item.getFileName().substring(item.getFileName().lastIndexOf("\\") + 1);
			
			archivoConfNombreEsRepetido = false;
			//Validacion si existe un archivo con el mismo nombre en la grilla
			if(existeNombreListaArchivos(listaArchivoConf, nombreArchivoConf)){
				archivoConfNombreEsRepetido = true;
				return respuesta;
			}
			
			archivoFinalConf = File.createTempFile("Temporal_", nombreArchivoConf);
			log.info("Archivo final: " + archivoFinalConf);
			
			FileUtils.copyFile(archivo, archivoFinalConf);
			archivo.delete();
			
			//Cargar registro a la lista de tramas de confirmación
			if(listaArchivoConf == null){
				listaArchivoConf = new ArrayList<TramaConfPagoSiniVentanilla>();
			}
			
			TramaConfPagoSiniVentanilla nuevoArchivoConf = new TramaConfPagoSiniVentanilla();
			 
			nuevoArchivoConf.setNombreTrama("20176661"); //TODO Validar nombre del archivo consideranco los 8 digitos del BBVA
			nuevoArchivoConf.setTipoTrama(Constantes.SINI_TIPO_TRAMA_CONFIRMACION); 
			nuevoArchivoConf.setNombreArchivo(nombreArchivoConf);
			nuevoArchivoConf.setFechaCarga(Calendar.getInstance().getTime()); 
			nuevoArchivoConf.setArchivoTrama(convertirFileToArrayByte(archivoFinalConf.getAbsolutePath()));
			nuevoArchivoConf.setUsuarioCrea(usuarioActual); 
			nuevoArchivoConf.setFechaCrea(Calendar.getInstance().getTime()); 
			//Campos transitorios para visualizacion en grilla
			nuevoArchivoConf.setRutaArchivo(archivoFinalConf.getAbsolutePath());
			nuevoArchivoConf.setArchivoTramaFile(archivoFinalConf);			
			
			listaArchivoConf.add(nuevoArchivoConf);
			
			//Habilitar botones
			deshabilitarBotones = false;
			
			//Actualizar secuencial de la lista
			listaArchivoConf = actualizarSecuencialLista(listaArchivoConf);
			
			//Limpiar variables
			archivoFinalConf = null;
			nombreArchivoConf = null;
			
		} catch (Exception e) {
			log.error("Exception (" + e.getClass().getName() + ") - ERROR" + e.getMessage());
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		log.debug("Fin");
		return respuesta;
	}
	
	
	public void validarArchivoConfRepetido(){
		if(archivoConfNombreEsRepetido){
			SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"El archivo seleccionado ( " + nombreArchivoConf + " ) ya existe en la lista de archivos de confirmación.");
		}
	}
	

	public String eliminarArchivoConf(){
		log.debug("Inicio");
		
		String respuesta = null;
		
		try {
			
			FacesContext fc = FacesContext.getCurrentInstance();
			Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
			
			String secArchivoConfSelec = params.get("secuencialArchivoConf");
			
			if( secArchivoConfSelec != null && (listaArchivoConf != null && listaArchivoConf.size() > 0) ){
				int intSecArchivoConfSelec = Integer.parseInt(secArchivoConfSelec);
				int indiceListaEliminar = intSecArchivoConfSelec - 1;
				listaArchivoConf.remove(indiceListaEliminar);
				
				if(listaArchivoConf.size() > 0){
					//Actualizar secuencial de la lista
					listaArchivoConf = actualizarSecuencialLista(listaArchivoConf);
				}else{
					//Limpiar variable
					listaArchivoConf = null;
				}
			}
			
			//verificar si las dos listas estan vacias para inicializar pantalla.
			if(verificarSiAmbasListasVacias()){
				limpiarPantalla();
			}
			
		} catch (Exception e) {
			log.error("Exception (" + e.getClass().getName() + ") - ERROR" + e.getMessage());
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		
		log.debug("Fin");
		return respuesta;
		
	}
	
	/**
	 * 	======================= METODOS PARA LAS TRAMAS DE COBROS =======================================
	 * 
	 **/
	
	public String fileUpLoadlistenerTramaCobros(UploadEvent event) {

		log.debug("Inicio");
		String respuesta = null;
		try {

			nombreArchivoCobros = new String();
			UploadItem item = event.getUploadItem();
			File archivo = item.getFile();
			nombreArchivoCobros = item.getFileName().substring(item.getFileName().lastIndexOf("\\") + 1);
			
			archivoCobrosNombreEsRepetido = false;
			//Validacion si existe un archivo con el mismo nombre en la grilla
			if(existeNombreListaArchivos(listaArchivoCobros, nombreArchivoCobros)){
				archivoCobrosNombreEsRepetido = true;
				return respuesta;
			}
			
			archivoFinalCobros = File.createTempFile("Temporal_", nombreArchivoCobros);
			log.info("Archivo final: " + archivoFinalCobros);
			
			FileUtils.copyFile(archivo, archivoFinalCobros);
			archivo.delete();
			
			//Cargar registro a la lista de tramas de confirmación
			if(listaArchivoCobros == null){
				listaArchivoCobros = new ArrayList<TramaConfPagoSiniVentanilla>();
			}
			
			TramaConfPagoSiniVentanilla nuevoArchivoCobros = new TramaConfPagoSiniVentanilla();
			
			nuevoArchivoCobros.setNombreTrama("20176662"); //TODO Validar nombre del archivo consideranco los 8 digitos del BBVA
			nuevoArchivoCobros.setTipoTrama(Constantes.SINI_TIPO_TRAMA_COBRO); 
			nuevoArchivoCobros.setNombreArchivo(nombreArchivoCobros);
			nuevoArchivoCobros.setFechaCarga(Calendar.getInstance().getTime()); 
			nuevoArchivoCobros.setArchivoTrama(convertirFileToArrayByte(archivoFinalCobros.getAbsolutePath()));
			nuevoArchivoCobros.setUsuarioCrea(usuarioActual); 
			nuevoArchivoCobros.setFechaCrea(Calendar.getInstance().getTime());
			//Campos transitorios para visualizacion en grilla
			nuevoArchivoCobros.setRutaArchivo(archivoFinalCobros.getAbsolutePath());
			nuevoArchivoCobros.setArchivoTramaFile(archivoFinalCobros);
			
			listaArchivoCobros.add(nuevoArchivoCobros);
			
			//Habilitar botones
			deshabilitarBotones = false;
			
			//Actualizar secuencial de la lista
			listaArchivoCobros = actualizarSecuencialLista(listaArchivoCobros);
			
			//Limpiar variables
			archivoFinalCobros = null;
			nombreArchivoCobros = null;
			
		} catch (Exception e) {
			log.error("Exception (" + e.getClass().getName() + ") - ERROR" + e.getMessage());
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		log.debug("Fin");
		return respuesta;
	}
	
	public void validarArchivoCobrosRepetido(){
		if(archivoCobrosNombreEsRepetido){
			SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"El archivo seleccionado ( " + nombreArchivoCobros + " ) ya existe en la lista de archivos de cobros.");
		}
	}
	

	public String eliminarArchivoCobros(){
		log.debug("Inicio");
		
		String respuesta = null;
		
		try {
			
			FacesContext fc = FacesContext.getCurrentInstance();
			Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
			
			String secArchivoCobrosSelec = params.get("secuencialArchivoCobros");
			
			if( secArchivoCobrosSelec != null && (listaArchivoCobros != null && listaArchivoCobros.size() > 0) ){
				int intSecArchivoCobrosSelec = Integer.parseInt(secArchivoCobrosSelec);
				int indiceListaEliminar = intSecArchivoCobrosSelec - 1;
				listaArchivoCobros.remove(indiceListaEliminar);
				
				if(listaArchivoCobros.size() > 0){
					//Actualizar secuencial de la lista
					listaArchivoCobros = actualizarSecuencialLista(listaArchivoCobros);
				}else{
					//Limpiar variable
					listaArchivoCobros = null;
				}
			}
			
			//verificar si las dos listas estan vacias para inicializar pantalla.
			if(verificarSiAmbasListasVacias()){
				btnCancelar_inicializarPantalla();
			}
			
		} catch (Exception e) {
			log.error("Exception (" + e.getClass().getName() + ") - ERROR" + e.getMessage());
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		
		log.debug("Fin");
		return respuesta;
		
	}
		
	
	/**
	 * 	======================= METODOS DE USO COMUN =======================================
	 * 
	 **/
	
	@SuppressWarnings("unchecked")
	public String procesarTramas(){
		log.debug("Inicio");
		String respuesta = null;
		
		List<TramaConfPagoSiniVentanilla> listaArchivoValidadosConf = new ArrayList<TramaConfPagoSiniVentanilla>();
		List<TramaConfPagoSiniVentanilla> listaArchivoValidadosCobros = new ArrayList<TramaConfPagoSiniVentanilla>();
		
		try{
			
			listaDetalleResultadoProceso = new ArrayList<LogErroresArchivosBean>();
			
			/* Pruebas */
//			siniBeneficiariosService.updateBeneTramaConfirmados("43618748", "20170011");
//			String montoEntero = "13333";
//			String montoDecimal = "33";
//			String montoCompleto = montoEntero + "." + montoDecimal;
//			BigDecimal monto = new BigDecimal(montoCompleto);
//			siniBeneficiariosService.updateBeneTramaCobros("69878418", monto);
			
			//Proceso de carga de los archivos de confirmacion (procesados).
			if(!verificaListaArchivoVacia(listaArchivoConf)){
				
				//Proceso de validacion de Archivos de confirmacion (procesados).
				Map<String, Object> respuestaMap = camposTramaPagoSiniVentanillaService.procesoValidacionArchivosConf(listaArchivoConf);
				
				listaArchivoValidadosConf = (List<TramaConfPagoSiniVentanilla>) 
														  respuestaMap.get(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_ARCHIVOS_VALIDOS.name());
				
				listaBufferErroresArchivoConf = (List<String>) respuestaMap.get(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_BUFFER_ERRORES.name());
				
				
				//Grabar Archivos de confirmacion (procesados).
				if(!verificaListaArchivoVacia(listaArchivoValidadosConf)){
					siniTramaPagoVentanillaService.insertarListaTrama(listaArchivoValidadosConf);
					//Actualizacion del estado y fecha
					siniBeneficiariosService.actualizarBeneficiariosTramaConfirmados(listaArchivoValidadosConf);					
				}
				
				//Se añade a la lista de resultados
				LogErroresArchivosBean objLogErroresArchivosConf = new LogErroresArchivosBean();
				objLogErroresArchivosConf.setTipoArchivo( BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_CONFIRMACION.name() );
				objLogErroresArchivosConf.setTipoArchivoDesc( BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_CONFIRMACION.getValue() );
				objLogErroresArchivosConf.setCantCorrectos( listaArchivoValidadosConf.size() );
				objLogErroresArchivosConf.setCantIncorrectos( listaBufferErroresArchivoConf.size() );
				objLogErroresArchivosConf.setCantTotal( (listaArchivoValidadosConf.size() + listaBufferErroresArchivoConf.size()) );
				objLogErroresArchivosConf.setLinkArchivoTxtErrores( listaBufferErroresArchivoConf.size() > 0 ? LogErroresArchivosBean.NOMBRE_ARCHIVO_LOG_ERRORES_TXT.CONFIRMACION.getValue() : "" );
				listaDetalleResultadoProceso.add(objLogErroresArchivosConf);
				
				//mostrar mensaje de exito del proceso
				if(objLogErroresArchivosConf.getCantCorrectos() == 0){
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Ningun archivo de Confirmación se procesó correctamente.");
				}else if(objLogErroresArchivosConf.getCantCorrectos() > 0){
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"El Sub estado de los beneficiarios fué actualizado a 'Procesados por el Banco' junto con la fecha de procesado.");
				}
				
			}
			
			//Proceso de carga de los archivos de cobros.
			if(!verificaListaArchivoVacia(listaArchivoCobros)){
				
				//Proceso de validacion de Archivos de cobros.
				Map<String, Object> respuestaMap = camposTramaPagoSiniVentanillaService.procesoValidacionArchivosCobros(listaArchivoCobros);
				 
				listaArchivoValidadosCobros = (List<TramaConfPagoSiniVentanilla>) 
															respuestaMap.get(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_ARCHIVOS_VALIDOS.name());
				
				listaBufferErroresArchivoCobros = (List<String>) respuestaMap.get(BBVAPagoProveedor.RPT_PROC_TRAMA_ENUM.LISTA_BUFFER_ERRORES.name());
				
				//Grabar Archivos cobros.
				if(!verificaListaArchivoVacia(listaArchivoValidadosCobros)){
					siniTramaPagoVentanillaService.insertarListaTrama(listaArchivoValidadosCobros);
					//Actualizacion del estado y fecha
					siniBeneficiariosService.actualizarBeneficiariosTramaCobros(listaArchivoValidadosCobros);
				}
				
				//Se añade a la lista de resultados
				LogErroresArchivosBean objLogErroresArchivosPago = new LogErroresArchivosBean();
				objLogErroresArchivosPago.setTipoArchivo( BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_COBROS.name() );
				objLogErroresArchivosPago.setTipoArchivoDesc( BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_COBROS.getValue() );
				objLogErroresArchivosPago.setCantCorrectos( listaArchivoValidadosCobros.size() );
				objLogErroresArchivosPago.setCantIncorrectos( listaBufferErroresArchivoCobros.size() );
				objLogErroresArchivosPago.setCantTotal( (listaArchivoValidadosCobros.size() + listaBufferErroresArchivoCobros.size()) );
				objLogErroresArchivosPago.setLinkArchivoTxtErrores( listaBufferErroresArchivoCobros.size() > 0 ? LogErroresArchivosBean.NOMBRE_ARCHIVO_LOG_ERRORES_TXT.PAGOS.getValue() : "" );
				listaDetalleResultadoProceso.add(objLogErroresArchivosPago);
				
				//mostrar mensaje de exito del proceso
				if(objLogErroresArchivosPago.getCantCorrectos() == 0){
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Ningun archivo de Cobros se procesó correctamente.");
				}else if(objLogErroresArchivosPago.getCantCorrectos() > 0){
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"El Sub estado de los beneficiarios fué actualizado a 'Cobrado' junto con la fecha de cobro.");
				}
				
			}
			
//			//mostrar mensaje de exito del proceso
//			SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO,"Se finalizó el proceso, verificar la sección 'Resultado del Proceso de Carga'.");
			
			//Limpiar pantalla
			//limpiarPantalla();
			
			//Deshabilitar botones
			deshabilitarBotones = true;
			
			//Mostrar grilla con el detalle de errores
			mostrarDetalleLogErrores = true;
			
			//Deshabilitar
			deshabilitarUploadArchivosCobros = true;
			deshabilitarUploadArchivosConf = true;
			
		}
		catch (SyncconException e){
			logger.error("SyncconException() - ERROR: " + ErrorConstants.ERROR_SYNCCON + e.getMessageComplete());
			logger.error("SyncconException() -->" + ExceptionUtils.getStackTrace(e));
			FacesMessage facesMsg = new FacesMessage(e.getSeveridad(), e.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}catch (Exception e){
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
	    	logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
	    	FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
	    	FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	    	respuesta = ErrorConstants.MSJ_ERROR;
		}
		
		log.debug("Fin");
		return respuesta;
	}
	
	
	public String exportarArchivoErrores(){
		
		String respuesta = null;
		ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();
		
		try
		{
			FacesContext facesContext = FacesContext.getCurrentInstance();
			String tipArchivoExportar = facesContext.getExternalContext().getRequestParameterMap().get("tipoArchivoTxtErrorExportar");
			
			String nombreArchivo = "";
			
			//Verificar el nombre del archivo segun el tipo
			if(BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_COBROS.name().equals(tipArchivoExportar)){
				nombreArchivo = LogErroresArchivosBean.NOMBRE_ARCHIVO_LOG_ERRORES_TXT.PAGOS.getValue();
				
			}else if(BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_CONFIRMACION.name().equals(tipArchivoExportar)){
				nombreArchivo = LogErroresArchivosBean.NOMBRE_ARCHIVO_LOG_ERRORES_TXT.CONFIRMACION.getValue();
			}
			
			String rutaTemporal = System.getProperty("java.io.tmpdir") + nombreArchivo;
			
			FileOutputStream fos = new FileOutputStream(rutaTemporal);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			
			//Verificar que tipo de errores se van a descargar en el TXT.
			if(BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_COBROS.name().equals(tipArchivoExportar)){
			
				for(String lineaErrorArchivoCobro : listaBufferErroresArchivoCobros){
					bw.write(lineaErrorArchivoCobro);
					bw.newLine();
				}
			
			}else if(BBVAPagoProveedor.TIPO_ENUM.ARCHIVO_CONFIRMACION.name().equals(tipArchivoExportar)){
				
				for(String lineaErrorArchivoConf : listaBufferErroresArchivoConf){
					bw.write(lineaErrorArchivoConf);
					bw.newLine();
				}
				
			}
			
			bw.close();
			
			File archivoResp = new File(rutaTemporal);
			FileInputStream fis = new FileInputStream(archivoResp);
			
			HttpServletResponse response = (HttpServletResponse) contexto.getResponse();
			byte[] loader = new byte[(int) archivoResp.length()];
			response.addHeader("Content-Disposition", "attachment;filename=" + nombreArchivo);
			response.setContentType("text/plain");
			
			ServletOutputStream sos = response.getOutputStream();
		    
		    while ((fis.read(loader)) > 0)
		    {
		    	sos.write(loader, 0, loader.length);
		    }
		    
		    fis.close();
		    sos.close();
			
		    FacesContext.getCurrentInstance().responseComplete();
				
//		}catch (SyncconException e){
//			logger.error("SyncconException() - ERROR: " + ErrorConstants.ERROR_SYNCCON + e.getMessageComplete());
//			logger.error("SyncconException() -->" + ExceptionUtils.getStackTrace(e));
//			FacesMessage facesMsg = new FacesMessage(e.getSeveridad(), e.getMessage(), null);
//			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}catch (Exception e){
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
	    	logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
	    	FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
	    	FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	    	respuesta = ErrorConstants.MSJ_ERROR;
		}
		
		return respuesta;
	}


	public String btnCancelar_inicializarPantalla(){
		log.debug("Inicio");
		
			String respuesta = null;
			
			//Limpiar pantalla
			limpiarPantalla();
		
		log.debug("Fin");
		return respuesta;
	}
	
	
	/**
	 * 	======================= METODOS COMUN UTILS =======================================
	 * 
	 **/
	
	private void limpiarPantalla(){
		log.debug("Inicio");
		
			listaArchivoConf = null;
			listaArchivoCobros = null;
			
			//Deshabilitar botones
			deshabilitarBotones = true;
			
			//Ocultar detalle de errores
			mostrarDetalleLogErrores = false;
			
		log.debug("Fin");
	}
	
	private List<TramaConfPagoSiniVentanilla> actualizarSecuencialLista(List<TramaConfPagoSiniVentanilla> lista) throws Exception{
		log.debug("Inicio");
		List<TramaConfPagoSiniVentanilla> listaResultado = null;
		if(lista != null && lista.size()>0){
			listaResultado = new ArrayList<TramaConfPagoSiniVentanilla>();
			int sec = 0;
			for(TramaConfPagoSiniVentanilla reg : lista){
				reg.setSecuencial(++sec);
				listaResultado.add(reg);
			}
		}
		lista = null;
		log.debug("Fin");
		return listaResultado;
	}
	
	private boolean existeNombreListaArchivos(List<TramaConfPagoSiniVentanilla> listaArchivos, String nombreNuevoArchivo) throws Exception {
		log.debug("Inicio");
			
			if(listaArchivos != null && listaArchivos.size() > 0){
				for(TramaConfPagoSiniVentanilla archivo : listaArchivos){
					if(archivo.getNombreArchivo().equals(nombreNuevoArchivo)){
						return true;
					}
				}
			}

		log.debug("Fin");
		return false;
	}
	
//	private byte[] convertirFileToArrayByte(String rutaArchivo) throws Exception{
//		
//		byte[] bytesArray = File.readAllBytes(rutaArchivo);
//		
//		return bytesArray;
//	}
	
	private byte[] convertirFileToArrayByte(String filePath) throws Exception {

        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;

        try {

            File file = new File(filePath);
            bytesArray = new byte[(int) file.length()];

            //read file into bytes[]
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);
            
            fileInputStream.close();

        } catch (Exception e) {
            throw e;
        }

        return bytesArray;

    }
	
	private boolean verificarSiAmbasListasVacias() throws Exception{
		
		if(verificaListaArchivoVacia(this.listaArchivoConf) && verificaListaArchivoVacia(this.listaArchivoCobros)){
			return true;
		}
		return false;
	}
	
	private boolean verificaListaArchivoVacia(List<TramaConfPagoSiniVentanilla> lista) throws Exception{
		
		if(lista != null && lista.size() > 0){
			return false; //Lista contiene al menos 1 elemento
		}
		return true; //Lista vacia
	}
	
	private boolean verificaListaStringVacia(List<String> lista) throws Exception{
		
		if(lista != null && lista.size() > 0){
			return false; //Lista contiene al menos 1 elemento
		}
		return true; //Lista vacia
	}


	/**
	 * 	======================= METODOS ACCESORES =======================================
	 * 
	 **/
	
	public String getNombreArchivoConf() {
		return nombreArchivoConf;
	}

	public void setNombreArchivoConf(String nombreArchivoConf) {
		this.nombreArchivoConf = nombreArchivoConf;
	}

	public File getArchivoFinalConf() {
		return archivoFinalConf;
	}

	public void setArchivoFinalConf(File archivoFinalConf) {
		this.archivoFinalConf = archivoFinalConf;
	}

	public String getNombreArchivoCobros() {
		return nombreArchivoCobros;
	}


	public void setNombreArchivoCobros(String nombreArchivoCobros) {
		this.nombreArchivoCobros = nombreArchivoCobros;
	}


	public File getArchivoFinalCobros() {
		return archivoFinalCobros;
	}


	public void setArchivoFinalCobros(File archivoFinalCobros) {
		this.archivoFinalCobros = archivoFinalCobros;
	}


	public List<TramaConfPagoSiniVentanilla> getListaArchivoConf() {
		return listaArchivoConf;
	}


	public void setListaArchivoConf(
			List<TramaConfPagoSiniVentanilla> listaArchivoConf) {
		this.listaArchivoConf = listaArchivoConf;
	}


	public List<TramaConfPagoSiniVentanilla> getListaArchivoCobros() {
		return listaArchivoCobros;
	}


	public void setListaArchivoCobros(
			List<TramaConfPagoSiniVentanilla> listaArchivoCobros) {
		this.listaArchivoCobros = listaArchivoCobros;
	}


	public Boolean getDeshabilitarBotones() {
		return deshabilitarBotones;
	}


	public void setDeshabilitarBotones(Boolean deshabilitarBotones) {
		this.deshabilitarBotones = deshabilitarBotones;
	}


	public Boolean getMostrarDetalleLogErrores() {
		return mostrarDetalleLogErrores;
	}


	public void setMostrarDetalleLogErrores(Boolean mostrarDetalleLogErrores) {
		this.mostrarDetalleLogErrores = mostrarDetalleLogErrores;
	}


	public List<LogErroresArchivosBean> getListaDetalleResultadoProceso() {
		return listaDetalleResultadoProceso;
	}


	public void setListaDetalleResultadoProceso(List<LogErroresArchivosBean> listaDetalleResultadoProceso) {
		this.listaDetalleResultadoProceso = listaDetalleResultadoProceso;
	}


	public boolean isDeshabilitarUploadArchivosConf() {
		return deshabilitarUploadArchivosConf;
	}


	public void setDeshabilitarUploadArchivosConf(boolean deshabilitarUploadArchivosConf) {
		this.deshabilitarUploadArchivosConf = deshabilitarUploadArchivosConf;
	}


	public boolean isDeshabilitarUploadArchivosCobros() {
		return deshabilitarUploadArchivosCobros;
	}


	public void setDeshabilitarUploadArchivosCobros(boolean deshabilitarUploadArchivosCobros) {
		this.deshabilitarUploadArchivosCobros = deshabilitarUploadArchivosCobros;
	}
	
	
}
