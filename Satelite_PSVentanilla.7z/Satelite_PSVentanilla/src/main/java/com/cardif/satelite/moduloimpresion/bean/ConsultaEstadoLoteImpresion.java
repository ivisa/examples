package com.cardif.satelite.moduloimpresion.bean;

public class ConsultaEstadoLoteImpresion implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String estadoLoteImpresion;
	
	
	public String getEstadoLoteImpresion()
	{
		return estadoLoteImpresion;
	}
	
	public void setEstadoLoteImpresion(String estadoLoteImpresion)
	{
		this.estadoLoteImpresion = estadoLoteImpresion;
	}
	
} //ConsultaEstadoLoteImpresion
