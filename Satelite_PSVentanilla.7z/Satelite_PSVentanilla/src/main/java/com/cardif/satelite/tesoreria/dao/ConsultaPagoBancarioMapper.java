package com.cardif.satelite.tesoreria.dao;

import java.util.Date;
import java.util.List;



import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;



import com.cardif.satelite.tesoreria.model.ConsultaPagoBancario;

public interface ConsultaPagoBancarioMapper {
	final String SELECT_PAGO_BANCARIOS=""
			+ "select ROW_NUMBER() OVER(ORDER BY TIPOTRAMA ASC)  as ordenResultado ,"
			+ "codigoTrama,tipoTrama,nombreTipo,fechaCarga,nombreArchivo,numeroLote from("
			+ "SELECT cast(tramaId as varchar) as CODIGOTRAMA,TIPOTRAMA,"
			+ " (SELECT LTRIM(RTRIM(NOM_VALOR)) FROM PARAMETRO WHERE  COD_PARAM ='102' AND COD_VALOR=TIPOTRAMA) AS NOMBRETIPO,"
			+ " FECHACARGA,NOMBREARCHIVO,"
			+ " CASE WHEN TIPOTRAMA = '0' THEN"
			+ " SUBSTRING(NOMBREARCHIVO,1,CHARINDEX('.',NOMBREARCHIVO)-1)"
			+ " ELSE '' END AS NUMEROLOTE"
			+ " FROM CARGA_TRAMA_EXTERNO"
			+ " WHERE "
			+ " TIPOTRAMA = ISNULL(#{tipoTrama,jdbcType=VARCHAR},TipoTrama) AND"
			+ " NOMBREARCHIVO LIKE ISNULL("
			+ "#{numeroLote,jdbcType=VARCHAR}"
			+ ",NOMBREARCHIVO) AND"
			+ " FECHACARGA>=DATEADD(dd, 0, DATEDIFF(dd, 0, ISNULL(#{fechaCargaInicio,jdbcType=DATE},FECHACARGA) ))   AND"
			+ " FECHACARGA<=DATEADD(dd, 1, DATEDIFF(dd, 0, ISNULL(#{fechaCargaFin,jdbcType=DATE},FECHACARGA) )) "
			+ ""
			+ " UNION ALL"
			+ ""
			+ " SELECT loteId AS CODIGOTRAMA ,'2' AS TIPOTRAMA,"
			+ " (SELECT LTRIM(RTRIM(NOM_VALOR)) FROM PARAMETRO WHERE  COD_PARAM ='102' AND COD_VALOR='2') AS NOMBRETIPO,"
			+ " FECGENTRAMA AS FECHACARGA,"
			+ " SUBSTRING(LOTEID,1,8)+ CAST('.txt' as varchar) NOMBREARCHIVO,"
			+ " SUBSTRING(LOTEID,1,8) AS NUMEROLOTE"
			+ " FROM SINI_TRAMA_GENERA"
			+ " WHERE"
			+ " tipoPagoMasivo=ISNULL(#{tipoSiniestro,jdbcType=VARCHAR},tipoPagoMasivo) AND"
			+ " LTRIM(RTRIM(LOTEID)) LIKE ISNULL("
			+ "#{numeroLote,jdbcType=VARCHAR}"
			+ ",LTRIM(RTRIM(LOTEID))) AND"
			+ " (CONVERT(DATE,fecGenTrama) BETWEEN ISNULL(#{fechaCargaInicio,jdbcType=DATE},CONVERT(DATE,fecGenTrama)) AND ISNULL(#{fechaCargaFin,jdbcType=DATE},CONVERT(DATE,fecGenTrama)))"
			+ " )  temp";
	@Select(SELECT_PAGO_BANCARIOS)
	List<ConsultaPagoBancario> buscarPagosBancarios(@Param("tipoTrama") String tipoTrama,@Param("numeroLote") String numeroLote,@Param("fechaCargaInicio") Date fechaCargaInicio,@Param("fechaCargaFin") Date fechaCargaFin,@Param("tipoSiniestro") String tipoSiniestro);
}
