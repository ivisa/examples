package com.cardif.satelite.tesoreria.service;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.tesoreria.model.TramaGenera;

public interface TramaGeneraService {
	
	public List<TramaGenera> listaTramas(String nroLote, String tipoPago,Date fec1,Date fec2)  throws SyncconException;
		
	public void insertTramaGenera(TramaGenera tramaGenera)  throws SyncconException;
	
	public TramaGenera listaTramasById(String nroLote) throws SyncconException;
	
	public void updateTramaGeneraFechaGenera(String nroLote) throws SyncconException;
}
