package com.cardif.satelite.tesoreria.service;

import java.util.List;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.tesoreria.model.FirmanteLoteEnvioAdjunto;

public interface FirmanteLoteEnvioAdjuntoService {
	public void insertFirmanteLoteEnvioAdjuntos(List<FirmanteLoteEnvioAdjunto> adjuntos) throws SyncconException;
}
