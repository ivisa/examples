package com.cardif.satelite.siniestro.service;

import java.util.List;
import java.util.Map;




import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.model.satelite.CamposTramaSiniVentanilla;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;

public interface CamposTramaPagoSiniVentanillaService {
		
	
	public Map<String, Object> procesoValidacionArchivosConf(List<TramaConfPagoSiniVentanilla> listaArchivoConfValidar) throws SyncconException;

	public Map<String, Object> procesoValidacionArchivosCobros(List<TramaConfPagoSiniVentanilla> listaArchivoCobrosValidar) throws SyncconException;
	
	public List<CamposTramaSiniVentanilla> getCamposTramaByBancoIdAndTramaId(String bancoId, String tramaId)throws SyncconException;
	
	
	
	
}
