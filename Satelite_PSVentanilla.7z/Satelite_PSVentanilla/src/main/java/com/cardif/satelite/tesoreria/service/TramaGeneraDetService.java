package com.cardif.satelite.tesoreria.service;


import java.util.List;

import com.cardif.framework.excepcion.SyncconException;

import com.cardif.satelite.tesoreria.model.TramaGeneraDet;

public interface TramaGeneraDetService {
	
	public List<TramaGeneraDet> listaTramas(String nroLote)  throws SyncconException;
		
	public void insertTramaGenera(TramaGeneraDet tramaGenera)  throws SyncconException;
}
