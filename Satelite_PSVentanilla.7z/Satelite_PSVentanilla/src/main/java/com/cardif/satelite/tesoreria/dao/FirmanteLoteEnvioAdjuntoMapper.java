package com.cardif.satelite.tesoreria.dao;

import org.apache.ibatis.annotations.Insert;

import com.cardif.satelite.tesoreria.model.FirmanteLoteEnvioAdjunto;

public interface FirmanteLoteEnvioAdjuntoMapper {
	final String INSERT_ADJUNTO ="INSERT INTO FIRMANTE_LOTE_ENVIO_ADJ("
			+ "loteId,envioId,fecha,adjunto)"
			+ " VALUES("
			+ "#{loteId,jdbcType=NVARCHAR},"
			+ "(SELECT COALESCE(MAX(envioId),0)+1 FROM FIRMANTE_LOTE_ENVIO_ADJ) ,"
			+ "GETDATE(),"
			+ "#{adjunto,jdbcType=VARBINARY })"
			+ "";
	@Insert(INSERT_ADJUNTO)
	public void insertFirmanteLoteEnvioAdjunto(FirmanteLoteEnvioAdjunto adjunto);
}
