package com.cardif.satelite.suscripcion.bean;

public class TarifaModeloBean
{
	private Long id;
	private String nombreModelo;
	
	
	public Long getId()
	{
		return id;
	}
	
	public void setId(Long id)
	{
		this.id = id;
	}
	
	public String getNombreModelo()
	{
		return nombreModelo;
	}
	
	public void setNombreModelo(String nombreModelo)
	{
		this.nombreModelo = nombreModelo;
	}
	
} //TarifaModeloBean
