package com.cardif.satelite.tesoreria.model;

import java.io.Serializable;
import java.util.Date;

public class TramaGeneraDet implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String loteId;
	private String tipoDocBenef;
	private String numDocBenef;
	private String benefNomComp;
	private double benefImporte;
	private String tipCodSunat;
	private String cuentaContable;
	private String referencia;
	private String usuarioCrea;
	private Date fechaCrea;
	private String usuarioModifica;
	private Date fechaModifica;
	private String direccionBenef;
	public String getLoteId() {
		return loteId;
	}
	public void setLoteId(String loteId) {
		this.loteId = loteId;
	}
	public String getTipoDocBenef() {
		return tipoDocBenef;
	}
	public void setTipoDocBenef(String tipoDocBenef) {
		this.tipoDocBenef = tipoDocBenef;
	}
	public String getNumDocBenef() {
		return numDocBenef;
	}
	public void setNumDocBenef(String numDocBenef) {
		this.numDocBenef = numDocBenef;
	}
	public String getBenefNomComp() {
		return benefNomComp;
	}
	public void setBenefNomComp(String benefNomComp) {
		this.benefNomComp = benefNomComp;
	}
	public double getBenefImporte() {
		return benefImporte;
	}
	public void setBenefImporte(double benefImporte) {
		this.benefImporte = benefImporte;
	}
	public String getTipCodSunat() {
		return tipCodSunat;
	}
	public void setTipCodSunat(String tipCodSunat) {
		this.tipCodSunat = tipCodSunat;
	}
	public String getCuentaContable() {
		return cuentaContable;
	}
	public void setCuentaContable(String cuentaContable) {
		this.cuentaContable = cuentaContable;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public String getUsuarioCrea() {
		return usuarioCrea;
	}
	public void setUsuarioCrea(String usuarioCrea) {
		this.usuarioCrea = usuarioCrea;
	}
	public Date getFechaCrea() {
		return fechaCrea;
	}
	public void setFechaCrea(Date fechaCrea) {
		this.fechaCrea = fechaCrea;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public Date getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
	public String getDireccionBenef() {
		return direccionBenef;
	}
	public void setDireccionBenef(String direccionBenef) {
		this.direccionBenef = direccionBenef;
	}
	
	
}
