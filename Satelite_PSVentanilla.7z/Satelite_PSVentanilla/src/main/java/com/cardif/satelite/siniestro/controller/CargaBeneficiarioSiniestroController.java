package com.cardif.satelite.siniestro.controller;


import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR;
import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.siniestro.model.SiniManual;
import com.cardif.satelite.siniestro.service.SiniManualService;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;
import com.cardif.sunsystems.util.Utilidades;

@Controller("cargaBeneficiarioSiniestroController")
@Scope("request")
public class CargaBeneficiarioSiniestroController extends BaseController {
	public static final Logger log = Logger.getLogger(CargaBeneficiarioSiniestroController.class);
	// private boolean upload;
	private boolean autoUpload = false;
	private boolean activarBotones = false;
	private String nombreArchivo;
	private File archivoFinal;
	private String usuarioDB = "";
	private List<SiniManual> listaSiniManual;
	private List<Parametro> listaEstadosBeneficiario;
	private List<Parametro> listaMonedas;
	private List<Parametro> listaDescripcionSiniestrosManuales;
	private List<Parametro> listaTipoDocumentos;
	private Parametro parametroEstadoBeneDefault;
	private SiniManual siniManualSeleccionado;

	static final String ARCHIVO_ESPERADO = ".XLSX";
	static final String ESTADO_BENEFICIARIO_CATEGORIA = "SINIESTADOSBENEFICIARIOS";
	static final String TIPO_MONEDA = "TIPOMONEDA";
	static final String CODIGO_ESTADO_DEFAULT = "01";
	static final String SINI_MANUAL = "SINIMANUAL";
	public static final String TIP_PARAM_DETALLE = "D";
	static final String MSJ_ERROR_EXCEL = "Archivo Excel no corresponde al formato esperado. Por favor, procese nuevamente";
	static final int MAXIMO_COLUMAS_EXCEL = 31;

	private String filtroRamo;
	private Date filtroInicio;
	private Date filtroFin;
	private String filtroNumeroSiniestro;
	private String filtroTipoDocumento;
	private String filtroNumeroDocumento;
	private String filtroEstado;
	private String filtroNombre;
	private String filtroApellidoPaterno;
	private String filtroApellidoMaterno;

	private List<SelectItem> selectItemsRamo;
	private List<SelectItem> selectItemsDocumentos;
	private List<SelectItem> selectItemsEstados;
	private boolean excelIncorrecto = false;
	private boolean errorExcel;
	private String mensajeErrorExcel;

	
	@Autowired
	private ParametroService parametroService;
	@Autowired
	private SiniManualService siniManualService;

	@Override
	@PostConstruct
	public String inicio() {
		log.info("Inicio");
		String respuesta = null;

		if (!tieneAcceso()) {
			log.debug("No cuenta con los accesos necesarios");
			return "accesoDenegado";
		}

		try {
			usuarioDB = SecurityContextHolder.getContext().getAuthentication().getName();
			listaEstadosBeneficiario = parametroService.buscar(Constantes.COD_PARAM_ESTADO_BENEFICIARIO, TIP_PARAM_DETALLE);
			listaMonedas = parametroService.buscar(Constantes.COD_PARAM_TIPO_MONEDA, TIP_PARAM_DETALLE);
			listaDescripcionSiniestrosManuales = parametroService.buscar(Constantes.COD_PARAM_SINIESTRO_MANUAL, TIP_PARAM_DETALLE);
			listaTipoDocumentos = parametroService.buscar(Constantes.COD_PARAM_TIPOS_DOCUMENTO_SINI, TIP_PARAM_DETALLE);
			parametroEstadoBeneDefault = getEstadoDefault(listaEstadosBeneficiario);
			cargaSelectItemRamos();
			cargaSelectItemDocumentos();
			cargaSelectItemEstados();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = MSJ_ERROR;
		}
		log.info("Fin");
		return respuesta;
	}

	public List<SelectItem> getSelectItemsEstados() {
		return selectItemsEstados;
	}

	public void setSelectItemsEstados(List<SelectItem> selectItemsEstados) {
		this.selectItemsEstados = selectItemsEstados;
	}

	private String obtenerIdTipoDocumento(String descripcionDocumento) {
		String idTipoDocumento = "";
		for (Parametro parametroItem : listaTipoDocumentos) {
			if (parametroItem.getNomValor().trim().equalsIgnoreCase(descripcionDocumento)) {
				idTipoDocumento = parametroItem.getCodValor().trim();
				break;
			}
		}
		return idTipoDocumento;
	}

	public void listener(UploadEvent event) {
		log.info("cargaBeneficiarioSiniestroController.listener()--inicio");

		String respuesta = null;
		errorExcel = false;
		excelIncorrecto = false;
		mensajeErrorExcel = "";

		try {

			nombreArchivo = new String();
			UploadItem item = event.getUploadItem();
			File archivo = item.getFile();

			nombreArchivo = item.getFileName().substring(item.getFileName().lastIndexOf("\\") + 1);

			archivoFinal = File.createTempFile("Beneficiario_", nombreArchivo);
			log.info("Archivo final: " + archivoFinal);
			FileUtils.copyFile(archivo, archivoFinal);
			archivo.delete();
			if (validarTipoArchivo(nombreArchivo)) {
				if (listaSiniManual == null) {
					listaSiniManual = new ArrayList<SiniManual>();
				} else {
					listaSiniManual.clear();
				}
				listaSiniManual.addAll(getObtenerListaDeExcel(archivoFinal));
				log.debug(listaSiniManual.size());
				activarBotones = true;
			} else {
				SateliteUtil.mostrarMensaje("Tipo de archivo incorrecto. Se espera " + ARCHIVO_ESPERADO);
			}

		} catch (Exception ex) {
			activarBotones = false;
			errorExcel = true;
			mensajeErrorExcel = MSJ_ERROR_EXCEL;
			log.error(ex.getMessage(), ex);
			SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_EXCEL);

		}

		log.info("cargaBeneficiarioSiniestroController.listener()--fin");
		// return respuesta;
	}

	public boolean validarTipoArchivo(String nombre) {
		boolean band = false;
		if (nombre.trim().toUpperCase().contains(ARCHIVO_ESPERADO)) {
			band = true;
		}
		return band;
	}

	public List<SiniManual> getObtenerListaDeExcel(File archivo) throws Exception {
		List<SiniManual> lista = null;
		String sheetName = "";
		int numeroColumna = 0;
		try {
			XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(archivo));
			XSSFSheet sheet = wb.getSheetAt(0);// sheetIndex);
			sheetName = wb.getSheetName(0);
			log.info("Nombre de la hoja :" + sheetName);
			Iterator<Row> filasExcel = sheet.iterator();
			lista = new ArrayList<SiniManual>();
			while (filasExcel.hasNext()) {
				Row fila = filasExcel.next();
				if (fila.getRowNum() != 0) {
					SiniManual siniManualFila = new SiniManual();
					Iterator<Cell> columnas = fila.cellIterator();
					numeroColumna = 0;
					while (columnas.hasNext()) {
						Cell celda = columnas.next();
						log.debug("(Fila,columna) = (" + fila.getRowNum() + "," + (numeroColumna + 1) + ")");
						switch (numeroColumna) {
						case 0:
							siniManualFila.setBeneFechaNotificacion(celda.getDateCellValue());
							break;
						case 1:
							siniManualFila.setSiniestroId(celda.getStringCellValue().trim());
							break;
						case 2:
							siniManualFila.setBeneFechaUltimaDocument(celda.getDateCellValue());
							break;
						case 3:
							siniManualFila.setBeneSocio(celda.getStringCellValue().trim());
							break;
						case 4:
							siniManualFila.setBeneProducto(celda.getStringCellValue().trim());
							break;
						case 5:
							if (celda.getCellType() == Cell.CELL_TYPE_NUMERIC) {
								celda.setCellType(Cell.CELL_TYPE_STRING);
							}
							siniManualFila.setBeneNumeroPoliza(celda.getStringCellValue().trim());
							break;
						case 6:
							siniManualFila.setBeneFechaOcurrencia(celda.getDateCellValue());
							break;
						case 7:
							siniManualFila.setBeneNumeroPlanilla(celda.getStringCellValue().trim());
							break;
						case 8:
							siniManualFila.setBeneNombreCompleto(celda.getStringCellValue().trim());
							break;
						case 9:
							siniManualFila.setDescripcionTipoDocumento(celda.getStringCellValue().trim());
							siniManualFila.setBeneTipoDocumento(obtenerIdTipoDocumento(siniManualFila.getDescripcionTipoDocumento()));
							break;
						case 10:
							celda.setCellType(Cell.CELL_TYPE_STRING);
							siniManualFila.setBeneNumeroDocumento(celda.getStringCellValue().trim());
							break;
						case 11:
							siniManualFila.setBenePais(celda.getStringCellValue().trim());
							break;
						case 12:
							siniManualFila.setBeneParentesco(celda.getStringCellValue().trim());
							break;
						case 13:
							siniManualFila.setBenePorcentajeParticipacion(celda.getNumericCellValue());
							break;
						case 14:
							siniManualFila.setDecripcionMoneda(celda.getStringCellValue().trim());
							siniManualFila.setBeneMoneda(obtenerTipoMoneda(listaMonedas, siniManualFila.getDecripcionMoneda().trim()));
							break;
						case 15:
							siniManualFila.setBeneMontoPagar(celda.getNumericCellValue());
							break;
						case 16:
							siniManualFila.setBeneFechaAproRechCarta(celda.getDateCellValue());
							break;
						case 17:
							siniManualFila.setBeneMesAproRechCarta(celda.getStringCellValue().trim());
							break;
						case 18:
							siniManualFila.setBeneFechaEntregaOpConta(celda.getDateCellValue());
							break;
						case 19:
							siniManualFila.setBeneFechaContabilizado(celda.getDateCellValue());
							break;
						case 20:
							siniManualFila.setBeneFechaRegistroPago(celda.getDateCellValue());
							break;
						case 21:
							siniManualFila.setBeneFechaAsignaFirmantes(celda.getDateCellValue());
							break;
						case 22:
							siniManualFila.setBeneFechaCargaBanco(celda.getDateCellValue());
							break;
						case 23:
							siniManualFila.setBeneFechaCobro(celda.getDateCellValue());
							break;
						case 24:
							celda.setCellType(Cell.CELL_TYPE_STRING);
							siniManualFila.setBeneTelefono1(celda.getStringCellValue().trim());
							break;
						case 25:
							celda.setCellType(Cell.CELL_TYPE_STRING);
							siniManualFila.setBeneTelefono2(celda.getStringCellValue().trim());
							break;
						case 26:
							siniManualFila.setBeneEmail(celda.getStringCellValue().trim());
							break;
						case 27:
							siniManualFila.setBeneNumeroCuentaBan(celda.getStringCellValue().trim());
							break;
						case 28:
							siniManualFila.setBeneApellidoPaterno(celda.getStringCellValue().trim());
							break;
						case 29:
							siniManualFila.setBeneApellidoMaterno(celda.getStringCellValue().trim());
							break;
						case 30:
							siniManualFila.setBeneNombre(celda.getStringCellValue().trim());
							break;
						}
						numeroColumna = numeroColumna + 1;
						if (numeroColumna > MAXIMO_COLUMAS_EXCEL) {
							excelIncorrecto = true;
							log.debug(MSJ_ERROR_EXCEL);
							lista.clear();
							throw new Exception("Excel incorrecto: número de columnas no permitido");
						}
					}
					if (!excelIncorrecto) {
						siniManualFila.setDescripcionEstado(parametroEstadoBeneDefault.getNomValor().trim());
						siniManualFila.setBeneEstado(parametroEstadoBeneDefault.getCodValor().trim());
						siniManualFila.setRamo(obtenerDescripcioRamo(siniManualFila.getSiniestroId()));
						siniManualFila.setBeneFechaPendiente(Calendar.getInstance().getTime());
						siniManualFila.setBeneFechaEnvioOpConta(Calendar.getInstance().getTime());
						siniManualFila.setBenefechaRegistro(Calendar.getInstance().getTime());
						log.info("" + siniManualFila.getBeneEstado().length());
						siniManualFila.setBeneUsuarioRegistra(usuarioDB.trim());
						if (siniManualFila.getBeneNumeroPlanilla() == null || siniManualFila.getBeneNumeroPlanilla().trim().compareTo("") == 0) {
							siniManualFila.setBeneNumeroPlanilla(siniManualFila.getSiniestroId());
						}
						lista.add(siniManualFila);
					} else {
						break;
					}
				}
			}

		} catch (Exception ex) {
			throw new Exception(ex);
		}
		return lista;
	}

	public void procesar(ActionEvent event) {
		if (log.isInfoEnabled()) {
			log.info("Inicio procesar");
		}
		try {
			validarCamposExcel();
			siniManualService.createAllSiniManual(listaSiniManual);
			SateliteUtil.mostrarMensaje("El excel fue procesado correctamente");
			limpiarFormulario();
			limpiarFiltros();

		} catch (SyncconException ex) {
			if (listaSiniManual != null) {
				listaSiniManual.clear();
			}
			log.error(ErrorConstants.ERROR_SYNCCON + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessageComplete(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			if (listaSiniManual != null) {
				listaSiniManual.clear();
			}
			e.printStackTrace();

			if (e.getMessage() != null) {
				log.info("error!!!");
				SateliteUtil.mostrarMensaje(e.getMessage());
			}
		}

	}

	public void buscar() {
		if (log.isInfoEnabled()) {
			log.info("Inicio busqueda controller");
		}

		try {
			if (validarFecha()) {
				if (!activarBotones) {
					if (listaSiniManual == null) {
						listaSiniManual = new ArrayList<SiniManual>();
					} else {
						listaSiniManual.clear();
					}

					log.info("Pinta ramos: "+ filtroRamo+"--fin pinta ramo");
					log.info("Pinta tipo documento: "+ filtroTipoDocumento+"--fin pinta tipo documento");
					log.info("Pinta estado: "+ filtroEstado +"--fin pinta estado");

					
					listaSiniManual=siniManualService.getAllSiniManualByFilter(Utilitarios.getEmptyString(filtroRamo), filtroInicio, filtroFin, Utilitarios.getEmptyString(filtroNumeroSiniestro.trim()),
							Utilitarios.getEmptyString(filtroTipoDocumento), Utilitarios.getEmptyString(filtroNumeroDocumento.trim()), Utilitarios.getEmptyString(filtroNombre.trim()), Utilitarios.getEmptyString(filtroApellidoPaterno.trim()), Utilitarios.getEmptyString(filtroApellidoMaterno.trim()),
							Utilitarios.getEmptyString(filtroEstado));
					log.info("cantidad de registros obtenidos: "+ listaSiniManual.size());
				}
			} else {
				SateliteUtil.mostrarMensaje("Rango de fechas inválido.");
			}

		} catch (SyncconException ex) {
			log.error(ErrorConstants.ERROR_SYNCCON + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception ex) {
			log.info("error!!!: ");
			if (ex!= null) {
				log.error(ex.getMessage());
				SateliteUtil.mostrarMensaje(ex.getMessage());
			}
		}

	}

	

	public boolean validarFecha() {
		if (filtroInicio != null || filtroFin != null) {
			if (filtroInicio != null && filtroFin == null) {
				return false;
			}
			if (filtroInicio == null && filtroFin != null) {
				return false;
			}
			Calendar fecini = Calendar.getInstance();
			fecini.setTime(filtroInicio);
			Calendar fecfin = Calendar.getInstance();
			fecfin.setTime(filtroFin);
			return (Utilitarios.validarRangoFechas(fecini, fecfin));

		}
		return true;
	}

	public void cancelar(ActionEvent event) {
		limpiarFormulario();
	}

	public void limpiar(ActionEvent event) {
		limpiarFiltros();
	}

	public void limpiarFormulario() {
		activarBotones = false;
		errorExcel = false;
		if (listaSiniManual != null) {
			listaSiniManual.clear();
		}
	}

	public void limpiarFiltros() {
		filtroRamo = "";
		filtroInicio = null;
		filtroFin = null;
		filtroNumeroSiniestro = "";
		filtroTipoDocumento = "";
		filtroNumeroDocumento = "";
		filtroEstado = "";
		filtroNombre = "";
		filtroApellidoPaterno = "";
		filtroApellidoMaterno = "";
		if (listaSiniManual != null) {
			listaSiniManual.clear();
		}
	}

	public void verDetalle() {
		if (siniManualSeleccionado != null) {
			log.info("" + siniManualSeleccionado.getBeneNombre());
		}
	}

	private void validarCamposExcel() throws SyncconException {
		int fila = 1;
		String msjError = "";
		msjError = "Error en el archivo excel: Fila = " + fila;
		if (excelIncorrecto) {
			excelIncorrecto = false;
			throw new SyncconException(MSJ_ERROR_EXCEL, FacesMessage.SEVERITY_ERROR);
		} else {
			for (SiniManual item : listaSiniManual) {
				if (!validarNumeroSiniestro(item.getSiniestroId())) {
					throw new SyncconException(msjError + " Numero Planilla incorrecto", FacesMessage.SEVERITY_INFO);
				}
				if (item.getBeneFechaOcurrencia() == null) {
					throw new SyncconException(msjError + " Fecha de ocurrencia incorrecto", FacesMessage.SEVERITY_INFO);
				}
				if (item.getBeneTipoDocumento() == null && item.getBeneTipoDocumento().trim().compareTo("") == 0) {
					throw new SyncconException(msjError + " tipo de documento incorrecto", FacesMessage.SEVERITY_INFO);
				}
				if (!Utilidades.containsOnlyNumbers(item.getBeneNumeroDocumento())) {
					throw new SyncconException(msjError + " Numero de documento incorrecto", FacesMessage.SEVERITY_INFO);
				}
			}
		}
	}

	private boolean validarNumeroSiniestro(String numeroSiniestro) {
		boolean band = false;
		String cadenaFinal = "";
		if (numeroSiniestro.trim().compareTo("") != 0) {
			String[] partes = numeroSiniestro.split("-");
			for (int i = 0; i < partes.length; i++) {
				cadenaFinal = cadenaFinal.concat(partes[i]);
			}
			band = Utilidades.containsOnlyNumbers(cadenaFinal);
		}
		return band;
	}

	private Parametro getEstadoDefault(List<Parametro> lista) {
		Parametro paramCfg = null;
		for (Parametro parametros : lista) {
			if (parametros.getCodValor().trim().compareTo(CODIGO_ESTADO_DEFAULT) == 0) {
				paramCfg = parametros;
				break;
			}
		}
		return paramCfg;
	}

	private String obtenerTipoMoneda(List<Parametro> listaMonedas, String descripcion) {
		String tipoMonedaFinal = "";
		for (Parametro paramCfg : listaMonedas) {
			if (paramCfg.getNomValor().trim().compareTo(descripcion) == 0) {
				tipoMonedaFinal = paramCfg.getCodValor().trim();
				break;
			}
		}
		return tipoMonedaFinal;
	}

	private void cargaSelectItemRamos() {
		if (selectItemsRamo == null) {
			selectItemsRamo = new ArrayList<SelectItem>();
		} else {
			selectItemsRamo.clear();
		}
		
		if (listaDescripcionSiniestrosManuales != null && listaDescripcionSiniestrosManuales.size() > 0) {
			for (Parametro paramCfg : listaDescripcionSiniestrosManuales) {
				selectItemsRamo.add(new SelectItem(paramCfg.getCodValor().trim(), paramCfg.getNomValor().trim()));
			}
		}
	}

	private void cargaSelectItemDocumentos() {
		if (selectItemsDocumentos == null) {
			selectItemsDocumentos = new ArrayList<SelectItem>();
		} else {
			selectItemsDocumentos.clear();
		}
		
		if (listaTipoDocumentos != null && listaTipoDocumentos.size() > 0) {
			for (Parametro paramCfg : listaTipoDocumentos) {
				selectItemsDocumentos.add(new SelectItem(paramCfg.getCodValor().trim(), paramCfg.getNomValor().trim()));
			}
		}
	}

	private void cargaSelectItemEstados() {
		if (selectItemsEstados == null) {
			selectItemsEstados = new ArrayList<SelectItem>();
		} else {
			selectItemsEstados.clear();
		}
		
		if (listaEstadosBeneficiario != null && listaEstadosBeneficiario.size() > 0) {
			for (Parametro paramCfg : listaEstadosBeneficiario) {
				selectItemsEstados.add(new SelectItem(paramCfg.getCodValor().trim(), paramCfg.getNomValor().trim()));
			}
		}
	}

	public void eliminarFila() {
		List<SiniManual> nuevaLista = eliminarDeLista(listaSiniManual, siniManualSeleccionado);
		listaSiniManual.clear();
		listaSiniManual.addAll(nuevaLista);
	}

	public static List<SiniManual> eliminarDeLista(List<SiniManual> lista, SiniManual siniManual) {
		List<SiniManual> nuevaLista = new ArrayList<SiniManual>();
		nuevaLista.addAll(lista);
		Iterator iterator = nuevaLista.iterator();
		while (iterator.hasNext()) {
			SiniManual siniLista = (SiniManual) iterator.next();
			if (siniManual.getSiniestroId().compareTo(siniLista.getSiniestroId()) == 0 && siniManual.getBeneTipoDocumento().compareTo(siniLista.getBeneTipoDocumento()) == 0
					&& siniManual.getBeneNumeroDocumento().compareTo(siniLista.getBeneNumeroDocumento()) == 0) {
				iterator.remove();
				break;
			}
		}
		return nuevaLista;
	}

	private String obtenerDescripcioRamo(String idSiniestro) {
		String descripcion = "Otro";
		for (Parametro paramCfg : listaDescripcionSiniestrosManuales) {
			log.info(idSiniestro.substring(0, 2));
			log.info(paramCfg.getCodValor().trim());
			if (idSiniestro.substring(0, 2).trim().compareTo(paramCfg.getCodValor().trim()) == 0) {
				descripcion = paramCfg.getNomValor();
				break;
			}
		}
		return descripcion;
	}

	private String obtenerDescripcionTipoDoc(String tipoDocumento) {
		String descripcion = null;
		if (tipoDocumento != null) {
			for (Parametro paramCfg : listaTipoDocumentos) {
				if (paramCfg.getCodValor().trim().compareTo(tipoDocumento) == 0) {
					descripcion = paramCfg.getNomValor().trim();
					break;
				}
			}
		}
		return descripcion;
	}

	public List<SiniManual> getListaSiniManual() {
		return listaSiniManual;
	}

	public void setListaSiniManual(List<SiniManual> listaSiniManual) {
		this.listaSiniManual = listaSiniManual;
	}

	public boolean isAutoUpload() {
		return autoUpload;
	}

	public void setAutoUpload(boolean autoUpload) {
		this.autoUpload = autoUpload;
	}

	public boolean isActivarBotones() {
		return activarBotones;
	}

	public void setActivarBotones(boolean activarBotones) {
		this.activarBotones = activarBotones;
	}

	public SiniManual getSiniManualSeleccionado() {
		return siniManualSeleccionado;
	}

	public void setSiniManualSeleccionado(SiniManual siniManualSeleccionado) {
		this.siniManualSeleccionado = siniManualSeleccionado;
	}

	public String getFiltroRamo() {
		return filtroRamo;
	}

	public void setFiltroRamo(String filtroRamo) {
		this.filtroRamo = filtroRamo;
	}

	public Date getFiltroInicio() {
		return filtroInicio;
	}

	public void setFiltroInicio(Date filtroInicio) {
		this.filtroInicio = filtroInicio;
	}

	public Date getFiltroFin() {
		return filtroFin;
	}

	public void setFiltroFin(Date filtroFin) {
		this.filtroFin = filtroFin;
	}

	public String getFiltroNumeroSiniestro() {
		return filtroNumeroSiniestro;
	}

	public void setFiltroNumeroSiniestro(String filtroNumeroSiniestro) {
		this.filtroNumeroSiniestro = filtroNumeroSiniestro;
	}

	public String getFiltroTipoDocumento() {
		return filtroTipoDocumento;
	}

	public void setFiltroTipoDocumento(String filtroTipoDocumento) {
		this.filtroTipoDocumento = filtroTipoDocumento;
	}

	public String getFiltroNumeroDocumento() {
		return filtroNumeroDocumento;
	}

	public void setFiltroNumeroDocumento(String filtroNumeroDocumento) {
		this.filtroNumeroDocumento = filtroNumeroDocumento;
	}

	public String getFiltroEstado() {
		return filtroEstado;
	}

	public void setFiltroEstado(String filtroEstado) {
		this.filtroEstado = filtroEstado;
	}

	public String getFiltroNombre() {
		return filtroNombre;
	}

	public void setFiltroNombre(String filtroNombre) {
		this.filtroNombre = filtroNombre;
	}

	public String getFiltroApellidoPaterno() {
		return filtroApellidoPaterno;
	}

	public void setFiltroApellidoPaterno(String filtroApellidoPaterno) {
		this.filtroApellidoPaterno = filtroApellidoPaterno;
	}

	public String getFiltroApellidoMaterno() {
		return filtroApellidoMaterno;
	}

	public void setFiltroApellidoMaterno(String filtroApellidoMaterno) {
		this.filtroApellidoMaterno = filtroApellidoMaterno;
	}

	public List<SelectItem> getSelectItemsRamo() {
		return selectItemsRamo;
	}

	public void setSelectItemsRamo(List<SelectItem> selectItemsRamo) {
		this.selectItemsRamo = selectItemsRamo;
	}

	public List<SelectItem> getSelectItemsDocumentos() {
		return selectItemsDocumentos;
	}

	public void setSelectItemsDocumentos(List<SelectItem> selectItemsDocumentos) {
		this.selectItemsDocumentos = selectItemsDocumentos;
	}

	public boolean isErrorExcel() {
		return errorExcel;
	}

	public void setErrorExcel(boolean errorExcel) {
		this.errorExcel = errorExcel;
	}

	public String getMensajeErrorExcel() {
		return mensajeErrorExcel;
	}

	public void setMensajeErrorExcel(String mensajeErrorExcel) {
		this.mensajeErrorExcel = mensajeErrorExcel;
	}

}
