package com.cardif.satelite.siniestro.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.model.satelite.BeneficiarioSiniestro;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;

public interface SiniBeneficiariosService {
	
	public int insertarSiniBeneficiario(BeneficiarioSiniestro beneficiarioSiniestro) throws SyncconException;
	
	public List<BeneficiarioSiniestro> listarBeneficiariosBySiniestro(String siniestroID) throws SyncconException;
	
	public void eliminarBeneficiarioByID(Long beneficiarioID) throws SyncconException;
	
	public void eliminarBeneficiariosByNroSiniestro(List<BeneficiarioSiniestro> listaSiniBeneficiario) throws SyncconException;
	
	public void modificarBeneficiarioByID(BeneficiarioSiniestro beneficiarioSiniestro) throws SyncconException;
	
	public void actualizarParticipacionBeneComun(List<BeneficiarioSiniestro> listaSiniBeneficiario, BigDecimal impPagos) throws SyncconException;

	public void actualizarParticipacionBeneComun(
			List<BeneficiarioSiniestro> listaSiniBeneficiario,
			Long beneficiarioID, BigDecimal benePart, BigDecimal partComun,
			BigDecimal impPagos) throws SyncconException;
	
	public void updateBeneficiarioFecOpContable(List<BeneficiarioSiniestro> listaSiniBeneficiario) throws SyncconException;

	
	public void updateBeneficiarioLoteId(String siniestroId,String nombres,String loteId,String usuario)throws SyncconException;
	
	public BeneficiarioSiniestro beneficiariosBySiniestroNombres(String siniestroId, String nombres)throws SyncconException;

	
//	public void updateBeneTramaConfirmados(String beneNumDoc, String numLoteSerie) throws SyncconException;
	
//	public void updateBeneTramaCobros(String beneNumDoc, String beneMonto) throws SyncconException;
	
	public void actualizarBeneficiariosTramaCobros(List<TramaConfPagoSiniVentanilla> listaArchivoValidadosCobros) throws SyncconException;


	public void actualizarBeneficiariosTramaConfirmados(List<TramaConfPagoSiniVentanilla> listaArchivoValidadosConf) throws SyncconException;
	
	public void updateBeneficiarioFechaAsigna( String loteId,String usuario)throws SyncconException;
	
	public void updateListaBeneficiarioFechaAsigna( List<String> loteId,String usuario)throws SyncconException;
	
	public boolean validarExisteLoteIdArchConf(String loteId) throws SyncconException;

}
