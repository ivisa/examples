package com.cardif.satelite.siniestro.service.impl;

import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_ACTUALIZAR;
import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_ELIMINAR;
import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_INSERTAR;
import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_OBTENER;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.model.satelite.TramaConfPagoSiniVentanilla;
import com.cardif.satelite.siniestro.dao.CargaTramaPagoSiniVentanillaMapper;
import com.cardif.satelite.siniestro.service.SiniTramaPagoVentanillaService;

@Service("siniTramaPagoVentanillaService")
public class SiniTramaPagoVentanillaServiceImpl implements SiniTramaPagoVentanillaService{
	
	public static final Logger log = Logger.getLogger(SiniTramaPagoVentanillaServiceImpl.class);
	
	@Autowired
	CargaTramaPagoSiniVentanillaMapper cargaTramaPagoSiniVentanillaMapper;
	
	
	public void insertar(TramaConfPagoSiniVentanilla tramaPagoSiniVentanilla) throws SyncconException{
		log.info("Inicio");
			
		try{
			if (log.isDebugEnabled()) log.debug("Input [ " + BeanUtils.describe(tramaPagoSiniVentanilla) + " ]");
		
			cargaTramaPagoSiniVentanillaMapper.insert(tramaPagoSiniVentanilla);
			
			if (log.isDebugEnabled()) log.debug("Output [OK]");
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
			e.printStackTrace();
			throw new SyncconException(COD_ERROR_BD_INSERTAR);
		}
		
		log.info("Fin");
	}
	
	
	public void eliminarByID(Long tramaId) throws SyncconException{
		log.info("Inicio");
		try{
			if (log.isDebugEnabled()) log.debug("Input [" + tramaId + "]");
			
			cargaTramaPagoSiniVentanillaMapper.deleteByPrimaryKey(tramaId);
			
			if (log.isDebugEnabled()) log.debug("Output [OK]");

		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ELIMINAR);
		}
		log.info("Fin");
	}
	
	
	public void modificarByID(TramaConfPagoSiniVentanilla tramaPagoSiniVentanilla) throws SyncconException{
		log.info("Inicio");
		try{
			if (log.isDebugEnabled()) log.debug("Input [ " + BeanUtils.describe(tramaPagoSiniVentanilla) + " ]");
			 
			cargaTramaPagoSiniVentanillaMapper.updateByPrimaryKeySelective(tramaPagoSiniVentanilla);
			
			if (log.isDebugEnabled()) log.debug("Output [OK]");

		}catch(Exception e){
			log.error(e.getMessage(), e);
		    throw new SyncconException(COD_ERROR_BD_ACTUALIZAR);
		}
		log.info("Fin");
	}
	
	
	public TramaConfPagoSiniVentanilla obtenerById(Long tramaId) throws SyncconException{
		log.info("Inicio");
		TramaConfPagoSiniVentanilla tramaPagoSiniVentanilla = null;
		try {
			if (log.isDebugEnabled()) log.debug("Input [" + tramaId + "]");
	
			tramaPagoSiniVentanilla = cargaTramaPagoSiniVentanillaMapper.selectByPrimaryKey(tramaId);
	
			if (log.isDebugEnabled()) log.debug("Output [" + BeanUtils.describe(tramaPagoSiniVentanilla) + "]");
		  
		} catch (Exception e) {
		  log.error(e.getMessage(), e);
		  throw new SyncconException(COD_ERROR_BD_OBTENER);
		}
		log.info("Fin");
		  return tramaPagoSiniVentanilla;
	}
	
	
	public void insertarListaTrama(List<TramaConfPagoSiniVentanilla> listaTramaSiniVentanilla) throws SyncconException{
		log.info("Inicio");
			
		try{
			if (log.isDebugEnabled()) log.debug("Input List [ " + BeanUtils.describe(listaTramaSiniVentanilla) + " ]");
		
			for(TramaConfPagoSiniVentanilla reg : listaTramaSiniVentanilla){
				if (log.isDebugEnabled()) log.debug("Input Registro [ " + BeanUtils.describe(reg) + " ]");
				cargaTramaPagoSiniVentanillaMapper.insert(reg);
				if (log.isDebugEnabled()) log.debug("Output [OK]");
			}
			
			if (log.isDebugEnabled()) log.debug("Output [OK]");
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
			e.printStackTrace();
			throw new SyncconException(COD_ERROR_BD_INSERTAR);
		}
		
		log.info("Fin");
	}
	
	
	
	
}