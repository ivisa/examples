package com.cardif.satelite.siniestro.dao;


import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.satelite.BeneficiarioSiniestro;


public interface BeneficiarioSiniestroMapper {
	
	
	public int insert(BeneficiarioSiniestro record);
	
	public BeneficiarioSiniestro selectByPrimaryKey(Long beneficiarioID);
	
	public int deleteByPrimaryKey(Long beneficiarioID);
	
	public int updateByPrimaryKeySelective(BeneficiarioSiniestro record);
	
	final String UPDATE_BENE_TRAMA_CONF = 		
			" UPDATE SINI_BENEF SET BeneFecProcesado = GETDATE(), BeneEstado = #{beneSiniEstado,jdbcType=NVARCHAR} " +  
			" WHERE BeneNumDoc = #{beneNumDoc,jdbcType=NVARCHAR} AND SUBSTRING(LoteId, 1, 8) = #{numLoteSerie,jdbcType=NVARCHAR} ";
	
	@Select(UPDATE_BENE_TRAMA_CONF)
	public void updateBeneTramaConfirmados(@Param("beneSiniEstado")String beneSiniEstado, @Param("beneNumDoc")String beneNumDoc, @Param("numLoteSerie")String numLoteSerie);
	
	
	final String UPDATE_BENE_TRAMA_COBROS =
			" UPDATE SINI_BENEF SET BeneFecCobrado = GETDATE(), BeneEstado = #{beneSiniEstado,jdbcType=NVARCHAR} " +  
			" WHERE BeneNumDoc = #{beneNumDoc,jdbcType=NVARCHAR} AND cast(cast(BeneMonto as DECIMAL(14,2)) as varchar(17)) = #{beneMonto,jdbcType=NVARCHAR} ";

	@Select(UPDATE_BENE_TRAMA_COBROS)
	public void updateBeneTramaCobrados(@Param("beneSiniEstado")String beneSiniEstado, @Param("beneNumDoc")String beneNumDoc, @Param("beneMonto")String beneMonto);

	
	
	final String SELECT_BENEFICIARIOS_BY_SINIESTRO = "SELECT BENE.BeneficiarioID, "
			+ " BENE.SiniestroID, "
			+ " BENE.BeneApePat, "
			+ " BENE.BeneApeMat , "
			+ " BENE.BeneNom, "
			+ " BENE.BeneDocTip, "
			+ " BENE.BeneNumDoc, "
			+ " BENE.BenePais, "
			+ " BENE.BeneDepartamento, "
			+ " BENE.BeneProvincia, "
			+ " BENE.BeneDistrito, "
			+ " BENE.BeneEma, "
			+ " BENE.BeneCtaBanco, "
			+ " BENE.BeneTel, "
			+ " BENE.BeneTel2, "
			+ " BENE.BeneDir, "
			+ " BENE.BeneParentesco, "
			+ " BENE.BenePart, "
			+ " BENE.BeneMonto, "
			+ " BENE.FecOpConta, "
			+ " BENE.BeneEstado, "
			+ " BENE.BeneFecPendiente, "
			+ " BENE.BeneFecEnvOpContable, "
			+ " BENE.BeneFecProvisionado, "
			+ " BENE.BeneFecRegPago, "
			+ " BENE.BeneFecAsigFirmante, "
			+ " BENE.BeneFecProcesado, "
			+ " BENE.BeneFecCobrado, "
			+ " BENE.LoteId, "
			+ " BENE.UsuCrea, "
			+ " BENE.FecCrea, "
			+ " BENE.UsuModifica, "
			+ " BENE.FecModifica, "
			+ " P2.CFG_DESCRIPCION AS BeneEstadoDesc, "
			+ " P3.NOM_VALOR AS BeneDocTipDesc "
			+ " FROM SINI_BENEF BENE "
			+ " LEFT JOIN PARAMETRO P2 ON P2.COD_VALOR = BENE.BeneEstado AND P2.TIP_PARAM = 'D' AND P2.COD_PARAM = '"+Constantes.COD_PARAM_ESTADO_BENEFICIARIO+"' "
			+ " LEFT JOIN PARAMETRO P3 ON P3.COD_VALOR = BENE.BeneDocTip AND P3.TIP_PARAM = 'D' AND P3.COD_PARAM = '027' "
			+ " WHERE BENE.SiniestroID = #{siniestroID,jdbcType=NVARCHAR} ";
	
	
	@Select(SELECT_BENEFICIARIOS_BY_SINIESTRO)
  	@ResultMap("BaseResultMap")
	public List<BeneficiarioSiniestro> listarBeneficiariosBySiniestro(@Param("siniestroID") String siniestroID);
	
	
	final String UPDATE_FECHA_ENVIO_OP_CONTABLE =
			" UPDATE SINI_BENEF " + 
			" SET BeneFecEnvOpContable = GETDATE() " +
            " WHERE BeneficiarioID = #{beneficiarioID,jdbcType=NUMERIC} ";
			
	
	@Select(UPDATE_FECHA_ENVIO_OP_CONTABLE)
	public void updateBeneficiarioFecOpContable(@Param("beneficiarioID") Long beneficiarioID);
	
	final String UPDATE_BENEFICIARIO_LOTE_ID=""
			+ " UPDATE SINI_BENEF"
			+ " SET loteId = #{loteId,jdbcType=NVARCHAR}"
			+ " ,UsuModifica = #{usuario,jdbcType=NVARCHAR}"
			+ " ,FecModifica = CONVERT (date,GETDATE())"
			+ " WHERE"
			+ " LTRIM(RTRIM(SiniestroID))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BeneApePat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneApeMat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneNom,' ','')))))=UPPER(#{nombres,jdbcType=NVARCHAR})";
	
	final String UPDATE_SINIESTRO_FECHA_PROVISIONADO=""
			+ " UPDATE SINI_BENEF"
			+ " SET BeneFecProvisionado =  #{beneFechaProvisionado,jdbcType=DATE}"
			+ " ,BeneEstado = '02'"
			+ " ,UsuModifica = #{usuario,jdbcType=NVARCHAR}"
			+ " ,FecModifica = CONVERT (date,GETDATE())"
			+ " WHERE"
			+ " LTRIM(RTRIM(SiniestroID))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BeneApePat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneApeMat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneNom,' ','')))))=UPPER(#{nombres,jdbcType=NVARCHAR})"
			+ " AND BeneMonto = #{beneMontoPagar,javaType=double,jdbcType=NUMERIC}"
			+ " AND BeneFecProvisionado IS NULL";
	
	final String UPDATE_SINIESTRO_FECHA_REGISTRO_PAGO=""
			+ " UPDATE SINI_BENEF"
			+ " SET BeneFecRegPago =  CONVERT (date,GETDATE())"
			+ " ,BeneEstado = '03'"
			+ " ,UsuModifica = #{usuario,jdbcType=NVARCHAR}"
			+ " ,FecModifica = CONVERT (date,GETDATE())"
			+ " WHERE"
			+ " LTRIM(RTRIM(SiniestroID))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BeneApePat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneApeMat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneNom,' ','')))))=UPPER(#{nombres,jdbcType=NVARCHAR})"
			+ " AND BeneMonto = #{beneMontoPagar,javaType=double,jdbcType=NUMERIC}"
			+ " AND BeneFecRegPago IS NULL";
			
 
	
	@Update(UPDATE_BENEFICIARIO_LOTE_ID)
	 public void updateBeneficiarioLoteId(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres,@Param("loteId") String loteId
			 ,@Param("usuario") String usuario);
	
	
	final String SELECT_BENEFICIARIO_LOTE_ID_NOMBRE=""
			+ " SELECT * FROM SINI_BENEF"
			+ " WHERE"
			+ " LTRIM(RTRIM(SiniestroID))=#{siniestroId,jdbcType=NVARCHAR} AND"
			+ " (UPPER(LTRIM(RTRIM(REPLACE(BeneApePat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneApeMat,' ',''))))+''+UPPER(LTRIM(RTRIM(REPLACE(BeneNom,' ','')))))=UPPER(#{nombres,jdbcType=NVARCHAR})";
	
	@Select(SELECT_BENEFICIARIO_LOTE_ID_NOMBRE)
  	@ResultMap("BaseResultMap")
	public BeneficiarioSiniestro beneficiariosBySiniestroNombres(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres);
	
	
	final String UPDATE_BENE_FECHA_ASIGNA =
			" UPDATE SINI_BENEF SET BeneFecAsigFirmante = CONVERT (date,GETDATE())"
			+ " ,UsuModifica = #{usuario,jdbcType=NVARCHAR}"
			+ " ,FecModifica = CONVERT (date,GETDATE())" 
	        + " WHERE loteId = #{loteId,jdbcType=NVARCHAR}";
	
	@Update(UPDATE_BENE_FECHA_ASIGNA)
	 public void updateBeneficiarioFechaAsigna(@Param("loteId") String loteId
			 ,@Param("usuario") String usuario);
	
	@Select(UPDATE_SINIESTRO_FECHA_PROVISIONADO)
	@ResultMap("BaseResultMap")
	public void updateSiniestroFechaProvisionado(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres,@Param("beneMontoPagar") double beneMontoPagar,@Param("beneFechaProvisionado") Date beneFechaProvisionado,@Param("usuario") String usuario);
	
	@Select(UPDATE_SINIESTRO_FECHA_REGISTRO_PAGO)
	@ResultMap("BaseResultMap")
	public void updateSiniestroFechaRegistroPago(@Param("siniestroId") String siniestroId,@Param("nombres") String nombres,@Param("beneMontoPagar") double beneMontoPagar,@Param("usuario") String usuario);
	
	public int validarExisteLoteIdArchConf_SB(@Param("loteId") String loteId);
	
}
