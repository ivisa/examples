package com.cardif.satelite.siniestro.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.model.satelite.CamposTramaSiniVentanilla;

public interface CamposTramaPagoSiniVentanillaMapper {

	public int getLongitudTotalCamposTramaByBancoIdAndTramaId(@Param("bancoId") String bancoId, @Param("tramaId") String tramaId);
	
	public List<CamposTramaSiniVentanilla> getCamposTramaByBancoIdAndTramaId(@Param("bancoId") String bancoId, @Param("tramaId") String tramaId);

}
