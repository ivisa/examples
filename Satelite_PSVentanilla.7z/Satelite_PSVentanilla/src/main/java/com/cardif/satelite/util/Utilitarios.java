package com.cardif.satelite.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.lang.time.DateUtils;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.Parametro;

public class Utilitarios {

	/**
	 * @author lmaron
	 * @fecha 15/03/2014
	 * @param line
	 * @return cadena con caracteres extranios reemplazados
	 */
	public static String replaceCaracters(String line) {

		CharsetEncoder isoEncoder = Charset.forName("ISO-8859-1").newEncoder();
		CharsetEncoder asciEncoder = Charset.forName("ASCII").newEncoder();
		CharsetEncoder utf8Encoder = Charset.forName("UTF-8").newEncoder();

		Boolean isISO = isoEncoder.canEncode(line);
		Boolean isASCII = asciEncoder.canEncode(line);
		String datos = "";

		if (isISO == false && isASCII == false) {
			Charset utf8charset = Charset.forName("UTF-8");
			Charset iso88591charset = Charset.forName("ISO-8859-1");
			// Decode UTF-8
			ByteBuffer bb = ByteBuffer.wrap(line.getBytes());
			CharBuffer data = utf8charset.decode(bb);

			// Encode ISO-8559-1
			ByteBuffer outputBuffer = iso88591charset.encode(data);
			byte[] outputData = outputBuffer.array();

			datos = new String(outputData);

			// logger.info("Datos con caract. Reemplazados |: "+datos);
		} else {
			datos = line;
			// logger.info("Datos no modificados: "+datos);
		}
		/*
		 * logger.info("isISO : "+isISO); logger.info("isASCII : "+isASCII);
		 * logger.info("isUTF8 : "+isUTF8);
		 */
		return datos;
	}

	/***
   * 
   */
	public static String convertirFechaACadena(Date fecha, String formato) {
		DateFormat df = null;
		String respuesta = "";
		try {
			if (fecha != null) {
				df = new SimpleDateFormat(formato, Locale.US);
				respuesta = df.format(fecha);
			} else {
				respuesta = "";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return respuesta;
	}

	/**
	 * Gutenberg Torres Brousset P.
	 */
	public static String completaCadenaIzq(String cadena, int longitud) {
		String respuesta = cadena == null ? "" : cadena;
		respuesta = String.format("%1$-" + longitud + "s", respuesta);
		return respuesta;
	}

	public static synchronized boolean verificarRangoDeFechas(Date fechaInicial, Date fechaFinal, int dias) throws Exception {
		/*
		 * Truncar las fechas
		 */
		fechaInicial = DateUtils.truncate(fechaInicial, Calendar.DAY_OF_MONTH);
		fechaFinal = DateUtils.truncate(fechaFinal, Calendar.DAY_OF_MONTH);

		Date fechaInicialDias = DateUtils.addDays(fechaInicial, dias);

		/*
		 * Validar: - fechaFinal >= fechaInicial - (fechaInicial + dias) >
		 * fechaFinal
		 */
		boolean flag = false;
		if ((fechaFinal.after(fechaInicial) || fechaInicial.equals(fechaFinal)) && fechaInicialDias.after(fechaFinal)) {
			flag = true;
		}
		return flag;
	} // verificarRangoDeFechas

	public static synchronized Parametro obtenerObjetoParametro(List<Parametro> listaParametros, String codValor) {
		Parametro paramRespuesta = null;

		if (null != listaParametros && 0 < listaParametros.size()) {
			for (Parametro parametro : listaParametros) {
				if (parametro.getCodValor().equalsIgnoreCase(codValor)) {
					paramRespuesta = parametro;
					break;
				}
			}
		}
		return paramRespuesta;
	} // obtenerObjetoParametro

	public static String verificarLongitudCampo(String str, int longitudMax) {
		String campo = "";
		campo = str.substring(0, longitudMax);
		return campo;
	}// verificarLongitudCampo

	public static Boolean validateCharacter(String cadena) {

		Boolean sw = false;
		if (null != cadena) {
			Matcher mat = null;
			Pattern pat = Pattern.compile("^([A-z\\s-ñáéíóúÑÁÉÍÓÚ.0-9]{1,255})$");
			mat = pat.matcher(cadena);
			if (!mat.matches()) {
				sw = true;
			}

			char[] ca = cadena.toCharArray();

			for (char c : ca) {
				switch (c) {
				case '[':
					sw = true;
					break;
				case ']':
					sw = true;
					break;
				case '_':
					sw = true;
					break;
				case '-':
					sw = true;
					break;
				}
			}
		}

		return sw;
	}

	public static Boolean validateCharacterDesCanal(String cadena) {

		Boolean sw = false;
		if (null != cadena) {
			Matcher mat = null;
			Pattern pat = Pattern.compile("^([A-z\\s-ñáéíóúÑÁÉÍÓÚ.0-9]{1,255})$");
			mat = pat.matcher(cadena);
			if (!mat.matches()) {
				sw = true;
			}

			char[] ca = cadena.toCharArray();

			for (char c : ca) {
				switch (c) {
				case '[':
					sw = true;
					break;
				case ']':
					sw = true;
					break;
				case '-':
					sw = true;
					break;
				}
			}
		}

		return sw;
	}

	public static boolean validarFechasInicioFin(Date fechaInicio, Date fechaFin) {
		boolean rpt = false;
		int resultado = 0;

		resultado = fechaFin.compareTo(fechaInicio);
		if (resultado == 0 || resultado > 0) {
			rpt = true;
		}

		return rpt;
	}

	public static void copyFiles(File source, File destino) throws IOException {

		InputStream inStream = null;
		OutputStream outStream = null;

		try {

			inStream = new FileInputStream(source);
			outStream = new FileOutputStream(destino);

			byte[] buffer = new byte[1024];

			int length;
			// copy the file content in bytes
			while ((length = inStream.read(buffer)) > 0) {

				outStream.write(buffer, 0, length);

			}

			inStream.close();
			outStream.close();

			// delete the original file
			// source.delete();

			System.out.println("File is copied successful!");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static String formateoMonto(Double monto) {
		String montoStr = "";

		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		DecimalFormat df = (DecimalFormat) nf;
		df.applyPattern("#####.00");

		if (monto == null || monto == 0D || Double.isNaN(monto)) {
			montoStr = "0.00";
		} else {
			montoStr = df.format(monto);
		}
		return montoStr;
	}

	public static String personalizarFecha(Date fecha, String formato) {
		String fechaFormateada = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat(formato);
		fechaFormateada = dateFormat.format(fecha);
		return fechaFormateada;

	}

	public static boolean validarRangoFechas(Calendar fechaInicio, Calendar fechaFinal) {
		boolean respuesta = false;
		Calendar fecIni = Calendar.getInstance();
		fecIni.setTime(fechaInicio.getTime());
		fecIni.set(Calendar.HOUR_OF_DAY, 0);
		fecIni.set(Calendar.MINUTE, 0);
		fecIni.set(Calendar.SECOND, 0);
		fecIni.set(Calendar.MILLISECOND, 0);

		Calendar fecFin = Calendar.getInstance();
		fecFin.setTime(fechaFinal.getTime());
		fecFin.set(Calendar.HOUR_OF_DAY, 0);
		fecFin.set(Calendar.MINUTE, 0);
		fecFin.set(Calendar.SECOND, 0);
		fecFin.set(Calendar.MILLISECOND, 0);

		if (fecIni.before(fechaFinal)) {
			return true;
		}
		if (fecIni.equals(fecFin)) {
			return true;
		}

		return respuesta;
	}

	/* inicio ventanilla */

	public static Boolean validateCorreoElectronico(String cadena) {
		Matcher mat = null;
		Pattern pat = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
		mat = pat.matcher(cadena);
		return mat.find();
	}

	/* fin ventanilla */

	public static String limpiarEspacios(String palabra) {
		String nuevo = "";
		for (int x = 0; x < palabra.length(); x++) {
			if (palabra.charAt(x) != ' ')
				nuevo += palabra.charAt(x);
		}
		return nuevo;
	}

	public static String getEmptyString(String x) {
		if(x==null){
			return x;
		}
		if (x.length() == 0) {
			return null;
		} else {
			return x;
		}
	}

	public static void sendMailWithAttachments(String recipients, String subject, String body, List<String> attachFiles) throws AddressException, MessagingException,IOException {

		Properties props = new Properties();
		props.put("mail.smtp.auth", Constantes.SMTP_AUTH_FALSE_MAIL);
		props.put("mail.smtp.starttls.enable", Constantes.SMTP_STARTTLS_MAIL);
		props.put("mail.smtp.host", Constantes.SMTP_HOST_MAIL);
		props.put("mail.smtp.port", Constantes.SMTP_PORT_MAIL);

		Session session = Session.getInstance(props);

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(Constantes.USER_NAME_MAIL));

			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipients));

			message.setSubject(subject);
			message.setSentDate(new Date());

			// creates message part
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(body, "text/html");

			// creates multi-part
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);

			// adds attachments
			if (attachFiles != null && attachFiles.size() > 0) {
				for (String filePath : attachFiles) {
					MimeBodyPart attachPart = new MimeBodyPart();
					attachPart.attachFile(filePath);
					multipart.addBodyPart(attachPart);
				}
			}
			message.setContent(multipart);

			Transport.send(message);
		} catch (MessagingException e) {
			throw new MessagingException(e.getMessage());
		} catch (IOException ex) {
			throw new IOException(ex.getMessage());
		}

	}
	public static boolean excedeTamanioArchivos(List<File> archivos,long maximo){
		long suma=0;
		boolean band=false;
		for(File file:archivos){
			suma = suma + file.length();
		}
		if(suma > maximo){
			band=true;
		}
		return band;
	}
	public static byte[] readBytesFromFile(String filePath) throws IOException {

        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;

        try {

            File file = new File(filePath);
            bytesArray = new byte[(int) file.length()];

            //read file into bytes[]
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);

        } catch (IOException e) {
        	throw new IOException(e);
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                	throw new IOException(e);
                }
            }

        }

        return bytesArray;

    }
	
	public static Map<String, Object> validarNroDocumento(String nroDoc, String tipoDoc){
		Map<String, Object> respMap = new HashMap<String, Object>();
		String msj = "";
		
		boolean rptNotBlank = (nroDoc != null && nroDoc.trim().length() > 0) ? true : false;
		
		if(!rptNotBlank){
			msj = "Nro. de documento vacío.";
			respMap.put("false", msj);
			return respMap;
		}
		
		//DNI
		if(tipoDoc.equals("2") && nroDoc.trim().length() != 8){
			msj = "Longitud de Nro. de DNI incorrecto.";
			respMap.put("false", msj);
			return respMap;
		}
		
		if(tipoDoc.equals("RUC") && nroDoc.trim().length() != 11){
			msj = "Longitud de RUC incorrecto.";
			respMap.put("false", msj);
			return respMap;
		}
		
		
		Matcher mat = null;
		Pattern pat = Pattern.compile("^([0-9]{0,255})$");
		mat = pat.matcher(nroDoc);	
		boolean rptMatch = mat.matches();
		
		if(!rptMatch){
			msj = "No se permiten caracteres especiales ni espacios en blanco para el Nro. de Documento.";
			respMap.put("false", msj);
			return respMap;
		}
		
		respMap.put("true", null);
		
		return respMap;
		
	}
	
	public static Map<String, Object> validarNombresApellidos(String cadena, String tipoCadena){
		Map<String, Object> respMap = new HashMap<String, Object>();
		String msj = "";
		
		boolean rptNotBlank = (cadena != null && cadena.trim().length() > 0) ? true : false;
		
		if(!rptNotBlank){
			if(tipoCadena.equals("NOMBRES")){
				msj = "El Campo Nombres no puede ser vacío.";
			} else
			if(tipoCadena.equals("PATERNO")){
				msj = "El Apellido Paterno no puede ser vacío.";
			} else
			if(tipoCadena.equals("MATERNO")){
				msj = "El Apellido Materno no puede ser vacío.";	
			}
						
			respMap.put("false", msj);
			return respMap;
		}
		
		Matcher mat = null;
		Pattern pat = Pattern.compile("^([A-Za-zñáéíóúÑÁÉÍÓÚ\\s-]{0,255})$");
		mat = pat.matcher(cadena);	
		boolean rptMatch = mat.matches();
		
		if(!rptMatch){
			if(tipoCadena.equals("NOMBRES")){
				msj = "Solo se permiten letras y el caracter especial (-) para nómbres.";
			} else
			if(tipoCadena.equals("PATERNO")){
				msj = "Solo se permiten letras y el caracter especial (-) para apellido paterno.";
			} else
			if(tipoCadena.equals("MATERNO")){
				msj = "Solo se permiten letras y el caracter especial (-) para apellido materno.";
			}
			
			respMap.put("false", msj);
			return respMap;
		}
		
		respMap.put("true", null);
		
		return respMap;
		
	}
	
	public static Map<String, Object> validarTelefono(String nroTel){
		Map<String, Object> respMap = new HashMap<String, Object>();
		String msj = "";
		
		if(nroTel == null || nroTel.trim().length() == 0){
			respMap.put("true", msj);
			return respMap;
		}
		
		Matcher mat = null;
		Pattern pat = Pattern.compile("^([0-9\\s-()]{0,255})$");
		mat = pat.matcher(nroTel);	
		boolean rptMatch = mat.matches();
		
		if(!rptMatch){
			msj = "Solo se permiten números y los caracteres '()' y '-' para los teléfonos.";
			respMap.put("false", msj);
			return respMap;
		}
		
		respMap.put("true", null);
		
		return respMap;
		
	}
	
	public static Map<String, Object> validarDireccion(String direccion){
		Map<String, Object> respMap = new HashMap<String, Object>();
		String msj = "";
		
		if(direccion == null || direccion.trim().length() == 0){
			respMap.put("true", msj);
			return respMap;
		}
		
		Matcher mat = null;
		Pattern pat = Pattern.compile("^([A-Za-zñáéíóúÑÁÉÍÓÚ0-9\\s.,/#º°-]{0,255})$");
		mat = pat.matcher(direccion);	
		boolean rptMatch = mat.matches();
		
		if(!rptMatch){
			msj = "Solo se permiten letras, números y los caracteres '. , / # º ° -' para la dirección.";
			respMap.put("false", msj);
			return respMap;
		}
		
		respMap.put("true", null);
		
		return respMap;
		
	}
	
	public static Map<String, Object> validarCtaBancariaCCI(String nroCtaBancaria){
		Map<String, Object> respMap = new HashMap<String, Object>();
		String msj = "";
		
		if(nroCtaBancaria == null || nroCtaBancaria.trim().length() == 0){
			respMap.put("true", msj);
			return respMap;
		}
		
		Matcher mat = null;
		Pattern pat = Pattern.compile("^([0-9-]{0,255})$");
		mat = pat.matcher(nroCtaBancaria);	
		boolean rptMatch = mat.matches();
		
		if(!rptMatch){
			msj = "Solo se permiten números y el caracter '-' para cuenta bancaria.";
			respMap.put("false", msj);
			return respMap;
		}
		
		respMap.put("true", null);
		
		return respMap;
		
	}
	
	public static Date convertStringToDate(String fechaCadena,String formatoFecha) throws ParseException{
		Date fechaCovertida=null;
		SimpleDateFormat formatter = new SimpleDateFormat(formatoFecha);
		fechaCovertida = formatter.parse(fechaCadena);
		return fechaCovertida;
	}

}
