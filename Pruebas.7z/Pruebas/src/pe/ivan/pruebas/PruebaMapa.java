package pe.ivan.pruebas;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class PruebaMapa {
	public static void main(String[] args){
		Map<Integer,String> mapa=new HashMap<Integer, String>();
		mapa.put(5, "Ana");
		mapa.put(1, "Juan");
		for(String cadena: mapa.values()){
			System.out.println(cadena);
		}
		
		double numero=539.98999;
		int entero = (int)numero;
		System.out.println(""+entero);
		String numeroOriginal= String.valueOf(numero);
		System.out.println(numeroOriginal);
		String[] pedasos=numeroOriginal.split(Pattern.quote("."));
		System.out.println("size "+ pedasos.length);
		System.out.println("pedazo 0 "+ pedasos[0]);
		System.out.println("pedazo 1 "+ pedasos[1]);
		
		String palabra= "0011-0586-51-0100009495 CTA CTE BBVA";
		System.out.println(Util.formatear(palabra));
		
		
		File file=new File("C:\\SUService.log");
		System.out.println(file.getName());
		System.out.println(file.length());
		List<File> archivos=new ArrayList<File>();
		archivos.add(file);
		long maximo=5242880;
		if(Util.verificarTamanioArchivos(archivos, maximo)){
			System.out.println("Es mayor");
		}else{
			System.out.println("Esta ok");
		}
		String nombre="IVAN_IGOR";
		String []arreglo=nombre.split("_");
		System.out.println(arreglo[1]);
	}
}
