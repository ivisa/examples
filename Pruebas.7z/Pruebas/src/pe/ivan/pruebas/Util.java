package pe.ivan.pruebas;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class Util {
	public static List<Persona> delete(List<Persona> lista,Persona persona){
		List<Persona> nuevaLista=new ArrayList<Persona>();
		nuevaLista.addAll(lista);
		Iterator iterator=nuevaLista.iterator();
		while(iterator.hasNext()){
			Persona personaLista=(Persona)iterator.next();
			if(persona.getDni().compareTo(personaLista.getDni())==0){
				iterator.remove();
				break;
			}
		}
		return nuevaLista;
	} 
	public static String personalizarFecha(Date fecha, String formato){
		String fechaFormateada="";
		SimpleDateFormat dateFormat=new SimpleDateFormat(formato);
		fechaFormateada=dateFormat.format(fecha);
		return fechaFormateada;
				
	}
	public static String limpiarEspacios(String palabra){
		String nuevo="";
	    for (int x=0; x < palabra.length(); x++) {
	        if (palabra.charAt(x) != ' ')
	        	nuevo += palabra.charAt(x);
	      }
	    return nuevo;
	}
	public static String formatear(String cuentaBanco){
		  String cuentaFormateada = "";
		  String cuentaSeleccionada="";
		  cuentaSeleccionada=cuentaBanco.trim();
		  for(int i=0;i< cuentaSeleccionada.length();i++){
			  if(cuentaSeleccionada.charAt(i)=='C'){
				  break;
			  }else{
				  cuentaFormateada = cuentaFormateada + cuentaSeleccionada.charAt(i);
			  }
		  }
		  return cuentaFormateada;
	  }
	public static boolean verificarTamanioArchivos(List<File> archivos,long maximo){
		long suma=0;
		boolean band=false;
		for(File file:archivos){
			suma = suma + file.length();
		}
		if(suma > maximo){
			band=true;
		}
		return band;
	}
	public static Date convertStringToDate(String fechaCadena,String formatoFecha) throws ParseException{
		Date fechaCovertida=null;
		SimpleDateFormat formatter = new SimpleDateFormat(formatoFecha);
		fechaCovertida = formatter.parse(fechaCadena);
		return fechaCovertida;
	}
}
