package pe.ivan.pruebas;

public class EncuentraCadena {
	public static void main(String[]args){
		String cadena="Ivan zapata";
		String buscar="apatz";
		if(cadena.contains(buscar)){
			System.out.println("encontro");
		}else{
			System.out.println("No encontro");
		}
		cadena= cadena.replace("Ivan","Igor");
		System.out.println(cadena);
	}
}
