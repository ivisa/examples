package pe.ivan.pruebas;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class SumarBigDecimal {
	public static void main(String[]args) {
		float valor1=6;
		float valor2=3;
		BigDecimal bigDecimal=new BigDecimal("0");
		bigDecimal=bigDecimal.add(new BigDecimal(valor1));
		bigDecimal=bigDecimal.add(new BigDecimal(valor2));
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		  DecimalFormat formateador = (DecimalFormat)nf;
		  formateador.applyPattern("###,###.##");
		System.out.println(formateador.format(bigDecimal));
	}
	
}
