package pe.ivan.pruebas;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class PruebaCheque {
	public static void main(String[]args){
		Cheque cheque =new Cheque();
		cheque.setNumero("20170026SNPEN");
		cheque.setDiario(396253);
		List<Cheque> lista=new ArrayList<Cheque>();
		lista.add(cheque);
		Cheque cheque1 =new Cheque();
		cheque1.setNumero("20170026SNPEN");
		cheque1.setDiario(396252);
		lista.add(cheque1);
		Cheque cheque2 =new Cheque();
		cheque2.setNumero("20170026SNPEN");
		cheque2.setDiario(396253);
		lista.add(cheque2);
		for(Cheque che:lista){
			System.out.println(che.getNumero()+" "+ che.getDiario());
		}
		Collections.sort(lista,Cheque.referenciaDiarioComparator);
		for(Cheque che:lista){
			System.out.println(che.getNumero()+" "+ che.getDiario());
		}
	}
}
