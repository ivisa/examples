package pe.ivan.pruebas;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Prueba {
	public static void main(String [] args) {
		String fmt="#.##";
		float importe=(float) 56.5596666666;
		BigDecimal importeBig= new BigDecimal(importe);
		System.out.println(""+importeBig);
		
		importeBig=importeBig.setScale(2, BigDecimal.ROUND_DOWN);
		System.out.println(""+importeBig.doubleValue());
		/*
		DecimalFormat df = new DecimalFormat(fmt);
		df.setRoundingMode(RoundingMode.DOWN);
		System.out.println(""+importe);
		String s = df.format(importe);
		System.out.println(""+s);
		Double valor= Double.parseDouble(s);
		System.out.println(""+valor);*/
		// TODO Auto-generated method stub
		Persona persona1=new Persona(30,"Ivan Igor","Zapata S�mbala","44175328");
		Persona persona2=new Persona(29,"Juan","Vargas","44175329");
		Persona persona3=new Persona(30,"Pedro","Garcia","44175330");
		Persona persona4=new Persona(31,"Girder","Fonseca","44175331");
		Persona persona5=new Persona(32,"Miguel","Orellana","44175332");
		Persona persona6=new Persona(23,"Heber","Cayo","44175333");
		List<Persona> personas=new ArrayList<Persona>();
		personas.add(persona1);
		personas.add(persona2);
		personas.add(persona3);
		personas.add(persona4);
		personas.add(persona5);
		personas.add(persona6);
		imprimir(personas);
		System.out.println("---------------Eliminar: "+persona2.getDni());
		List<Persona> personasNuevas=Util.delete(personas, persona2);
		personas.clear();
		personas.addAll(personasNuevas);
		imprimir(personas);
		System.out.println("---------------Fecha Actual");
		Date fecha = Calendar.getInstance().getTime();
		System.out.println(fecha);
		System.out.println("---------------Fecha formateada");
		System.out.println(Util.personalizarFecha(fecha,"ddMMyyyyHHmm"));
		System.out.println(Util.personalizarFecha(fecha,"ddMMyyyy"));
		
		String nombre="Ivan Igor,Zapata Simbala    ";
		System.out.println(nombre);
		nombre=nombre.replace(',',' ');
		System.out.println(Util.limpiarEspacios(nombre)+"FFFF");
		
		String reemplazar="Ivan igor zapata simbala.pdf";
		reemplazar= reemplazar.replaceAll(".pdf","");
		System.out.println(reemplazar);
	}	
	public static void imprimir(List<Persona> lista) {
		// TODO Auto-generated method stub
		int numero = 1;
		for(Persona persona:lista){
			System.out.println("Persona "+numero+"----------");
			System.out.println("DNI:    "+persona.getDni());
			System.out.println("Nombre  "+persona.getNombre());
			System.out.println("Apellido"+persona.getApellido());
			System.out.println("Edad    "+persona.getEdad());
			numero=numero+1;
		}
	}
}
