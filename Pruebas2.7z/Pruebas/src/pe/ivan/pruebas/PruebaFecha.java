package pe.ivan.pruebas;

import java.text.ParseException;
import java.util.Date;

public class PruebaFecha {
	public static void main(String[] args){
		String fecha="24052017";
		String formato="ddMMyyyy";
		try {
			Date fechaObtenida=Util.convertStringToDate(fecha, formato);
			System.out.println(fechaObtenida.toString());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
